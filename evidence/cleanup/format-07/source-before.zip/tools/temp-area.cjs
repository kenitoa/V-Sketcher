// A uniquely owned system-temporary area. Cleanup never accepts an arbitrary root.
const fs = require('node:fs');
const path = require('node:path');
const { tmpdir } = require('node:os');
const { randomUUID } = require('node:crypto');

function createTempArea(label = 'test') {
  if (!/^[a-z][a-z0-9-]{0,40}$/.test(label)) throw Error('E_TEMP_LABEL');
  const parent = fs.realpathSync(tmpdir());
  const root = fs.mkdtempSync(path.join(parent, '2dsketcher-' + label + '-'));
  const marker = path.join(root, '.owned-area.json');
  const token = randomUUID();
  fs.writeFileSync(marker, JSON.stringify({ format: '2dsketcher-temp/1', token }), { flag: 'wx' });
  let disposed = false;
  return Object.freeze({
    path(relative = '') {
      if (disposed) throw Error('E_TEMP_DISPOSED');
      const target = path.resolve(root, relative);
      const part = path.relative(root, target);
      if (path.isAbsolute(part) || part.split(/[\\/]/).includes('..')) throw Error('E_TEMP_PATH');
      return target;
    },
    dispose() {
      if (disposed) return;
      if (!fs.existsSync(root)) throw Error('E_TEMP_MISSING');
      if (
        fs.lstatSync(root).isSymbolicLink() ||
        fs.realpathSync(root) !== root ||
        path.dirname(root) !== parent
      )
        throw Error('E_TEMP_ROOT');
      if (JSON.parse(fs.readFileSync(marker, 'utf8')).token !== token) throw Error('E_TEMP_OWNER');
      // Node removes junction entries themselves, never their external targets.
      fs.rmSync(root, { recursive: true, maxRetries: 3, retryDelay: 100 });
      disposed = true;
    },
  });
}
module.exports = { createTempArea };
