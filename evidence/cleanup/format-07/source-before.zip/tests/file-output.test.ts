import { scratchPath } from './temp';
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir, mkdtemp, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import { randomUUID, createHash } from 'node:crypto';
import { readProject, type Project } from '../packages/project-model';
import { ProjectSession } from '../packages/project-session';
import { readBundle } from '../packages/project-storage/archive';
import { ImageExportService, type FileInput } from '../packages/image-export/service';
import {
  defaultImageSettings,
  assertImageSettings,
  type ImageRequest,
} from '../packages/image-export/types';
import { writePNG, imageHash } from '../packages/image-export/atomic';
import { inspectCompatibility } from '../packages/export-check';
import { CompatibilityService } from '../packages/export-check/service';
import {
  TARGET_ID,
  CONVERTER_VERSION,
  assertTargetOptions,
  type TargetOptions,
} from '../packages/export-check/types';
async function fixture() {
  const r = readProject(await readFile('assets/product/preview-project.json', 'utf8'));
  if (r.mode !== 'read-write') throw new Error('fixture');
  const project = r.project,
    resources = new Map<string, Buffer>();
  for (const a of project.assets)
    resources.set(
      a.id,
      await readFile(join('assets/product/preview', a.fingerprint.sha256 + '.png')),
    );
  return { project, resources };
}
function basis(p: Project) {
  return {
    source: 'working' as const,
    projectId: p.projectId,
    revision: p.revision,
    fingerprint: createHash('sha256').update(JSON.stringify(p)).digest('hex'),
  };
}
const opts = (p: Project): TargetOptions => ({
  targetId: TARGET_ID,
  parameterMap: p.parameters.map((v) => ({
    parameterId: v.id,
    targetName: v.previewKey ?? v.semantic,
  })),
});
async function directory() {
  await mkdir(scratchPath('file-output-tests'), { recursive: true });
  return mkdtemp(scratchPath('file-output-tests/run-'));
}
async function images() {
  const f = await fixture(),
    png = f.resources.values().next().value!,
    width = png.readUInt32BE(16),
    height = png.readUInt32BE(20),
    dir = await directory();
  let valid = true,
    running = false,
    chosen: string | null = join(dir, 'image.png'),
    renders = 0;
  const input: FileInput = { ...f, basis: basis(f.project) };
  const s = new ImageExportService({
    capture: async () => input,
    validate: () => valid,
    running: () => running,
    render: async () => {
      renders++;
      return png;
    },
    choose: async () => chosen,
  });
  const request = (): ImageRequest => ({
    id: randomUUID(),
    source: 'working',
    projectId: f.project.projectId,
    revision: f.project.revision,
    settings: defaultImageSettings(width, height),
    live: null,
  });
  return {
    s,
    f,
    png,
    dir,
    request,
    renders: () => renders,
    setValid: (v: boolean) => {
      valid = v;
    },
    setRunning: (v: boolean) => {
      running = v;
    },
    setChoice: (v: string | null) => {
      chosen = v;
    },
  };
}
test('PNG settings enforce bounded explicit format, size, alpha, pose and crop', () => {
  assertImageSettings(defaultImageSettings());
  for (const value of [
    { ...defaultImageSettings(), format: 'jpg' },
    { ...defaultImageSettings(), width: 0 },
    { ...defaultImageSettings(), width: 4097 },
    { ...defaultImageSettings(), transparent: 'yes' },
    { ...defaultImageSettings(), background: 'url(secret)' },
    { ...defaultImageSettings(), x: Infinity },
    { ...defaultImageSettings(), crop: { left: 0.45, right: 0.45, top: 0, bottom: 0 } },
    { ...defaultImageSettings(), pose: 'expression', expressionId: null },
  ])
    assert.throws(() => assertImageSettings(value), /E_IMAGE_SETTINGS/);
});
test('image preparation freezes settings/basis and saves exactly preview PNG bytes without devices', async () => {
  const x = await images();
  try {
    const req = x.request(),
      ticket = await x.s.prepare(req);
    req.settings.width = 64;
    assert.equal(ticket.settings.width, x.png.readUInt32BE(16));
    assert.equal(x.s.resource(`assets/image-export/${ticket.id}/preview.png`), x.png);
    const receipt = await x.s.save(ticket.id);
    assert.equal(receipt!.sha256, ticket.sha256);
    assert.deepEqual(await readFile(join(x.dir, 'image.png')), x.png);
    assert.equal(x.renders(), 1);
  } finally {
    x.s.close();
  }
});
test('static parts need no motion rig, parameters or runtime to create a PNG', async () => {
  const x = await images();
  delete x.f.project.motion;
  x.f.project.parameters = [];
  x.f.project.partBindings = [];
  x.f.project.expressions = [];
  x.f.project.inputBindings = [];
  x.f.project.exportProfiles = [];
  delete x.f.project.expressionSettings;
  x.f.project.runtimeProfile.fallbackExpressionId = null;
  try {
    const ticket = await x.s.prepare(x.request());
    assert.ok(ticket.bytes > 0);
    assert.ok(await x.s.save(ticket.id));
  } finally {
    x.s.close();
  }
});
test('changed input before native save selection is rejected without overwriting a file', async () => {
  const x = await images();
  try {
    const ticket = await x.s.prepare(x.request());
    await writeFile(join(x.dir, 'image.png'), Buffer.from('previous'));
    x.setValid(false);
    await assert.rejects(x.s.save(ticket.id), /E_IMAGE_STALE/);
    assert.equal(await readFile(join(x.dir, 'image.png'), 'utf8'), 'previous');
  } finally {
    x.s.close();
  }
});
test('native save cancellation retains preview and creates no file', async () => {
  const x = await images();
  try {
    const t = await x.s.prepare(x.request());
    x.setChoice(null);
    assert.equal(await x.s.save(t.id), null);
    assert.equal(x.s.stats().tickets, 1);
    assert.equal((await readdir(x.dir)).length, 0);
  } finally {
    x.s.close();
  }
});
test('cancel and late rendering results cannot revive an old image ticket', async () => {
  const f = await fixture(),
    png = f.resources.values().next().value!;
  let finish!: (v: Buffer) => void;
  const ready = new Promise<Buffer>((r) => {
    finish = r;
  });
  const s = new ImageExportService({
    capture: async () => ({ ...f, basis: basis(f.project) }),
    validate: () => true,
    running: () => false,
    render: async () => ready,
    choose: async () => null,
  });
  const id = randomUUID(),
    request: ImageRequest = {
      id,
      source: 'working',
      projectId: f.project.projectId,
      revision: f.project.revision,
      settings: defaultImageSettings(png.readUInt32BE(16), png.readUInt32BE(20)),
      live: null,
    };
  const pending = s.prepare(request);
  await new Promise((r) => setTimeout(r, 10));
  s.release(id);
  finish(png);
  await assert.rejects(pending, /E_IMAGE_(CANCELLED|STALE)/);
  assert.equal(s.stats().tickets, 0);
  assert.equal(s.stats().resources, 0);
});
test('PNG write faults preserve an old target and clean only owned temporary files', async () => {
  const x = await images(),
    file = join(x.dir, 'image.png'),
    old = Buffer.from('old');
  for (const stage of ['before-write', 'after-sync', 'before-replace']) {
    await writeFile(file, old);
    await assert.rejects(
      writePNG(
        file,
        x.png,
        x.png.readUInt32BE(16),
        x.png.readUInt32BE(20),
        imageHash(old),
        undefined,
        (phase) => {
          if (phase === stage) throw Object.assign(new Error('fault'), { code: 'ENOSPC' });
        },
      ),
    );
    assert.deepEqual(await readFile(file), old);
    assert.deepEqual(await readdir(x.dir), ['image.png']);
  }
});
test('PNG optimistic overwrite rejects a concurrent outside change', async () => {
  const x = await images(),
    file = join(x.dir, 'image.png');
  await writeFile(file, 'old');
  await assert.rejects(
    writePNG(
      file,
      x.png,
      x.png.readUInt32BE(16),
      x.png.readUInt32BE(20),
      imageHash(Buffer.from('old')),
      undefined,
      async (phase) => {
        if (phase === 'before-replace') await writeFile(file, 'outside');
      },
    ),
    /E_IMAGE_CONFLICT/,
  );
  assert.equal(await readFile(file, 'utf8'), 'outside');
});
test('large render work is deferred during an active execution and accepted after stop', async () => {
  const x = await images();
  try {
    x.setRunning(true);
    const req = x.request();
    req.settings.width = 4096;
    req.settings.height = 4096;
    await assert.rejects(x.s.prepare(req), /E_IMAGE_DEFER/);
    assert.equal(x.renders(), 0);
    x.setRunning(false);
    assert.ok(await x.s.prepare(x.request()));
  } finally {
    x.s.close();
  }
});
test('release of an old ticket does not revoke a newer prepared image', async () => {
  const x = await images();
  try {
    const a = await x.s.prepare(x.request()),
      b = await x.s.prepare(x.request());
    x.s.release(a.id);
    assert.equal(x.s.stats().tickets, 1);
    assert.ok(await x.s.save(b.id));
  } finally {
    x.s.close();
  }
});
test('external profile rejects unsupported targets and unknown request fields', () => {
  assertTargetOptions({ targetId: TARGET_ID, parameterMap: [] });
  assert.throws(
    () => assertTargetOptions({ targetId: 'vrm', parameterMap: [] }),
    /E_EXPORT_TARGET/,
  );
  assert.throws(
    () => assertTargetOptions({ targetId: TARGET_ID, parameterMap: [], secret: 'ignored' }),
    /E_EXPORT_TARGET/,
  );
});
test('compatibility report blocks missing core controls and assets instead of silently dropping them', async () => {
  const { project: p, resources } = await fixture();
  p.parameters = p.parameters.filter((v) => v.previewKey !== 'mouth');
  const r = inspectCompatibility(p, basis(p), opts(p), new Set(resources.keys()));
  assert.equal(r.status, 'BLOCKED');
  assert.ok(r.issues.some((v) => v.code === 'CORE_PARAMETER'));
  const q = await fixture(),
    missing = inspectCompatibility(q.project, basis(q.project), opts(q.project), new Set());
  assert.ok(missing.issues.some((v) => v.code === 'ASSET_MISSING' && v.fix));
});
test('bad hierarchy, references and expression values produce identified blocking issues', async () => {
  const { project: p, resources } = await fixture();
  p.parts[0]!.parentId = p.parts[0]!.id;
  p.expressions[0]!.values[0]!.parameterId = 'missing';
  const r = inspectCompatibility(p, basis(p), opts(p), new Set(resources.keys()));
  assert.equal(r.status, 'BLOCKED');
  assert.ok(r.issues.some((v) => v.category === 'structure'));
  assert.ok(r.issues.some((v) => v.code === 'EXPRESSION_REFERENCE'));
});
test('case-folded duplicate target names and unmapped parameters block conversion', async () => {
  const f = await fixture(),
    o = opts(f.project);
  o.parameterMap[1]!.targetName = o.parameterMap[0]!.targetName.toUpperCase();
  o.parameterMap.pop();
  const r = inspectCompatibility(f.project, basis(f.project), o, new Set(f.resources.keys()));
  assert.ok(r.issues.some((v) => v.code === 'PARAMETER_MAP'));
  assert.ok(r.issues.some((v) => v.code === 'UNMAPPED_PARAMETER'));
});
test('texture budget and unknown color space remain explicit blockers', async () => {
  const f = await fixture();
  const used = f.project.assets.find((a) => a.id === f.project.parts[0]!.textures[0]!.assetId)!;
  used.colorSpace = 'unknown';
  used.dimensions = { width: 8192, height: 8192 };
  f.project.parts[0]!.color = {
    hueDegrees: 10,
    minimumHue: 0,
    maximumHue: 1,
    minimumSaturation: 0,
  };
  const r = inspectCompatibility(
    f.project,
    basis(f.project),
    opts(f.project),
    new Set(f.resources.keys()),
  );
  assert.ok(r.issues.some((v) => v.code === 'COLOR_SPACE'));
  assert.ok(r.issues.some((v) => v.code === 'TEXTURE_SIZE'));
  assert.ok(r.issues.some((v) => v.code === 'COLOR_BAKE'));
});
test('supported weighted mesh export retains explicit approximation and texture warnings', async () => {
  const f = await fixture(),
    r = inspectCompatibility(
      f.project,
      basis(f.project),
      opts(f.project),
      new Set(f.resources.keys()),
    );
  assert.equal(r.status, 'WARNING');
  assert.ok(r.issues.some((v) => v.code === 'SAMPLED_DEFORMATION' && v.severity === 'warning'));
  assert.ok(r.issues.some((v) => v.code === 'TEXTURE_ENCODING' && v.severity === 'warning'));
});
test('normalized conversion copy keeps original untouched and contains real centered vertices/UUIDs', async () => {
  const f = await fixture(),
    original = JSON.stringify(f.project),
    r = inspectCompatibility(
      f.project,
      basis(f.project),
      opts(f.project),
      new Set(f.resources.keys()),
    );
  assert.equal(JSON.stringify(f.project), original);
  assert.ok(r.copy!.parts.every((p) => Number.isSafeInteger(p.uuid) && p.uuid > 0));
  assert.ok(r.copy!.parts.some((p) => p.vertices.some((v) => v[0] < 0)));
  assert.ok(
    r.copy!.textures.every((t) => t.name.startsWith('textures/') && !t.name.includes('..')),
  );
  assert.ok(r.copy!.changes.length > 0);
});
test('warning acknowledgement binds the exact basis, target, checker and warning signature', async () => {
  const f = await fixture();
  delete f.project.motion;
  for (const key of ['head_yaw', 'head_roll']) {
    const p = f.project.parameters.find((p) => p.previewKey === key)!;
    f.project.partBindings.push({
      id: randomUUID(),
      parameterId: p.id,
      partId: f.project.parts[0]!.id,
      kind: 'transform',
      mapping: {
        component: key === 'head_yaw' ? 'translate-x' : 'rotate-degrees',
        outputRange: [-1, 1],
      },
    });
  }
  const s = new CompatibilityService(
    async () => ({ ...f, basis: basis(f.project) }),
    (b) => b.fingerprint === basis(f.project).fingerprint,
  );
  const r = await s.inspect('working', f.project.projectId, f.project.revision, opts(f.project));
  assert.equal(r.status, 'WARNING');
  const opaque = structuredClone(f.project);
  opaque.expressions = [];
  delete opaque.expressionSettings;
  opaque.runtimeProfile.fallbackExpressionId = null;
  for (const a of opaque.assets) a.alphaMode = 'opaque';
  assert.equal(
    inspectCompatibility(opaque, basis(opaque), opts(opaque), new Set(f.resources.keys())).status,
    'PASS',
  );
  assert.throws(() => s.acknowledge(r.id, r.signature, 'wrong'), /E_EXPORT_ACK/);
  assert.equal(s.acknowledge(r.id, r.signature, r.warningScope).acknowledged, true);
  f.project.revision++;
  assert.throws(() => s.verify(r.id), /E_EXPORT_STALE/);
  s.close();
});
test('reinspection clears prior acknowledgement and target settings change changes the signature', async () => {
  const f = await fixture();
  let valid = true;
  const s = new CompatibilityService(
    async () => ({ ...f, basis: basis(f.project) }),
    () => valid,
  );
  const a = await s.inspect('working', f.project.projectId, f.project.revision, opts(f.project)),
    o = opts(f.project);
  o.parameterMap[0]!.targetName = 'renamed-eye';
  const b = await s.inspect('working', f.project.projectId, f.project.revision, o);
  assert.notEqual(a.signature, b.signature);
  assert.equal(b.acknowledged, false);
  assert.throws(() => s.verify(a.id), /E_EXPORT_STALE/);
  assert.equal(s.acknowledge(b.id, b.signature, b.warningScope).acknowledged, true);
  valid = false;
  assert.throws(() => s.verify(b.id), /E_EXPORT_STALE/);
  s.close();
});
test('project target settings survive real save/reopen and invalidate old preflight input', async () => {
  const f = await fixture(),
    dir = await directory(),
    file = join(dir, 'target.2dsketch');
  const s = new ProjectSession({
    dataDir: dir,
    dialogs: {
      openProject: async () => file,
      saveProject: async () => file,
      relinkImage: async () => null,
      unsaved: async () => 'discard',
    },
    bundled: f.project,
    bundledBytes: f.resources,
    autoTimers: false,
  });
  await s.init();
  try {
    await s.newProject('export settings', 'parts');
    await s.dispatch({ type: 'sample' });
    const p = s.view().project!,
      old = s.runtimeInputBasis('working', p.projectId, p.revision),
      profile = {
        id: randomUUID(),
        revision: 1,
        displayName: 'Inochi 0.8.7',
        target: 'inochi2d',
        targetVersion: '0.8.7',
        format: 'inp',
        converterVersion: CONVERTER_VERSION,
        parameterMap: opts(p).parameterMap,
      };
    await s.dispatch({ type: 'export-profile', expectedRevision: p.revision, profile });
    assert.equal(s.view().errorCode, null);
    assert.throws(() => s.runtimeInputBasis('working', old.projectId, old.revision));
    await s.dispatch({ type: 'save' });
    assert.ok((await readBundle(file)).project!.exportProfiles.some((p) => p.id === profile.id));
    await s.dispatch({ type: 'open' });
    assert.ok(s.view().project!.exportProfiles.some((p) => p.id === profile.id));
  } finally {
    await s.shutdown();
  }
});
