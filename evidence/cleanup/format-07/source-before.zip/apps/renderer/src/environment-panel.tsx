import { useEffect, useState } from 'react';
import { defaults, type SettingsView, type ResourceMetrics } from '../../../packages/settings';
import type { SessionView } from '../../../packages/project-session/contracts';
import type { RunRuntime } from './run-runtime';
import type { CameraRuntime } from './camera-runtime';
import type { MicrophoneRuntime } from './microphone-runtime';
import type { RunPreferences } from '../../../packages/execution';
import { Modal } from './ui-foundations';
import './environment.css';
export function EnvironmentPanel({
  view,
  run,
  camera,
  microphone,
  close,
  navigate,
}: {
  view: SessionView | null;
  run: RunRuntime;
  camera: CameraRuntime;
  microphone: MicrophoneRuntime;
  close: () => void;
  navigate: (to: 'camera' | 'microphone' | 'broadcast') => void;
}) {
  const [tab, setTab] = useState('environment'),
    [saved, setSaved] = useState<SettingsView | null>(null),
    [form, setForm] = useState(defaults),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState(''),
    [devices, setDevices] = useState<MediaDeviceInfo[]>([]),
    [resources, setResources] = useState<ResourceMetrics | null>(null),
    [, tick] = useState(0),
    [support, setSupport] = useState<Awaited<
      ReturnType<typeof window.studio.settings.support>
    > | null>(null),
    [keys, setKeys] = useState<RunPreferences>(structuredClone(run.preferences)),
    [diagnosticReview, setDiagnosticReview] = useState(false);
  useEffect(() => {
    void run.context(true);
    return () => {
      void run.context(false);
    };
  }, [run]);
  const load = async () => {
    const data = await window.studio.settings.view();
    setSaved(data);
    setForm(data.value);
  };
  const list = async () => {
    try {
      setDevices(await navigator.mediaDevices.enumerateDevices());
    } catch {
      setMessage('장치 목록을 읽지 못했어요. 연결 화면에서 다시 확인하세요.');
    }
  };
  useEffect(() => {
    let alive = true;
    void load();
    void list();
    void window.studio.settings.support().then((v) => {
      if (alive) setSupport(v);
    });
    const timer = setInterval(() => {
      tick((v) => v + 1);
      void window.studio.settings.metrics().then((v) => {
        if (alive) setResources(v);
      });
    }, 1000);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, []);
  const operate = async (action: () => Promise<void>) => {
    if (busy) return;
    setBusy(true);
    setMessage('');
    try {
      await action();
    } catch {
      setMessage('처리하지 못했어요. 기존 설정과 원본은 유지됩니다.');
    } finally {
      setBusy(false);
    }
  };
  const release = async () => {
    camera.stop();
    run.camera.stop();
    await Promise.all([
      camera.stopped(),
      run.camera.stopped(),
      microphone.stop(),
      run.microphone.stop(),
    ]);
  };
  const save = async () => {
    const result = await window.studio.settings.save(form);
    if (!result.ok) throw new Error();
    if (!form.cameraRequests) {
      camera.stop();
      run.camera.stop();
      await Promise.all([camera.stopped(), run.camera.stopped()]);
    }
    if (!form.microphoneRequests) await Promise.all([microphone.stop(), run.microphone.stop()]);
    await load();
    setMessage('이 PC의 환경 설정을 적용했어요. 프로젝트 원본은 유지됩니다.');
  };
  const metrics = run.surface.metrics.summary(performance.now()),
    textureMiB = run.surface.textureEstimateMiB();
  const state = (kind: 'camera' | 'microphone') =>
    [kind === 'camera' ? camera : microphone, kind === 'camera' ? run.camera : run.microphone].some(
      (r) => r.state === 'open',
    )
      ? '사용 중'
      : [
            kind === 'camera' ? camera : microphone,
            kind === 'camera' ? run.camera : run.microphone,
          ].some((r) => r.state === 'connecting')
        ? '연결 중'
        : '사용 안 함';
  const exportDiagnostic = async () => {
    const result = await window.studio.settings.diagnostic({
      run: run.state,
      camera: camera.state === 'open' ? camera.state : run.camera.state,
      microphone: microphone.state === 'open' ? microphone.state : run.microphone.state,
      fps: metrics.fps.value,
      submissionP95: metrics.submissionP95.value,
      textureMiB,
    });
    if (!result.ok) throw new Error();
    setMessage(
      result.cancelled
        ? '진단 파일 저장을 취소했어요.'
        : '그림·영상·음성·경로를 제외한 진단 JSON을 저장했어요.',
    );
    setDiagnosticReview(false);
  };
  return (
    <Modal
      titleId="environment-title"
      className="environment-dialog"
      onClose={() => {
        if (!busy) close();
      }}
    >
      <section data-environment-panel aria-busy={busy}>
        <header className="settings-heading">
          <div>
            <span className="settings-eyebrow">PREFERENCES</span>
            <h2 id="environment-title">환경 설정</h2>
          </div>
          <span className="settings-scope">
            <i />이 PC에만 저장
          </span>
        </header>
        <div className="settings-layout">
          <nav className="settings-tabs" aria-label="설정 분류">
            {[
              ['environment', '장치·저장·키', '기기와 작업 환경'],
              ['privacy', '개인정보', '접근 권한과 데이터'],
              ['performance', '성능·품질', '측정과 수동 조절'],
              ['support', '지원 정보', '버전·출처·진단'],
            ].map(([id, label, description], i) => (
              <button
                key={id}
                data-settings-tab={id}
                aria-current={tab === id ? 'page' : undefined}
                aria-pressed={tab === id}
                onClick={() => {
                  setTab(id!);
                  requestAnimationFrame(() =>
                    document.querySelector('.settings-content')?.scrollTo({ top: 0 }),
                  );
                }}
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  aria-hidden="true"
                >
                  <path
                    d={
                      [
                        'M5 4h14v11H5zM9 20h6M12 15v5',
                        'M12 3 4 6v6c0 5 8 9 8 9s8-4 8-9V6zM8 12l3 3 5-6',
                        'M4 18V8m5 10V4m6 14v-6m5 6V9M2 21h20',
                        'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20M12 10v7M12 6v1',
                      ][i]
                    }
                  />
                </svg>
                <span>
                  <strong>{label}</strong>
                  <small>{description}</small>
                </span>
                <span className="settings-chevron">›</span>
              </button>
            ))}
            <div className="settings-nav-note">
              <span className="settings-pill">LOCAL</span>
              <p>
                프로젝트를 옮겨도
                <br />이 PC의 설정은 분리됩니다.
              </p>
            </div>
          </nav>
          <div className="settings-content">
            {saved?.loadError && (
              <div className="settings-callout warning" role="alert">
                설정을 읽지 못해 기본값으로 표시합니다. 검토 후 적용하면 이 PC의 설정을 다시
                저장합니다.
              </div>
            )}
            {tab === 'environment' && (
              <>
                <div className="settings-section-title">
                  <h3>장치와 작업 환경</h3>
                  <p>프로젝트의 부위·표정·추적 매핑과 별도로 관리합니다.</p>
                </div>
                <section className="settings-card">
                  <div className="settings-card-heading">
                    <h4>기본 입력 장치</h4>
                    <span className="settings-pill neutral">자동 연결 안 함</span>
                  </div>
                  <div className="settings-fields">
                    {(['camera', 'microphone'] as const).map((kind, i) => (
                      <label key={kind}>
                        {i === 0 ? '카메라' : '마이크'}
                        <select
                          data-settings-device={kind}
                          value={kind === 'camera' ? form.cameraId : form.microphoneId}
                          onChange={(e) =>
                            setForm({
                              ...form,
                              [kind === 'camera' ? 'cameraId' : 'microphoneId']: e.target.value,
                            })
                          }
                        >
                          <option value="">Windows 기본 장치</option>
                          {devices
                            .filter((d) => d.kind === (i === 0 ? 'videoinput' : 'audioinput'))
                            .map((d, n) => (
                              <option key={d.deviceId || n} value={d.deviceId}>
                                {d.label || `${i === 0 ? '카메라' : '마이크'} ${n + 1}`}
                              </option>
                            ))}
                          {(kind === 'camera' ? form.cameraId : form.microphoneId) &&
                            !devices.some(
                              (d) =>
                                d.deviceId ===
                                (kind === 'camera' ? form.cameraId : form.microphoneId),
                            ) && (
                              <option value={kind === 'camera' ? form.cameraId : form.microphoneId}>
                                저장한 장치 없음 · 다시 선택
                              </option>
                            )}
                        </select>
                      </label>
                    ))}
                  </div>
                  <button className="settings-text-button" onClick={() => void list()}>
                    ↻ 장치 목록 새로 고침
                  </button>
                </section>
                <section className="settings-card">
                  <h4>저장과 자동 복구</h4>
                  <div className="settings-folder">
                    <div>
                      <span className="settings-field-caption">기본 저장 폴더</span>
                      <strong data-settings-folder>
                        {saved?.defaultFolderSet ? '사용자가 선택한 폴더' : 'Windows 문서 폴더'}
                      </strong>
                    </div>
                    <button
                      data-settings-folder-select
                      disabled={busy}
                      onClick={() =>
                        void operate(async () => {
                          if (!(await window.studio.settings.folder()).ok) throw new Error();
                          setSaved(await window.studio.settings.view());
                        })
                      }
                    >
                      폴더 선택
                    </button>
                    <button
                      className="settings-text-button"
                      disabled={busy}
                      onClick={() =>
                        void operate(async () => {
                          if (!(await window.studio.settings.folder(true)).ok) throw new Error();
                          setSaved(await window.studio.settings.view());
                        })
                      }
                    >
                      기본값
                    </button>
                  </div>
                  <label>
                    자동 복구 주기
                    <select
                      data-settings-recovery
                      value={form.recovery}
                      onChange={(e) =>
                        setForm({ ...form, recovery: e.target.value as typeof form.recovery })
                      }
                    >
                      <option value="standard">표준 · 편집 유휴 15초 / 최대 60초</option>
                      <option value="frequent">자주 · 편집 유휴 5초 / 최대 30초</option>
                      <option value="off">사용 안 함 · 직접 저장 필요</option>
                    </select>
                  </label>
                  <div className="settings-callout">
                    자동 복구는 Ctrl+S 저장과 별개입니다. 꺼도 기존 복구본과 중요 변경 전 보관본은
                    유지됩니다.
                  </div>
                </section>
                <section className="settings-card">
                  <details className="settings-key-details">
                    <summary>
                      <span>
                        <strong>빠른 조작 키</strong>
                        <small>앱 전용·전역 등록과 현재 상태</small>
                      </span>
                      <span className="settings-pill neutral">
                        {keys.bindings.filter((k) => k.enabled).length}개 사용
                      </span>
                    </summary>
                    <div className="settings-switch-row">
                      <div>
                        <strong>이 PC에서 전역 키 허용</strong>
                        <small>실행 중에만 등록합니다. 충돌한 키는 다시 선택하세요.</small>
                      </div>
                      <input
                        className="settings-switch"
                        aria-label="전역 키 허용"
                        type="checkbox"
                        data-settings-global
                        checked={keys.allowGlobal}
                        onChange={(e) => setKeys({ ...keys, allowGlobal: e.target.checked })}
                      />
                    </div>
                    {keys.bindings.map((b, i) => (
                      <div className="settings-key-row" key={b.action}>
                        <label>
                          <input
                            type="checkbox"
                            checked={b.enabled}
                            onChange={(e) =>
                              setKeys({
                                ...keys,
                                bindings: keys.bindings.map((v, n) =>
                                  n === i ? { ...v, enabled: e.target.checked } : v,
                                ),
                              })
                            }
                          />
                          {
                            {
                              neutral: '기본 자세',
                              release: '표정 해제',
                              hide: '캐릭터 숨김',
                              recalibrate: '중립 재보정',
                              stop: '실행 중지',
                              'expression-1': '표정 1',
                              'expression-2': '표정 2',
                              'expression-3': '표정 3',
                            }[b.action]
                          }
                        </label>
                        <input
                          aria-label={b.action + ' 키'}
                          value={b.accelerator}
                          onChange={(e) =>
                            setKeys({
                              ...keys,
                              bindings: keys.bindings.map((v, n) =>
                                n === i ? { ...v, accelerator: e.target.value } : v,
                              ),
                            })
                          }
                        />
                        <select
                          aria-label={b.action + ' 범위'}
                          value={b.scope}
                          onChange={(e) =>
                            setKeys({
                              ...keys,
                              bindings: keys.bindings.map((v, n) =>
                                n === i ? { ...v, scope: e.target.value as 'local' | 'global' } : v,
                              ),
                            })
                          }
                        >
                          <option value="local">앱 전용</option>
                          <option value="global">전역</option>
                        </select>
                        <small>
                          {
                            {
                              local: '앱 전용',
                              disabled: '사용 안 함',
                              inactive: '실행 전',
                              suspended: '설정 중 보류',
                              registered: '등록됨',
                              conflict: '충돌',
                            }[run.statuses.find((v) => v.action === b.action)?.state ?? 'inactive']
                          }
                        </small>
                      </div>
                    ))}
                    <button
                      disabled={busy}
                      data-settings-keys-save
                      onClick={() =>
                        void operate(async () => {
                          if (!(await run.configure(keys))) throw new Error();
                          setMessage('키 설정을 저장했어요. 설정 창에서는 전역 조작을 보류합니다.');
                        })
                      }
                    >
                      키 설정 저장
                    </button>
                  </details>
                </section>
              </>
            )}
            {tab === 'privacy' && (
              <>
                <div className="settings-section-title">
                  <h3>개인정보와 장치 접근</h3>
                  <p>장치 연결·로컬 기록·학습 활용을 각각 구분합니다.</p>
                </div>
                <section className="settings-card">
                  <div className="settings-card-heading">
                    <h4>현재 장치 사용</h4>
                    <button
                      data-settings-release
                      disabled={busy}
                      onClick={() =>
                        void operate(async () => {
                          await release();
                          setMessage(
                            '카메라 트랙·추적 worker와 마이크 트랙·오디오 분석을 해제했어요.',
                          );
                        })
                      }
                    >
                      모든 장치 해제
                    </button>
                  </div>
                  <div className="settings-device-status" data-settings-device-state>
                    {(['camera', 'microphone'] as const).map((kind, i) => (
                      <div key={kind}>
                        <span>{i === 0 ? '카메라' : '마이크'}</span>
                        <strong className={state(kind) === '사용 중' ? 'is-on' : ''}>
                          <i />
                          {state(kind)}
                        </strong>
                      </div>
                    ))}
                  </div>
                  {(['cameraRequests', 'microphoneRequests'] as const).map((key, i) => (
                    <label className="settings-switch-row" key={key}>
                      <span>
                        <strong>{i === 0 ? '카메라' : '마이크'} 연결 요청 허용</strong>
                        <small>연결 버튼을 누를 때 접근할 수 있습니다.</small>
                      </span>
                      <input
                        className="settings-switch"
                        data-settings-camera-permission={i === 0 ? '' : undefined}
                        data-settings-mic-permission={i === 1 ? '' : undefined}
                        type="checkbox"
                        checked={form[key]}
                        onChange={(e) => setForm({ ...form, [key]: e.target.checked })}
                      />
                    </label>
                  ))}
                  <p className="settings-note">
                    허용만으로 장치를 열지 않습니다. Windows 권한 확인이 필요하며, 해제 후에는 연결
                    화면에서 직접 다시 시작하세요.
                  </p>
                </section>
                <section className="settings-card">
                  <div className="settings-card-heading">
                    <h4>데이터 처리 위치</h4>
                    <span className="settings-pill">로컬 처리</span>
                  </div>
                  <div className="settings-data-flow">
                    <span>카메라·마이크</span>
                    <b>→</b>
                    <span>메모리에서 분석</span>
                    <b>→</b>
                    <span>캐릭터 출력</span>
                  </div>
                  <p>
                    2D 분석·추적·음량·렌더·저장·INP 생성은 이 PC에서 처리합니다. 카메라 영상은 추적
                    후 폐기하며 원음 녹음·방송 오디오 송출·자산 학습은 하지 않습니다.
                  </p>
                  <p>
                    OBS에는 이 PC의 loopback 연결로 캐릭터와 제어만 전달합니다. 카메라
                    영상·원음·편집 화면은 전달하지 않습니다. 모델·원화·worker를 패키지에 포함하며
                    현재 기능에는 서버 계정이 필요하지 않습니다.
                  </p>
                  <details>
                    <summary>네트워크·보관·삭제 범위</summary>
                    <p>
                      개발 도구 설치와 공식 외부 프로그램 다운로드는 별도의 네트워크 작업입니다.
                      프로젝트는 지정한 저장 위치에, 캐시·복구본·기기 설정은 앱 데이터 폴더에
                      남습니다. 앱 종료만으로 파일이 삭제되지는 않습니다.
                    </p>
                    <p>
                      프로젝트·내보낸 파일은 저장 위치에서 직접 삭제하세요. 캐시·복구본을 삭제하려면
                      프로젝트를 먼저 저장하고 앱을 종료한 뒤 앱 데이터 폴더에서 처리하세요. 삭제한
                      미저장 복구본은 복원할 수 없습니다. 자동 복구·이전 정상본은 각각 5개 정책으로
                      관리합니다.
                    </p>
                    <button onClick={() => void window.studio.settings.dataFolder()}>
                      앱 데이터 폴더 열기
                    </button>
                  </details>
                </section>
                <section className="settings-card">
                  <label className="settings-switch-row">
                    <span>
                      <strong>최소 로컬 진단 기록</strong>
                      <small>버전·이벤트·시간·오류 코드만 기록합니다.</small>
                    </span>
                    <input
                      className="settings-switch"
                      data-settings-local-log
                      type="checkbox"
                      checked={form.localDiagnostics}
                      onChange={(e) => setForm({ ...form, localDiagnostics: e.target.checked })}
                    />
                  </label>
                  <p className="settings-note">
                    그림·영상·음성·개인 경로·토큰은 제외합니다. 기록을 꺼도 기존 로그는 남습니다.
                  </p>
                  <button
                    data-settings-clear-logs
                    disabled={busy}
                    onClick={() =>
                      void operate(async () => {
                        if (!(await window.studio.settings.clearLogs()).ok) throw new Error();
                        setMessage(
                          '앱의 최소 진단 로그만 삭제했어요. 프로젝트·복구본은 유지됩니다.',
                        );
                      })
                    }
                  >
                    기존 진단 로그 삭제
                  </button>
                  <div className="settings-policy-row">
                    <span>진단 자동 전송</span>
                    <span className="settings-pill neutral">미제공·동의 안 됨</span>
                  </div>
                  <div className="settings-policy-row">
                    <span>사용자 자산 학습 활용</span>
                    <span className="settings-pill neutral">미제공·동의 안 됨</span>
                  </div>
                  <p className="settings-note">
                    장치 허용을 진단 전송이나 학습 활용 동의로 해석하지 않습니다.
                  </p>
                </section>
              </>
            )}
            {tab === 'performance' && (
              <>
                <div className="settings-section-title">
                  <h3>성능과 미리보기 품질</h3>
                  <p>측정 범위를 확인하고, 필요한 항목만 직접 조절하세요.</p>
                </div>
                <div className="settings-metric-grid" data-settings-performance>
                  <article className="settings-metric">
                    <span>제출 프레임</span>
                    <strong>
                      {metrics.fps.value?.toFixed(1) ?? '—'}
                      <small>FPS</small>
                    </strong>
                    <span
                      className={'settings-pill ' + (metrics.fps.value === null ? 'neutral' : '')}
                    >
                      {metrics.fps.value === null ? '미측정' : '실측'}
                    </span>
                  </article>
                  <article className="settings-metric">
                    <span>CPU 제출 작업 p95</span>
                    <strong>
                      {metrics.submissionP95.value?.toFixed(2) ?? '—'}
                      <small>ms</small>
                    </strong>
                    <span
                      className={
                        'settings-pill ' + (metrics.submissionP95.value === null ? 'neutral' : '')
                      }
                    >
                      {metrics.submissionP95.value === null ? '미측정' : '실측'}
                    </span>
                  </article>
                  <article className="settings-metric">
                    <span>기본 레벨 텍스처</span>
                    <strong>
                      {textureMiB?.toFixed(1) ?? '—'}
                      <small>MiB</small>
                    </strong>
                    <span
                      className={'settings-pill ' + (textureMiB === null ? 'neutral' : 'estimate')}
                    >
                      {textureMiB === null ? '미측정' : '추정'}
                    </span>
                  </article>
                  <p className="settings-measure-window">
                    구간: 최근 {Math.round(metrics.fps.windowMs)} ms · {metrics.fps.samples}개 제출
                  </p>
                </div>
                <div className="settings-callout">
                  GPU 완료 FPS·센서→OBS 전체 지연·OBS 인코더 성능은 <strong>미측정</strong>입니다.
                  제출 계측으로 대체하지 않습니다.
                </div>
                <section className="settings-card">
                  <div className="settings-card-heading">
                    <h4>실행 미리보기</h4>
                    <button
                      className="settings-text-button"
                      data-settings-quality-reset
                      onClick={() => setForm({ ...form, previewFps: 30, previewScale: 1 })}
                    >
                      기본값 복원
                    </button>
                  </div>
                  <div className="settings-fields">
                    <label>
                      프레임 제한
                      <select
                        data-settings-fps
                        value={form.previewFps}
                        onChange={(e) =>
                          setForm({
                            ...form,
                            previewFps: Number(e.target.value) as typeof form.previewFps,
                          })
                        }
                      >
                        <option value="15">15 FPS</option>
                        <option value="30">30 FPS · 기본</option>
                        <option value="60">60 FPS · 추가 부하</option>
                      </select>
                    </label>
                    <label>
                      표시 해상도
                      <select
                        data-settings-scale
                        value={form.previewScale}
                        onChange={(e) =>
                          setForm({
                            ...form,
                            previewScale: Number(e.target.value) as typeof form.previewScale,
                          })
                        }
                      >
                        <option value="1">640 × 800 · 기본</option>
                        <option value="0.75">480 × 600</option>
                        <option value="0.5">320 × 400</option>
                      </select>
                    </label>
                  </div>
                  <p className="settings-note">
                    실행 미리보기에만 적용합니다. 원본 텍스처·프로젝트·PNG/INP 결과는 보존하며, 방송
                    크기·프레임은 별도로 조절합니다.
                  </p>
                  <button disabled={!view?.project} onClick={() => navigate('broadcast')}>
                    방송 출력 설정 열기 ↗
                  </button>
                </section>
                <section className="settings-card">
                  <div className="settings-card-heading">
                    <h4>자원·자동 조절</h4>
                    <span className="settings-pill neutral">자동 조절 미제공</span>
                  </div>
                  <div className="settings-resource-row">
                    <span>Electron 작업 집합 합계</span>
                    <strong>{resources?.rssMiB.toFixed(1) ?? '—'} MiB</strong>
                  </div>
                  <div className="settings-resource-row">
                    <span>Electron CPU API 합계</span>
                    <strong>{resources?.cpuPercent?.toFixed(1) ?? '미측정'}%</strong>
                  </div>
                  <p className="settings-note">
                    프로세스 {resources?.processes ?? 0}개 · 측정 구간{' '}
                    {Math.round(resources?.windowMs ?? 0)} ms. Python worker·OBS 제외, 공유 메모리
                    중복 가능. 드라이버의 실제 GPU 메모리는 미측정입니다.
                  </p>
                  <p>
                    부하가 높으면 미리보기 프레임·해상도를 낮추고 방송 출력을 1280×720·15 FPS로
                    조절하세요. 직접 복원할 때까지 선택값을 유지합니다. 현재 계측은 출시 성능 통과
                    판정이 아닙니다.
                  </p>
                </section>
              </>
            )}
            {tab === 'support' && (
              <>
                <div className="settings-section-title">
                  <h3>지원 정보와 진단</h3>
                  <p>현재 버전과 사용 자산, 문제 재현에 필요한 정보를 확인합니다.</p>
                </div>
                <section className="settings-card">
                  <h4>현재 구성요소</h4>
                  <dl className="settings-version-grid">
                    {Object.entries(support?.versions ?? {}).map(([k, v]) => (
                      <div key={k}>
                        <dt>
                          {(
                            {
                              app: '앱',
                              project: '프로젝트 모델',
                              electron: '앱 런타임',
                              chromium: '렌더 엔진',
                              tracking: '얼굴 추적',
                              checker: '호환 검사',
                              converter: 'INP 변환',
                              broadcast: '방송 검증 대상',
                              avatar: '아바타 검증 대상',
                            } as Record<string, string>
                          )[k] ?? k}
                        </dt>
                        <dd>{v}</dd>
                      </div>
                    ))}
                  </dl>
                </section>
                <section className="settings-card">
                  <h4>지원 형식·환경</h4>
                  <div className="settings-format-tags">
                    {[
                      'PNG',
                      'JPEG',
                      '.2dparts 1.0',
                      '.2dsketch 1.9',
                      'RGBA PNG 출력',
                      '제한 프로필 INP',
                    ].map((v) => (
                      <span key={v}>{v}</span>
                    ))}
                  </div>
                  <p className="settings-note">
                    분리 PNG 폴더를 지원합니다. PSD·VRM·moc3·다른 Session 버전은 미지원입니다.
                  </p>
                  <details>
                    <summary>실제 기준 장비와 검증 범위</summary>
                    <p>
                      Windows 11 x64 · i5-13420H · 31.71 GiB RAM · RTX 4050 Laptop 6 GB / Intel UHD
                      · Windows 11 Pro 26300. 단일 PC 검증이며 최소 사양이나 모든 장비의 성능 보증은
                      아닙니다.
                    </p>
                    <p>
                      깨끗한 별도 Windows·장치 호환성·장시간 성능은 추가 검증 대상입니다. 실제
                      카메라·전역 키 재검증 대기와 출시 승인은 자동 시험·사용자 외부 확인과
                      구분합니다.
                    </p>
                  </details>
                </section>
                <section className="settings-card">
                  <details>
                    <summary>
                      <strong>현재 프로젝트 자산 출처</strong>
                    </summary>
                    <p className="settings-note">
                      입력 자료의 사용 권한을 직접 확인하세요. 프로그램이 권리를 자동 보증하지
                      않습니다.
                    </p>
                    <div className="settings-attributions">
                      {[
                        ...new Map(
                          (
                            view?.project?.assets.map((a) => ({
                              author: a.attribution.creator,
                              source: a.attribution.source,
                              license: a.attribution.usage,
                              status: a.attribution.status,
                            })) ??
                            support?.attributions ??
                            []
                          ).map((a) => [JSON.stringify(a), a]),
                        ).values(),
                      ].map((a, i) => (
                        <div key={i}>
                          <strong>{a.author}</strong>
                          <span>{a.source}</span>
                          <small>
                            {a.license}
                            {'status' in a && a.status === 'unverified' ? ' · 권한 확인 필요' : ''}
                          </small>
                        </div>
                      ))}
                    </div>
                  </details>
                  <button
                    data-settings-notices
                    disabled={!support?.noticesAvailable}
                    onClick={() => void window.studio.settings.notices()}
                  >
                    구성요소 고지·모델·원화 출처 열기 ↗
                  </button>
                </section>
                <section className="settings-card settings-diagnostic-card">
                  <div className="settings-card-heading">
                    <h4>최소 진단 파일</h4>
                    <span className="settings-pill">로컬 JSON</span>
                  </div>
                  <p>
                    <strong>포함</strong> 버전·실행/장치 상태·제출 FPS/CPU 제출 p95·텍스처 추정
                  </p>
                  <p className="settings-note">
                    <strong>제외</strong> 이름/ID·그림·영상·음성·파일 이름·개인 경로·장치
                    식별자·주소/토큰·원시 오류/로그. 직접 저장·공유하며 자동 전송하지 않습니다.
                  </p>
                  <label className="settings-review">
                    <input
                      data-settings-diagnostic-review
                      type="checkbox"
                      checked={diagnosticReview}
                      onChange={(e) => setDiagnosticReview(e.target.checked)}
                    />
                    위 포함 항목을 확인했습니다
                  </label>
                  <button
                    data-settings-diagnostic
                    disabled={busy || !diagnosticReview}
                    onClick={() => void operate(exportDiagnostic)}
                  >
                    진단 JSON 저장
                  </button>
                </section>
              </>
            )}
          </div>
        </div>
        <footer className="settings-footer">
          <p data-settings-message role="status">
            {message || '변경한 환경 설정은 적용 후 이 PC에 저장됩니다.'}
          </p>
          <div>
            <button data-settings-close disabled={busy} onClick={close}>
              닫기
            </button>
            <button
              data-settings-apply
              className="primary"
              disabled={busy || !saved}
              onClick={() => void operate(save)}
            >
              {busy ? '처리 중…' : '변경 사항 적용'}
            </button>
          </div>
        </footer>
      </section>
    </Modal>
  );
}
