import { useEffect, useState } from 'react';
import type { SessionView } from '../../../packages/project-session/contracts';
import type { RunRuntime } from './run-runtime';
import { RunCanvas } from './run-panel';
import { defaultTracking } from '../../../packages/tracking';
const kinds = {
  none: '실행본과 같은 내용',
  immediate: '검증 후 즉시 반영',
  manual: '새 그림 검사 후 수동 적용',
  restart: '검사 후 실행 상태 재시작 필요',
};
export function RunDock({
  runtime: r,
  view,
  open,
  showPreview,
  save,
  tracking,
}: {
  runtime: RunRuntime;
  view: SessionView;
  open: () => void;
  showPreview: boolean;
  save: () => void;
  tracking: (gain: number) => void;
}) {
  const [, refresh] = useState(0);
  useEffect(() => r.subscribe(() => refresh((n) => n + 1)), [r]);
  if (!r.active || !r.lease) return null;
  const change = r.changeFor(view),
    blocked =
      view.saving ||
      view.editingGroup ||
      view.jobs.some((j) =>
        ['QUEUED', 'RUNNING', 'RESULT_READY', 'CANCEL_REQUESTED'].includes(j.state),
      );
  const gain = (view.project?.tracking ?? defaultTracking()).channels.find(
    (v) => v.key === 'head_yaw',
  )!.gain;
  const error: Record<string, string> = {
    E_RUN_STALE: '검사 중 작업본이 바뀌었습니다. 기존 실행은 유지됩니다. 취소 후 새로 검사하세요.',
    E_RUN_RESOURCE: '그림 파일을 확인하지 못했습니다. 기존 실행을 유지합니다.',
    E_RUN_RENDER: '새 그림을 표시하지 못했습니다. 기존 실행을 유지합니다.',
    E_RUN_HEAVY: '실행 중 자원 한도를 넘습니다. 실행을 중지한 뒤 준비하세요.',
    E_RUN_BUSY: '저장·편집 조절·작업이 끝난 뒤 다시 검사하세요.',
    E_RUN_RESTART: '실행 상태 재시작을 선택해야 반영할 수 있습니다.',
  };
  return (
    <section
      className="run-dock"
      data-run-dock
      data-change-kind={change?.kind ?? 'none'}
      data-change-state={r.changeState}
      aria-label="실행과 작업본"
    >
      <div>{showPreview && <RunCanvas runtime={r} />}</div>
      <div className="run-dock-controls">
        <strong>
          {r.lease.project.displayName} · 실행본 {r.lease.revision} ·{' '}
          {r.state === 'limited' ? '제한 실행' : '정상 실행'}
        </strong>
        <p data-run-revisions>
          작업본: {view.project ? `${view.project.displayName} · ${view.project.revision}` : '닫힘'}{' '}
          / 저장본: {view.savedRevision ?? '아직 없음'}
          <br />
          입력·표정·실행 화면은 실행본을 사용합니다. 저장은 현재 작업본을 사용합니다.
        </p>
        <p data-run-change-kind>
          {change ? kinds[change.kind] : '다른 작업본을 열어도 현재 캐릭터는 계속 실행합니다.'}
        </p>
        <label>
          <input
            data-run-auto
            type="checkbox"
            checked={r.autoApply}
            onChange={(e) => r.setAutoApply(e.target.checked)}
          />
          표정·추적 설정의 검증된 변경 자동 반영
        </label>
        {r.changeState === 'preparing' && (
          <p role="status">새 실행본 검사 중 · 현재 실행은 유지됩니다.</p>
        )}
        {r.changeState === 'ready' && (
          <p role="status">
            변경 {r.preparedRevision} 검사 완료
            {r.preparedRevision !== view.project?.revision
              ? ' · 이후 편집이 있습니다. 취소 후 새로 검사하세요.'
              : ''}
          </p>
        )}
        {r.changeState === 'committing' && <p role="status">프레임 경계에서 교체 중</p>}
        {r.changeError && (
          <p role="alert" data-run-change-error>
            {error[r.changeError] ?? '변경을 적용하지 못했습니다. 기존 실행을 유지합니다.'}{' '}
            <code>{r.changeError}</code>
          </p>
        )}
        <div className="edit-actions">
          <button
            data-run-change-prepare
            disabled={
              !view.project || change?.kind === 'none' || r.changeState !== 'idle' || blocked
            }
            onClick={() => void r.prepareChanges(view)}
          >
            변경 검사·준비
          </button>
          {r.changeState === 'ready' && (
            <button
              data-run-change-apply
              disabled={change?.kind === 'restart' || r.preparedRevision !== view.project?.revision}
              onClick={() => void r.commitChanges()}
            >
              검사한 실행본 적용
            </button>
          )}
          {r.changeState === 'ready' && change?.kind === 'restart' && (
            <button
              data-run-change-restart
              disabled={r.preparedRevision !== view.project?.revision}
              onClick={() => void r.commitChanges(true)}
            >
              실행 상태 재시작하여 적용
            </button>
          )}
          <button
            data-run-change-cancel
            disabled={!['preparing', 'ready'].includes(r.changeState)}
            onClick={() => void r.cancelChange()}
          >
            준비 취소 · 기존 실행 유지
          </button>
        </div>
        {change?.kind === 'restart' && (
          <small>
            적용 시 표정·추적 대상을 새로 시작합니다. 연결된 장치와 숨김 상태는 유지하며, 준비 실패
            시 기존 캐릭터를 계속 표시합니다.
          </small>
        )}
        {blocked && <p>저장·연속 조절·작업이 끝난 뒤 검사할 수 있습니다.</p>}
        {view.project && (
          <label>
            작업본 고개 추적 세기
            <input
              data-run-live-gain
              type="range"
              min="0"
              max="2"
              step="0.1"
              value={gain}
              onChange={(e) => tracking(Number(e.target.value))}
            />
            <output>{gain.toFixed(1)}</output>
          </label>
        )}
        <div className="edit-actions">
          <button data-run-dock-open onClick={open}>
            실행 화면·빠른 조작
          </button>
          <button data-run-dock-save disabled={!view.project || view.saving} onClick={save}>
            작업본 {view.project?.revision} 저장
          </button>
          <button data-run-dock-stop onClick={() => void r.stop()}>
            실행 중지
          </button>
        </div>
        <small>
          분석·새 파일 가져오기·큰 파일 처리는 실행을 중지한 뒤 진행하세요. 실행 중 파일 처리는
          64MiB 한도입니다.
        </small>
      </div>
    </section>
  );
}
