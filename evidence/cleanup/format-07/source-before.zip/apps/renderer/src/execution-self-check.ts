import type {
  SessionView,
  SessionCommand,
  SessionReply,
} from '../../../packages/project-session/contracts';
import { clickCommittedControl } from './ui-check-control';
import type { RunRuntime } from './run-runtime';
import { settings } from '../../../packages/expression-control';
import { defaultRunPreferences } from '../../../packages/execution';
export async function prepareExecutionKeys(host: {
  current: () => SessionView | null;
  command: (c: SessionCommand) => Promise<SessionReply>;
  settled: () => Promise<unknown>;
  runtime: RunRuntime;
}) {
  const r = host.runtime;
  await host.command({ type: 'new', name: '단축키 실제 입력 확인', sourceType: 'parts' });
  await host.command({ type: 'sample' });
  const prefs = defaultRunPreferences();
  prefs.allowGlobal = true;
  prefs.bindings.find((b) => b.action === 'hide')!.scope = 'global';
  await r.configure(prefs);
  await clickCommittedControl('[data-run-open]', host.current);
  await new Promise((resolve) => setTimeout(resolve, 150));
  await clickCommittedControl('[data-run-start]', host.current);
  const end = performance.now() + 20000;
  while (!r.active) {
    if (performance.now() > end) throw new Error('E_RUN_KEY_REVIEW');
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  document.querySelector<HTMLButtonElement>('[data-run-action=hide]')!.focus();
  await r.context(false);
  r.statuses = await window.studio.run.active(r.lease!.requestId, true);
  return {
    registered: r.statuses.find((s) => s.action === 'hide')?.state === 'registered',
    revision: r.lease!.revision,
  };
}
export async function checkExecutionUI(host: {
  current: () => SessionView | null;
  command: (c: SessionCommand) => Promise<SessionReply>;
  settled: () => Promise<unknown>;
  runtime: RunRuntime;
}) {
  const r = host.runtime,
    media = navigator.mediaDevices,
    originalGet = media.getUserMedia,
    originalEnum = media.enumerateDevices,
    originalPreferences = structuredClone(r.preferences);
  let stage = 'prepare',
    gumCalls = 0,
    completed = false;
  const routes: Record<string, unknown>[] = [],
    streams: MediaStream[] = [];
  let audio: AudioContext | null = null;
  let oscillator: OscillatorNode | null = null;
  let deny = false;
  const pause = (ms = 50) => new Promise((resolve) => setTimeout(resolve, ms)),
    verify = (v: unknown, code: string) => {
      if (!v) throw new Error(code);
    },
    current = () => host.current()!.project!;
  const until = async (fn: () => unknown) => {
    const end = performance.now() + 65000;
    while (!fn()) {
      window.editorFailureState = {
        executionStage: stage,
        state: r.state,
        error: r.errorCode,
        revision: current()?.revision,
        lease: !!r.lease,
        projectErrorCode: host.current()?.errorCode ?? null,
        splitBusy: host.current()?.split?.busy ?? false,
        splitPrepareAvailable: !!document.querySelector('[data-split-prepare]'),
        canvas: document.querySelector('[data-run-canvas]')?.getAttribute('data-run-canvas'),
      };
      if (performance.now() > end) throw new Error('E_RUN_UI_TIMEOUT');
      await pause();
    }
  };
  const click = async (selector: string) => {
    stage = selector;
    await clickCommittedControl(selector, host.current);
    await host.settled();
    if (selector === '[data-run-close]')
      await until(() => !document.querySelector('[data-run-panel]'));
    await pause();
  };
  const choose = async (mode: string) => {
    stage = 'mode:' + mode;
    await until(() => !!document.querySelector('[data-run-mode]'));
    const el = document.querySelector<HTMLSelectElement>('[data-run-mode]')!;
    el.value = mode;
    el.dispatchEvent(new Event('change', { bubbles: true }));
    await new Promise<void>((resolve) =>
      requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
    );
  };
  const key = (code: string, extra: Partial<KeyboardEventInit> = {}) =>
    document.dispatchEvent(
      new KeyboardEvent('keydown', {
        code,
        key: code,
        ctrlKey: true,
        altKey: true,
        shiftKey: true,
        bubbles: true,
        cancelable: true,
        ...extra,
      }),
    );
  Object.defineProperty(media, 'enumerateDevices', { configurable: true, value: async () => [] });
  Object.defineProperty(media, 'getUserMedia', {
    configurable: true,
    value: async () => {
      gumCalls++;
      throw new DOMException('Denied', 'NotAllowedError');
    },
  });
  try {
    await r.configure(defaultRunPreferences());
    for (const route of ['parts', 'single-image', 'split-image'] as const) {
      stage = route;
      await host.command({ type: 'new', name: '실행 검증 · ' + route, sourceType: route });
      await click('[data-step="prepare"]');
      if (route === 'parts')
        await host.command({ type: 'parts-start', expectedRevision: current().revision });
      else if (route === 'single-image') {
        await host.command({ type: 'import-image' });
        await until(() => !host.current()!.input!.busy);
        const d = host.current()!.input!.draft!;
        await host.command({
          type: 'input-apply',
          draftId: d.id,
          selection: {
            rect: { x: 0, y: 0, ...d.probe.size },
            masks: [],
            occluded: false,
            backgroundTolerance: null,
          },
        });
        await until(() => !host.current()!.input!.busy);
        await host.command({
          type: 'structure-start',
          expectedRevision: current().revision,
          completion: 'estimated',
        });
        await until(() => !host.current()!.structure!.busy);
        await host.command({ type: 'structure-apply', expectedRevision: current().revision });
      } else {
        await click('[data-split-load="example"]');
        await until(
          () => !host.current()!.split!.busy && document.querySelector('[data-split-prepare]'),
        );
        await click('[data-split-prepare]');
        await until(() => !host.current()!.split!.busy);
        await click('[data-split-apply]');
        await click('[data-split-close]');
      }
      await host.command({
        type: 'expression-edit',
        expectedRevision: current().revision,
        operation: {
          kind: 'save',
          id: null,
          name: '실행 표정',
          values: [
            {
              parameterId: current().parameters[0]!.id,
              value: current().parameters[0]!.neutral,
              locked: true,
            },
          ],
          transitionMs: 0,
          releaseMs: 100,
          release: 'live-input',
        },
      });
      const expression = current().expressions.at(-1)!;
      await host.command({
        type: 'expression-edit',
        expectedRevision: current().revision,
        operation: {
          kind: 'settings',
          value: { ...settings(current()), shortcuts: [expression.id, null, null] },
        },
      });
      const before = JSON.stringify(current()),
        dirty = host.current()!.dirty;
      await click('[data-run-open]');
      await until(() => !!document.querySelector('[data-run-start]'));
      await click('[data-run-start]');
      await until(() => r.active && document.querySelector('[data-run-canvas="ready"]'));
      verify(
        r.lease?.revision === current().revision &&
          r.lease.project !== current() &&
          Object.isFrozen(r.lease.project),
        'E_RUN_SNAPSHOT',
      );
      const canvas = document.querySelector<HTMLCanvasElement>('[data-run-canvas]')!;
      const alpha = () => Number(canvas.getAttribute('data-visible-pixels'));
      verify(alpha() > 1000, 'E_RUN_PIXELS');
      const visiblePixels = alpha();
      await click('[data-run-action="expression-1"]');
      await pause(200);
      verify(r.player.controls.snapshot().activeId === expression.id, 'E_RUN_EXPRESSION');
      await click('[data-run-action="neutral"]');
      verify(
        r.player.neutralHold && r.player.controls.snapshot().activeId === expression.id,
        'E_RUN_NEUTRAL_PRESERVES_EXPRESSION',
      );
      await click('[data-run-action="release"]');
      verify(
        r.player.neutralHold && !r.player.controls.snapshot().activeId,
        'E_RUN_RELEASE_DISTINCT',
      );
      await click('[data-run-action="hide"]');
      await pause(100);
      verify(r.hidden && alpha() === 0 && r.active, 'E_RUN_HIDE_DISTINCT');
      await click('[data-run-action="hide"]');
      await pause(100);
      verify(alpha() > 1000, 'E_RUN_SHOW');
      await click('[data-run-action="neutral"]');
      document.querySelector<HTMLButtonElement>('[data-run-action="hide"]')!.focus();
      await pause();
      key('F9');
      await pause();
      verify(r.hidden, 'E_RUN_LOCAL_KEY');
      key('F9', { repeat: true });
      verify(r.hidden, 'E_RUN_REPEAT_GUARD');
      key('F9', { isComposing: true });
      verify(r.hidden, 'E_RUN_IME_KEY_GUARD');
      document.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true }));
      key('F9');
      verify(r.hidden, 'E_RUN_COMPOSITION_GUARD');
      document.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true }));
      key('F9');
      verify(!r.hidden, 'E_RUN_COMPOSITION_END');
      await click('[data-run-settings]');
      await until(() => !!document.querySelector('[data-run-key-settings]'));
      const field = document.querySelector<HTMLInputElement>(
        '[data-run-key-settings] input:not([type="checkbox"])',
      )!;
      field.focus();
      key('F9');
      verify(!r.hidden, 'E_RUN_TEXT_KEY_EDIT_GUARD');
      await click('[data-run-keys-cancel]');
      for (let i = 0; i < 3; i++) {
        await click('[data-run-stop]');
        await until(() => r.state === 'idle');
        verify(
          !r.lease && r.camera.state === 'idle' && r.microphone.state === 'idle',
          'E_RUN_STOP_CLEANUP',
        );
        await choose(i % 2 ? 'manual' : 'automatic');
        await click('[data-run-start]');
        await until(() => r.active);
      }
      await click('[data-run-stop]');
      await until(() => r.state === 'idle');
      verify(
        JSON.stringify(current()) === before && host.current()!.dirty === dirty,
        'E_RUN_DIRTY_PRESERVED',
      );
      verify(gumCalls === 0, 'E_RUN_UNNECESSARY_DEVICE');
      await choose('camera-microphone');
      verify(
        document.querySelector<HTMLButtonElement>('[data-run-start]')!.disabled,
        'E_RUN_REQUIRED_DEVICE_BLOCK',
      );
      await click('[data-run-limited]');
      await until(() => r.state === 'limited');
      verify(gumCalls === 0, 'E_RUN_NO_DEVICE_FALLBACK');
      await click('[data-run-stop]');
      await until(() => r.state === 'idle');
      await click('[data-run-fix="camera"]');
      await until(() => !!document.querySelector('[data-camera-panel]'));
      await click('[data-camera-close]');
      await click('[data-run-open]');
      await until(() => !!document.querySelector('[data-run-start]'));
      await choose('manual');
      await r.configure({ ...r.preferences, mode: 'manual' });
      await click('[data-run-close]');
      await host.command({ type: 'save' });
      verify(!host.current()!.dirty, 'E_RUN_SAVE');
      const savedRevision = current().revision;
      await host.command({ type: 'close' });
      await click(
        '[data-recent-run="' +
          host.current()!.recent.find((x) => x.displayName === '실행 검증 · ' + route)!.id +
          '"]',
      );
      await until(() => r.active);
      verify(r.lease?.revision === savedRevision && !host.current()!.dirty, 'E_RUN_QUICK_RECENT');
      await click('[data-run-stop]');
      await until(() => r.state === 'idle');
      await click('[data-run-close]');
      routes.push({
        route,
        passed: true,
        actualRoutePreparation: true,
        visiblePixels,
        frozenRevision: true,
        distinctControls: true,
        localKeysAndIME: true,
        textAndKeyEditGuard: true,
        repeatedStarts: 4,
        noUnneededDevices: true,
        missingDeviceFallback: true,
        fixNavigation: true,
        dirtyPreserved: true,
        quickRecent: true,
      });
    }
    // Real AudioWorklet in the execution owner; synthetic source, then a denied restart.
    audio = new AudioContext();
    oscillator = audio.createOscillator();
    const gain = audio.createGain();
    gain.gain.value = 0.2;
    oscillator.connect(gain);
    oscillator.start();
    await audio.resume();
    Object.defineProperty(media, 'enumerateDevices', {
      configurable: true,
      value: async () => [
        { kind: 'audioinput', deviceId: 'execution-audio', groupId: 'fixture', label: '합성 입력' },
      ],
    });
    Object.defineProperty(media, 'getUserMedia', {
      configurable: true,
      value: async () => {
        gumCalls++;
        if (deny) throw new DOMException('Denied', 'NotAllowedError');
        const destination = audio!.createMediaStreamDestination();
        gain.connect(destination);
        streams.push(destination.stream);
        return destination.stream;
      },
    });
    await click('[data-run-open]');
    await until(() => !!document.querySelector('[data-run-start]'));
    await choose('microphone');
    await click('[data-run-refresh]');
    await pause(100);
    await click('[data-run-start]');
    await until(() => r.active && r.microphone.blocks > 2);
    const blocks = r.microphone.blocks;
    await click('[data-run-stop]');
    await until(() => r.state === 'idle');
    verify(
      streams.every((s) => s.getTracks().every((t) => t.readyState === 'ended')),
      'E_RUN_STREAM_RELEASE',
    );
    deny = true;
    await click('[data-run-start]');
    await until(() => r.state === 'failed');
    verify(
      r.errorCode === 'E_RUN_DEVICE' && !r.lease && r.microphone.state === 'idle',
      'E_RUN_FAILED_CLEANUP',
    );
    await choose('manual');
    await click('[data-run-start]');
    await until(() => r.active);
    verify(!host.current()!.dirty, 'E_RUN_FAILURE_DATA');
    completed = true;
    return {
      passed: true,
      routes,
      executionAudioWorklet: true,
      syntheticAudioBlocks: blocks,
      permissionFailureCleanup: true,
      deviceTracksReleased: true,
      devicesOpened: false,
      osGlobalKeyDelivery: 'NOT_RUN',
      physicalDevices: 'NOT_RUN',
      m0: 'HOLD',
    };
  } finally {
    if (document.querySelector('[data-run-key-settings]')) await click('[data-run-keys-cancel]');
    if (!completed) await r.stop();
    await r.configure(originalPreferences);
    streams.forEach((s) => s.getTracks().forEach((t) => t.stop()));
    oscillator?.stop();
    await audio?.close();
    Object.defineProperty(media, 'getUserMedia', { configurable: true, value: originalGet });
    Object.defineProperty(media, 'enumerateDevices', { configurable: true, value: originalEnum });
  }
}
