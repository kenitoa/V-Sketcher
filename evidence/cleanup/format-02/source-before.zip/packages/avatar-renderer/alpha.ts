/** Keep only the alpha needed for picking, rather than retaining decoded RGBA images. */
export function copyAlphaRows(
  rgba: Uint8ClampedArray,
  plane: Uint8Array,
  width: number,
  startRow: number,
): void {
  if (!Number.isInteger(width) || width < 1 || !Number.isInteger(startRow) || startRow < 0 || rgba.length % (width * 4) !== 0 || startRow * width + rgba.length / 4 > plane.length) {
    throw new Error('E_ALPHA_ROWS');
  }
  const offset = startRow * width;
  for (let index = 0; index < rgba.length / 4; index++) plane[offset + index] = rgba[index * 4 + 3]!;
}

export function alphaAt(plane: Uint8Array, width: number, height: number, u: number, v: number): number {
  const x = Math.floor(u * width), y = Math.floor(v * height);
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0 || x >= width || y >= height) return 0;
  return plane[y * width + x] ?? 0;
}

export function imageAlpha(image: HTMLImageElement): Uint8Array {
  const width = image.naturalWidth, height = image.naturalHeight;
  if (!width || !height) throw new Error('E_ALPHA_IMAGE');
  const plane = new Uint8Array(width * height);
  const scratch = document.createElement('canvas');
  scratch.width = width;
  scratch.height = Math.min(64, height);
  const context = scratch.getContext('2d', { willReadFrequently: true });
  if (!context) throw new Error('E_ALPHA_CONTEXT');
  try {
    for (let row = 0; row < height; row += scratch.height) {
      const count = Math.min(scratch.height, height - row);
      context.clearRect(0, 0, width, count);
      context.drawImage(image, 0, row, width, count, 0, 0, width, count);
      copyAlphaRows(context.getImageData(0, 0, width, count).data, plane, width, row);
    }
    return plane;
  } finally {
    scratch.width = scratch.height = 1;
  }
}
