// Only directories created by the current test run may be reclaimed.
import {existsSync,lstatSync,readdirSync,realpathSync,rmSync} from 'node:fs';
import {resolve,join,relative,isAbsolute} from 'node:path';
export const scratchNames=Object.freeze(['avatar-export-tests','broadcast-tests','correction-tests','detail-tests','editor-tests','execution-tests','expression-tests','file-output-tests','input-tests','journal-replace-tests','motion-tests','parts-tests','project-tests','runtime-change-tests','settings-tests','split-tests','structure-tests','tracking-tests']);
const snapshots=new WeakSet();
function inside(root,target){const r=relative(root,target);return !!r&&!isAbsolute(r)&&!r.split(/[\\/]/).includes('..');}
function noLinks(path){if(lstatSync(path).isSymbolicLink())return false;for(const child of readdirSync(path,{withFileTypes:true})){if(child.isSymbolicLink())return false;if(child.isDirectory()&&!noLinks(join(path,child.name)))return false;}return true;}
export function snapshotScratch(base=resolve('.local')){
 const root=realpathSync(base),allowed=resolve('.local');if(root.toLowerCase()!==resolve(base).toLowerCase()||(root.toLowerCase()!==allowed.toLowerCase()&&!inside(allowed,root)))throw Error('E_SCRATCH_ROOT');
 const snapshot=Object.freeze({root,groups:Object.freeze(scratchNames.map(name=>{const path=join(root,name);if(existsSync(path)&&(lstatSync(path).isSymbolicLink()||realpathSync(path).toLowerCase()!==path.toLowerCase()))throw Error('E_SCRATCH_LINK');return Object.freeze({name,before:Object.freeze(existsSync(path)?readdirSync(path):[])});}))});snapshots.add(snapshot);return snapshot;
}
export function cleanNewScratch(snapshot){
 if(!snapshots.has(snapshot))throw Error('E_SCRATCH_SNAPSHOT');
 const removed=[],retained=[];
 for(const group of snapshot.groups){
  if(!scratchNames.includes(group.name))throw Error('E_SCRATCH_GROUP');const parent=join(snapshot.root,group.name);if(!existsSync(parent))continue;
  if(lstatSync(parent).isSymbolicLink()||realpathSync(parent).toLowerCase()!==parent.toLowerCase())throw Error('E_SCRATCH_LINK');
  for(const entry of readdirSync(parent,{withFileTypes:true})){
   if(group.before.includes(entry.name)||!entry.isDirectory())continue;const target=join(parent,entry.name);
   if(!inside(parent,target)||!inside(snapshot.root,realpathSync(target))||!noLinks(target)){retained.push(group.name);continue;}
   rmSync(target,{recursive:true,force:false,maxRetries:3,retryDelay:100});removed.push(group.name);
  }
 }
 return {removedDirectories:removed.length,retainedUnsafeDirectories:retained.length,preexistingDirectoriesRemoved:0};
}
