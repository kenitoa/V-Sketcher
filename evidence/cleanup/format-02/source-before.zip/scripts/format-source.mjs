// Readability changes are accepted only when the parsed program stays identical.
import {readFileSync,writeFileSync,readdirSync,mkdirSync,existsSync,createWriteStream} from 'node:fs';
import {resolve,relative,join,extname} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {ZipFile} from 'yazl';

const root=resolve('.'),out=resolve(process.argv[2]??'evidence/cleanup/format-01');
if(!out.startsWith(resolve('evidence/cleanup')+'/')&&!out.startsWith(resolve('evidence/cleanup')+'\\'))throw Error('E_FORMAT_OUTPUT');
if(existsSync(out))throw Error('E_FORMAT_EXISTS');mkdirSync(out,{recursive:true});
const prettier=await import(pathToFileURL(resolve('.local/format-tools/node_modules/prettier/index.mjs')).href);
const config=JSON.parse(readFileSync('.prettierrc.json','utf8'));
const python=resolve('.venv-product/Scripts/python.exe');
const wanted=new Set(['.ts','.tsx','.js','.mjs','.cjs','.py','.css','.html']);
const files=[];
function walk(folder){for(const entry of readdirSync(folder,{withFileTypes:true})){if(entry.isSymbolicLink())throw Error('E_FORMAT_LINK');const path=join(folder,entry.name);if(entry.isDirectory()){if(entry.name!=='__pycache__'&&entry.name!=='fixtures')walk(path);}else if(wanted.has(extname(path))&&!/\.(generated\.|runtime\.(js|d\.ts)$)/.test(path))files.push(path);}}
for(const folder of ['apps','packages','worker','scripts','tools','tests'])walk(resolve(folder));
for(const name of ['forge.config.cjs','vite.config.mjs'])if(existsSync(name))files.push(resolve(name));
const hash=data=>createHash('sha256').update(data).digest('hex');
const originals=files.map(file=>({file,relative:relative(root,file).replaceAll('\\','/'),bytes:readFileSync(file)}));
const zip=new ZipFile();for(const row of originals)zip.addBuffer(row.bytes,row.relative);
await new Promise((yes,no)=>{const dest=createWriteStream(join(out,'source-before.zip'),{flags:'wx'});zip.outputStream.pipe(dest);zip.outputStream.on('error',no);dest.on('error',no);dest.on('finish',yes);zip.end();});
const ignored=new Set(['loc','range','start','end','comments','leadingComments','trailingComments','innerComments','tokens','extra','parent']);
function jsxText(text){const lines=text.split(/\r\n|\n|\r/);let last=0;for(let i=0;i<lines.length;i++)if(/[^ \t]/.test(lines[i]))last=i;let result='';for(let i=0;i<lines.length;i++){let line=lines[i].replaceAll('\t',' ');if(i)line=line.replace(/^ +/,'');if(i!==lines.length-1)line=line.replace(/ +$/,'');if(line)result+=line+(i!==last?' ':'');}return result;}
function normalized(value){
 if(Array.isArray(value))return value.map(normalized);
 if(!value||typeof value!=='object')return typeof value==='bigint'?String(value):value;
 if(value.type==='ParenthesizedExpression')return normalized(value.expression);
 if(value.type==='TSParenthesizedType')return normalized(value.typeAnnotation);
 const result={};for(const key of Object.keys(value).sort()){
  if(key.startsWith('__')||ignored.has(key)||(key==='raw'&&['Literal','JSXText'].includes(value.type)))continue;
  result[key]=value.type==='JSXText'&&key==='value'?jsxText(value[key]):normalized(value[key]);
 }return result;
}
async function jsAst(text,file){const {ast}=await prettier.__debug.parse(text,{filepath:file,...config});return hash(JSON.stringify(normalized(ast)));}
function pyAst(text){const result=spawnSync(python,['-I','scripts/python-ast.py'],{input:text,encoding:'utf8',windowsHide:true,timeout:30000});if(result.status!==0)throw Error('E_FORMAT_PYTHON_AST');return result.stdout.trim();}
const result=[];
for(const [index,row]of originals.entries()){
 const before=row.bytes.toString('utf8'),extension=extname(row.file);let after,astBefore=null,astAfter=null,status='unchanged';
 try{
  if(extension==='.py'){
   astBefore=pyAst(before);const formatted=spawnSync(python,['-I','-m','ruff','format','--stdin-filename',row.file,'--config','line-length=100','--config',"format.quote-style='single'",'-'],{input:before,encoding:'utf8',windowsHide:true,timeout:30000});
   if(formatted.status!==0)throw Error('E_FORMAT_RUFF');after=formatted.stdout;astAfter=pyAst(after);
  }else{
   if(!['.css','.html'].includes(extension))astBefore=await jsAst(before,row.file);
   after=await prettier.format(before,{filepath:row.file,...config});
   if(astBefore)astAfter=await jsAst(after,row.file);
  }
  if(astBefore&&astBefore!==astAfter){status='retained-original-ast-difference';after=before;}
  else if(after!==before){writeFileSync(row.file,after,'utf8');status='formatted';}
 }catch{status='retained-original-parser-limit';after=before;}
 result.push({file:row.relative,status,beforeSha256:hash(row.bytes),afterSha256:hash(Buffer.from(after??before)),astBefore,astAfter});
 if((index+1)%100===0)console.log('Readability review: '+(index+1)+' files');
}
writeFileSync(join(out,'format.json'),JSON.stringify({files:result,formatted:result.filter(r=>r.status==='formatted').length,astDifferencesRetained:result.filter(r=>r.status==='retained-original-ast-difference').length,parserLimitsRetained:result.filter(r=>r.status==='retained-original-parser-limit').length,historicalFilesModified:false,dependenciesOrGeneratedCodeFormatted:false},null,2)+'\n',{flag:'wx'});
console.log('Readability formatting complete; parsed-program differences retained unchanged.');
