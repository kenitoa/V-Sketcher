import test from 'node:test';
import assert from 'node:assert/strict';
import {
  mkdtempSync,
  mkdirSync,
  writeFileSync,
  existsSync,
  symlinkSync,
  readFileSync,
} from 'node:fs';
import { resolve, join } from 'node:path';
import { snapshotScratch, cleanNewScratch } from '../tools/test-scratch.mjs';
test('test cleanup retains previous files and removes only new, verified scratch directories', () => {
  const base = mkdtempSync(resolve('.local/scratch-policy-'));
  const parent = join(base, 'project-tests');
  mkdirSync(join(parent, 'previous'), { recursive: true });
  writeFileSync(join(parent, 'previous/original.txt'), 'original');
  const before = snapshotScratch(base);
  mkdirSync(join(parent, 'new'));
  writeFileSync(join(parent, 'new/generated.txt'), 'generated');
  const result = cleanNewScratch(before);
  assert.equal(result.removedDirectories, 1);
  assert.equal(existsSync(join(parent, 'new')), false);
  assert.equal(readFileSync(join(parent, 'previous/original.txt'), 'utf8'), 'original');
});
test('a new directory containing a junction cannot make cleanup traverse or remove its target', () => {
  const base = mkdtempSync(resolve('.local/scratch-policy-'));
  mkdirSync(join(base, 'project-tests'));
  const before = snapshotScratch(base);
  const outside = join(base, 'outside');
  mkdirSync(outside);
  writeFileSync(join(outside, 'keep.txt'), 'keep');
  const candidate = join(base, 'project-tests/new');
  mkdirSync(candidate);
  symlinkSync(outside, join(candidate, 'link'), 'junction');
  const result = cleanNewScratch(before);
  assert.equal(result.removedDirectories, 0);
  assert.equal(result.retainedUnsafeDirectories, 1);
  assert.equal(readFileSync(join(outside, 'keep.txt'), 'utf8'), 'keep');
});
