const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const { resolve, join } = require('node:path');
const { fork, spawn, spawnSync } = require('node:child_process');
const { createProject, editProject, readProject } = require(
  resolve('.local/test-js/packages/project-model'),
);
const { encodeBundle, decodeBundle, readBundle, sha256 } = require(
  resolve('.local/test-js/packages/project-storage/archive'),
);
const { atomicBundle } = require(resolve('.local/test-js/packages/project-storage/atomic'));
const { ProjectCatalog } = require(resolve('.local/test-js/packages/project-storage/catalog'));
const { ProjectSession } = require(resolve('.local/test-js/packages/project-session'));
const { imageProcessor } = require(resolve('.local/test-js/apps/desktop/image-processor'));
const { writeINP } = require(resolve('.local/test-js/packages/avatar-export/atomic'));
const { ZipFile } = require('yazl');
const out = resolve(process.argv[2]),
  work = resolve('.local/reliability-' + Date.now());
const results = [];
const record = (name, detail = {}) => {
  results.push({ name, passed: true, ...detail });
  console.log('Reliability: ' + name);
};
async function crash(job) {
  const config = join(job.directory, 'job.json');
  await fs.writeFile(config, JSON.stringify(job));
  const child = fork(resolve('tools/reliability-child.cjs'), [config], {
    cwd: process.cwd(),
    windowsHide: true,
    stdio: ['ignore', 'ignore', 'ignore', 'ipc'],
  });
  try {
    await new Promise((yes, no) => {
      const timer = setTimeout(() => no(Error('E_CHILD_TIMEOUT')), 20000);
      child.once('error', () => {
        clearTimeout(timer);
        no(Error('E_CHILD_START'));
      });
      child.once('message', (v) => {
        clearTimeout(timer);
        v.ready ? yes() : no(Error('E_CHILD_READY'));
      });
      child.once('exit', () => {
        clearTimeout(timer);
        no(Error('E_CHILD_EARLY_EXIT'));
      });
    });
    const ended = new Promise((r) => child.once('exit', r));
    child.kill('SIGKILL');
    await ended;
  } finally {
    if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL');
  }
}
async function zip(entries) {
  return new Promise((yes, no) => {
    const z = new ZipFile(),
      chunks = [];
    z.outputStream.on('data', (b) => chunks.push(b));
    z.outputStream.on('end', () => yes(Buffer.concat(chunks)));
    z.outputStream.on('error', no);
    for (const [name, b] of entries) z.addBuffer(b, name, { compress: false });
    z.end();
  });
}
async function altered(bundle, mutate) {
  const raw = structuredClone(bundle.project),
    m = structuredClone(bundle.manifest),
    entries = new Map(bundle.resources);
  mutate(raw, entries);
  const b = Buffer.from(JSON.stringify(raw));
  m.project.bytes = b.length;
  m.project.sha256 = sha256(b);
  entries.set('project.json', b);
  entries.set('manifest.json', Buffer.from(JSON.stringify(m)));
  return zip(entries);
}
async function main() {
  await fs.mkdir(out, { recursive: true });
  await fs.mkdir(work, { recursive: true });
  const free = await fs.statfs(work);
  assert.ok(free.bavail * free.bsize > 1024 * 1024 * 1024, 'E_TEST_SPACE_PREFLIGHT');
  const p = readProject(await fs.readFile('assets/product/preview-project.json', 'utf8')).project,
    resources = new Map();
  for (const a of p.assets)
    resources.set(
      a.id,
      await fs.readFile(join('assets/product/preview', a.fingerprint.sha256 + '.png')),
    );
  const old = await encodeBundle(p, resources, 'manual'),
    next = await encodeBundle(
      editProject(p, (d) => {
        d.displayName = 'updated';
      }),
      resources,
      'manual',
    ),
    oldHash = sha256(old);
  const target = join(work, 'normal.2dsketch');
  await fs.writeFile(target, old);
  // Real OS path and read-only replacement errors; no ACL or system setting changes.
  const invalidParent = join(work, 'not-directory');
  await fs.writeFile(invalidParent, 'file');
  await assert.rejects(
    atomicBundle(join(invalidParent, 'x.2dsketch'), next, { expectedHash: null }),
    /E_SAVE_PATH/,
  );
  assert.equal(sha256(await fs.readFile(target)), oldHash);
  record('actual-path-error-preserves-normal');
  assert.equal(
    spawnSync('attrib.exe', ['+R', target], { windowsHide: true, stdio: 'ignore' }).status,
    0,
  );
  try {
    await assert.rejects(
      atomicBundle(target, next, { expectedHash: oldHash, backup: async () => {} }),
      /E_SAVE_PERMISSION/,
    );
    assert.equal(sha256(await fs.readFile(target)), oldHash);
  } finally {
    assert.equal(
      spawnSync('attrib.exe', ['-R', target], { windowsHide: true, stdio: 'ignore' }).status,
      0,
    );
  }
  await atomicBundle(target, next, { expectedHash: oldHash, backup: async () => {} });
  await atomicBundle(join(work, 'other-location.2dsketch'), next, { expectedHash: null });
  record('actual-readonly-error-retry-and-save-as');
  for (const phase of [
    'before-write',
    'after-sync',
    'after-verify',
    'before-backup',
    'after-backup',
    'before-replace',
  ]) {
    await fs.writeFile(target, old);
    await assert.rejects(
      atomicBundle(target, next, {
        expectedHash: oldHash,
        backup: async () => {},
        fault: (p) => {
          if (p === phase) throw Object.assign(Error('not logged'), { code: 'ENOSPC' });
        },
      }),
      /E_SAVE_SPACE/,
    );
    assert.equal(sha256(await fs.readFile(target)), oldHash);
  }
  record('controlled-ENOSPC-at-six-boundaries', { physicalDiskFull: false });
  const budget = await encodeBundle(createProject('bounded', 'parts'), new Map(), 'autosave');
  const catalog = new ProjectCatalog(join(work, 'quota'), budget.length + 32);
  await catalog.init();
  const first = await catalog.record(
    createProject('bounded', 'parts'),
    new Map(),
    'autosave',
    null,
    '',
  );
  await assert.rejects(
    catalog.record(
      {
        ...createProject('bounded', 'parts'),
        projectId: first.projectId,
        displayName: 'x'.repeat(100),
      },
      new Map(),
      'checkpoint',
      null,
      '',
    ),
    /E_RECOVERY_SPACE/,
  );
  assert.equal((await readBundle(catalog.file(first.id), false)).fileHash, first.hash);
  record('actual-recovery-budget-exhaustion');
  let crashes = 0;
  for (let repeat = 0; repeat < 3; repeat++)
    for (const phase of [
      'before-write',
      'after-sync',
      'after-verify',
      'before-backup',
      'after-backup',
      'before-replace',
      'after-replace',
    ]) {
      const directory = join(work, 'save-' + repeat + '-' + phase);
      await fs.mkdir(directory);
      const target = join(directory, 'normal.2dsketch'),
        candidate = join(directory, 'next.2dsketch'),
        backup = join(directory, 'backup.2dsketch');
      await fs.writeFile(target, old);
      await fs.writeFile(candidate, next);
      await crash({ kind: 'save', directory, target, next: candidate, backup, phase });
      const b = await readBundle(target, false);
      assert.equal(b.fileHash, phase === 'after-replace' ? sha256(next) : oldHash);
      if (['after-backup', 'before-replace', 'after-replace'].includes(phase))
        assert.equal((await readBundle(backup, false)).fileHash, oldHash);
      await atomicBundle(target, next, { expectedHash: b.fileHash, backup: async () => {} });
      assert.equal((await readBundle(target, false)).fileHash, sha256(next));
      crashes++;
    }
  record('actual-process-kill-save-boundaries', { crashes, repeats: 3, powerLossTested: false });
  for (let repeat = 0; repeat < 3; repeat++) {
    const directory = join(work, 'edit-' + repeat);
    await fs.mkdir(directory);
    const target = join(directory, 'normal.2dsketch');
    await fs.writeFile(target, old);
    await crash({ kind: 'edit', directory, target });
    const s = new ProjectSession({
      dataDir: directory,
      dialogs: {
        unsaved: async () => 'discard',
        saveProject: async () => join(directory, 'restored.2dsketch'),
        openProject: async () => null,
        relinkImage: async () => null,
      },
      bundled: p,
      bundledBytes: resources,
      autoTimers: false,
    });
    try {
      await s.init();
      const rec = s.view().recoveries.find((r) => r.pending);
      assert.ok(rec);
      await s.dispatch({ type: 'recover', id: rec.id });
      assert.equal(s.view().project.displayName, 'unsaved-recoverable-edit');
      await s.save(false);
      assert.equal(sha256(await fs.readFile(target)), oldHash);
    } finally {
      await s.shutdown();
    }
  }
  record('actual-process-kill-edit-recovery', { repeats: 3 });
  const inpRoot = resolve('evidence/phase27/run-1794981764746/avatar'),
    inpOld = await fs.readFile(join(inpRoot, 'avatar-parts-v1.inp')),
    inpNew = await fs.readFile(join(inpRoot, 'avatar-parts-v2.inp'));
  for (let repeat = 0; repeat < 3; repeat++)
    for (const phase of ['before-write', 'after-sync', 'before-replace']) {
      const directory = join(work, 'export-' + repeat + '-' + phase);
      await fs.mkdir(directory);
      const target = join(directory, 'avatar.inp'),
        candidate = join(directory, 'next.inp');
      await fs.writeFile(target, inpOld);
      await fs.writeFile(candidate, inpNew);
      await crash({ kind: 'export', directory, target, next: candidate, phase });
      assert.equal(sha256(await fs.readFile(target)), sha256(inpOld));
      await writeINP(target, inpNew, sha256(inpOld), new AbortController().signal);
      assert.equal(sha256(await fs.readFile(target)), sha256(inpNew));
    }
  record('actual-process-kill-export', {
    crashes: 9,
    input: 'previously verified native INP; not new external acceptance',
  });
  const workerOut = join(work, 'analysis');
  await fs.mkdir(workerOut);
  const source = p.assets.find((a) => a.id === p.inputAssetIds[0]),
    sourceFile = resolve('assets/product/preview', source.fingerprint.sha256 + '.png');
  const child = spawn(
    resolve('.venv-product/Scripts/python.exe'),
    ['-I', '-u', resolve('worker/main.py'), '--image-input'],
    { windowsHide: true, stdio: ['pipe', 'ignore', 'ignore'] },
  );
  child.stdin.on('error', () => {});
  child.stdin.end(
    JSON.stringify({
      operation: 'probe',
      source: sourceFile,
      suffix: '.png',
      selection: null,
      output: workerOut,
    }) + '\n',
  );
  await new Promise((r) => setTimeout(r, 500));
  assert.equal(child.exitCode, null);
  const exited = new Promise((r) => child.once('exit', r));
  child.kill('SIGKILL');
  await exited;
  assert.equal(sha256(await fs.readFile(join(work, 'other-location.2dsketch'))), sha256(next));
  const processor = imageProcessor(
    resolve('.venv-product/Scripts/python.exe'),
    ['-I', '-u', resolve('worker/main.py')],
    join(work, 'analysis-retry'),
    process.env,
  );
  const probe = await processor.run(
    'probe',
    await fs.readFile(sourceFile),
    '.png',
    null,
    new AbortController().signal,
  );
  assert.ok(probe.files.has('normalized.png'));
  record('actual-analysis-worker-kill-and-real-retry', { rawUserMediaUsed: false });
  const bundle = await decodeBundle(old, false),
    asset = p.assets.find((a) => a.kind !== 'original-image');
  const missing = await altered(bundle, (_p, e) => e.delete(asset.storage.path));
  const missingPath = join(work, 'missing.2dsketch');
  await fs.writeFile(missingPath, missing);
  let relink = null;
  const repaired = join(work, 'repaired.2dsketch');
  const s = new ProjectSession({
    dataDir: join(work, 'relink'),
    dialogs: {
      unsaved: async () => 'discard',
      saveProject: async () => repaired,
      openProject: async () => null,
      relinkImage: async () => relink,
    },
    bundled: p,
    bundledBytes: resources,
    autoTimers: false,
  });
  try {
    await s.init();
    await s.openFile(missingPath);
    assert.equal(s.view().issues.length, 1);
    relink = join(work, 'moved.png');
    await fs.writeFile(relink, resources.get(asset.id));
    assert.equal((await s.dispatch({ type: 'relink', assetId: asset.id })).view.issues.length, 0);
    await s.save(false);
    assert.equal(sha256(await fs.readFile(missingPath)), sha256(missing));
    const moved = join(work, 'moved-project.2dsketch');
    await fs.rename(repaired, moved);
    const reopened = await readBundle(moved, false);
    assert.equal(reopened.issues.length, 0);
    for (const [major, minor] of [
      [2, 0],
      [1, 99],
    ]) {
      const b = await altered(bundle, (raw) => {
        raw.schemaVersion = { major, minor };
        raw.futureCanary = { preserve: true };
      });
      const file = join(work, 'future-' + major + '.2dsketch');
      await fs.writeFile(file, b);
      if (major === 2) await assert.rejects(s.openFile(file));
      else {
        await s.openFile(file);
        assert.equal(s.view().mode, 'read-only');
        await s.dispatch({ type: 'save' });
      }
      assert.equal(sha256(await fs.readFile(file)), sha256(b));
    }
    record('actual-missing-move-relink-and-future-versions');
  } finally {
    await s.shutdown();
  }
  await fs.writeFile(
    join(out, 'storage.json'),
    JSON.stringify(
      {
        passed: true,
        results,
        physicalDiskFullVerified: false,
        wholeElectronProcessKilled: false,
        ownedProductProcessesTerminated: true,
        hardwarePowerLossTested: false,
        m0: 'HOLD',
      },
      null,
      2,
    ) + '\n',
  );
}
main().catch(async () => {
  await fs.mkdir(out, { recursive: true });
  await fs.writeFile(
    join(out, 'storage-failed.json'),
    JSON.stringify(
      { passed: false, code: 'E_RELIABILITY_ASSERTION', completed: results },
      null,
      2,
    ) + '\n',
  );
  console.error('E_RELIABILITY_FAILED');
  process.exitCode = 1;
});
