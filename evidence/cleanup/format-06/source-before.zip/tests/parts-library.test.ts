import { scratchPath } from './temp';
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import {
  assertCatalog,
  combination,
  selectItem,
  removeSlot,
  adjustPart,
  linkEyes,
  resetAdjustment,
  startAssembly,
  compatible,
  type Catalog,
} from '../packages/parts-library';
import {
  assertProject,
  createProject,
  validateProject,
  readProject,
} from '../packages/project-model';
import { ProjectSession } from '../packages/project-session';
import { parseSessionCommand } from '../packages/project-session/contracts';
import { projectToPreview } from '../packages/project-model/preview';
import { activeTextures } from '../packages/editor-view';
import { capabilities } from '../packages/motion';
import { encodeBundle, sha256 } from '../packages/project-storage/archive';
const catalog = async () =>
  JSON.parse(await readFile('assets/product/parts/catalog.json', 'utf8')) as Catalog;
async function setup() {
  const c = await catalog();
  const bytes = new Map<string, Buffer>();
  for (const a of c.assets)
    bytes.set(a.id, await readFile(join('assets/product', c.files[a.fingerprint.sha256]!)));
  const r = readProject(await readFile('assets/product/preview-project.json', 'utf8'));
  if (r.mode !== 'read-write') throw new Error('fixture');
  const bundled = r.project;
  const bundledBytes = new Map<string, Buffer>();
  for (const a of bundled.assets)
    bundledBytes.set(
      a.id,
      await readFile(join('assets/product/preview', a.fingerprint.sha256 + '.png')),
    );
  await mkdir(scratchPath('parts-tests'), { recursive: true });
  const dir = await mkdtemp(scratchPath('parts-tests/run-'));
  let output = join(dir, 'parts.2dsketch');
  const s = new ProjectSession({
    dataDir: dir,
    parts: { catalog: c, bytes },
    bundled,
    bundledBytes,
    autoTimers: false,
    dialogs: {
      openProject: async () => null,
      saveProject: async () => output,
      relinkImage: async () => null,
      unsaved: async () => 'discard',
    },
  });
  await s.init();
  await s.newProject('Parts test', 'parts');
  return {
    s,
    c,
    dir,
    bundled,
    bundledBytes,
    output: (v: string) => {
      output = v;
    },
  };
}
test('T121/T123: catalog registers six pairs, unique immutable state assets and rejects incompatible family/default metadata', async () => {
  const c = await catalog();
  assertCatalog(c);
  assert.equal(c.assets.length, 27);
  assert.equal(Object.keys(c.files).length, 13);
  for (const change of [
    (v: Catalog) => {
      v.items[0]!.family = 'other';
    },
    (v: Catalog) => {
      v.defaults.mouth = 'missing';
    },
    (v: Catalog) => {
      v.items.find((i) => i.slot === 'hair')!.templates.pop();
    },
  ]) {
    const bad = structuredClone(c);
    change(bad);
    assert.throws(() => assertCatalog(bad));
  }
});
test('T121/T125/T129: all 64 real authored combinations validate and connect five controls with paired front/back hair', async () => {
  const c = await catalog();
  const options = new Set<string>();
  for (let i = 0; i < 64; i++) {
    const p = combination(c, i);
    assertProject(p);
    assert.equal(p.parameters.length, 5);
    assert.ok(capabilities(p).every((v) => v.supported));
    assert.equal(p.parts.filter((v) => v.role.startsWith('hair-')).length, 2);
    assert.equal(p.motion!.faceWidth, 344);
    assert.equal(p.motion!.maxRollDegrees, 6);
    options.add(JSON.stringify(p.assembly!.choices));
  }
  assert.equal(options.size, 64);
});
test('T127: replacing parts preserves semantic parameter IDs, expressions, input calibration settings and valid custom transform bindings', async () => {
  const c = await catalog();
  const p = combination(c, 0);
  const mouth = p.parts.find((v) => v.role === 'mouth')!;
  const param = p.parameters.find((v) => v.previewKey === 'mouth')!;
  p.partBindings.push({
    id: 'custom-mouth-roll',
    partId: mouth.id,
    parameterId: p.parameters.find((v) => v.previewKey === 'head_roll')!.id,
    kind: 'transform',
    mapping: { component: 'rotate-degrees', outputRange: [-2, 2] },
  });
  p.inputBindings.push({
    id: 'microphone-test',
    source: 'microphone',
    channel: 'rms',
    parameterId: param.id,
    inputRange: [0, 1],
    invert: false,
    gain: 1,
    offset: 0,
    smoothingMs: 120,
    fallback: { mode: 'neutral', value: 0, returnMs: 150 },
  });
  p.motion!.settings.strength = 0.8;
  p.motion!.settings.pose = [{ parameterId: param.id, value: 0.3 }];
  const ids = p.parameters.map((v) => v.id),
    expressions = structuredClone(p.expressions),
    inputs = structuredClone(p.inputBindings);
  selectItem(p, c, 'mouth-b');
  selectItem(p, c, 'eyes-b');
  selectItem(p, c, 'hair-b');
  assert.deepEqual(
    p.parameters.map((v) => v.id),
    ids,
  );
  assert.deepEqual(p.expressions, expressions);
  assert.deepEqual(p.inputBindings, inputs);
  assert.equal(p.partBindings.find((v) => v.id === 'custom-mouth-roll')!.partId, mouth.id);
  assert.equal(p.motion!.settings.strength, 0.8);
  assert.equal(p.motion!.settings.pose[0]!.value, 0.3);
});
test('T125/T127: removal disables unavailable motion, reports lost bindings and reattaches eyes to retained expression/input parameters', async () => {
  const c = await catalog();
  const p = combination(c, 0);
  const ids = p.parameters.map((v) => v.id);
  removeSlot(p, c, 'eyes');
  assert.ok(!p.parts.some((v) => v.role === 'eye'));
  assert.equal(capabilities(p).find((v) => v.key === 'eye_left')!.supported, false);
  assert.ok(p.assembly!.warnings.length);
  selectItem(p, c, 'eyes-a');
  assert.ok(capabilities(p).every((v) => v.supported));
  assert.deepEqual(
    p.parameters.map((v) => v.id),
    ids,
  );
});
test('T126: transform/color bounds, mirrored linked eyes, independent editing and selected/all reset preserve choices', async () => {
  const c = await catalog();
  const p = combination(c, 0);
  const v = { key: 'eye-left', x: 2, y: 1, scale: 1.03, rotation: 1, hue: 18 };
  adjustPart(p, c, v);
  assert.deepEqual(
    p.assembly!.adjustments.find((a) => a.key === 'eye-right'),
    { ...v, key: 'eye-right', x: -2, rotation: -1 },
  );
  linkEyes(p, c, false, 'eye-left');
  adjustPart(p, c, { ...v, key: 'eye-right', x: 1 });
  assert.equal(p.assembly!.adjustments.find((a) => a.key === 'eye-left')!.x, 2);
  linkEyes(p, c, true, 'eye-right');
  assert.equal(p.assembly!.adjustments.find((a) => a.key === 'eye-left')!.x, -1);
  for (const bad of [
    { ...v, x: 3 },
    { ...v, hue: 19 },
    { ...v, scale: NaN },
  ])
    assert.throws(() => adjustPart(p, c, bad));
  const choices = structuredClone(p.assembly!.choices);
  resetAdjustment(p, c, 'eye-left');
  assert.ok(p.assembly!.adjustments.every((a) => a.x === 0));
  resetAdjustment(p, c, null);
  assert.equal(p.assembly!.adjustments.length, 0);
  assert.deepEqual(p.assembly!.choices, choices);
});
test('T123/T126: persisted library/color/assembly and middle-state references reject malformed values and old schema misuse', async () => {
  const p = combination(await catalog(), 0);
  for (const mutate of [
    (v: typeof p) => {
      v.parts[0]!.color!.hueDegrees = 20;
    },
    (v: typeof p) => {
      v.assembly!.choices.pop();
    },
    (v: typeof p) => {
      v.schemaVersion.minor = 2;
    },
    (v: typeof p) => {
      const b = v.partBindings[0]!;
      if (b.kind === 'state-blend') b.mapping.middleState = 'missing';
    },
  ]) {
    const bad = structuredClone(p);
    mutate(bad);
    assert.ok(validateProject(bad).length);
  }
  assert.throws(() =>
    parseSessionCommand({
      type: 'parts-select',
      expectedRevision: 0,
      itemId: 'hair-a',
      path: 'private',
    }),
  );
  assert.throws(() =>
    parseSessionCommand({ type: 'parts-adjust', expectedRevision: NaN, value: {} }),
  );
});
test('T128/T130: actual cache/ZIP/save/duplicate/reopen preserve composition, adjustments, resources and source project', async () => {
  const { s, c, dir, output } = await setup();
  await s.dispatch({ type: 'parts-start', expectedRevision: s.view().project!.revision });
  assert.equal(s.view().errorCode, null);
  await s.dispatch({
    type: 'parts-adjust',
    expectedRevision: s.view().project!.revision,
    value: { key: 'hair-front', x: 1, y: 1, scale: 1.005, rotation: 0.25, hue: 6 },
  });
  for (const a of c.assets) assert.equal(sha256((await s.cache.read(a))!), a.fingerprint.sha256);
  await s.save(false);
  const before = sha256(await readFile(join(dir, 'parts.2dsketch')));
  const assembly = structuredClone(s.view().project!.assembly);
  const id = s.view().project!.projectId;
  output(join(dir, 'parts-copy.2dsketch'));
  await s.dispatch({ type: 'duplicate' });
  assert.notEqual(s.view().project!.projectId, id);
  assert.deepEqual(s.view().project!.assembly, assembly);
  await s.openFile(join(dir, 'parts.2dsketch'));
  assert.deepEqual(s.view().project!.assembly, assembly);
  assert.equal(sha256(await readFile(join(dir, 'parts.2dsketch'))), before);
  await s.shutdown();
});
test('T119/T125/T127: actual checkpoint and undo/redo restore original premium parts and mappings together', async () => {
  const { s } = await setup();
  await s.dispatch({ type: 'sample' });
  const before = structuredClone(s.view().project!);
  await s.dispatch({ type: 'parts-start', expectedRevision: before.revision });
  assert.equal(s.view().errorCode, null);
  assert.ok(s.view().recoveries.length);
  await s.dispatch({ type: 'undo' });
  assert.equal(s.view().project!.assembly, undefined);
  assert.deepEqual(s.view().project!.parts, before.parts);
  assert.deepEqual(s.view().project!.partBindings, before.partBindings);
  await s.dispatch({ type: 'redo' });
  assert.ok(s.view().project!.assembly);
  assert.ok(before.assets.every((a) => s.view().project!.assets.some((v) => v.id === a.id)));
  await s.shutdown();
});
test('T124/T125: required face, unknown choice and incompatible saved version are blocked without changing a valid composition', async () => {
  const c = await catalog();
  const p = combination(c, 0);
  const before = JSON.stringify(p);
  assert.throws(() => removeSlot(p, c, 'face'));
  assert.throws(() => selectItem(p, c, 'unknown'));
  assert.equal(JSON.stringify(p), before);
  const altered = structuredClone(p);
  altered.assets[0]!.sourceToEdited[4] += 1;
  assert.ok(compatible(altered, c, c.items[0]!));
  assert.throws(() => selectItem(altered, c, 'face-a'));
  p.assembly!.version = '9.0.0';
  assert.ok(compatible(p, c, c.items[0]!));
  const saved = JSON.stringify(p);
  assert.throws(() => selectItem(p, c, 'face-a'));
  assert.equal(JSON.stringify(p), saved);
});
test('T103/T123: shared atlas state URLs stay distinct and intermediate eye/mouth drawings are actually selected at 0.5', async () => {
  const c = await catalog();
  const p = combination(c, 0);
  const scene = projectToPreview(p);
  for (const key of ['eye_left', 'eye_right', 'mouth'] as const) {
    const layer = scene.layers.find((v) => v.bind === key)!;
    assert.equal(new Set(Object.values(layer.states)).size, 3);
    assert.equal(Object.keys(layer.geometry!).length, 3);
    const weights = activeTextures(layer, { [key]: 0.5 });
    assert.equal(weights.find((v) => v[0] === layer.states.middle)![1], 1);
    assert.ok(layer.color);
  }
});
test('T120/T125: stale revision during actual resource preparation cannot apply parts over a newer manual edit', async () => {
  const { s } = await setup();
  let release!: () => void, entered!: () => void;
  const gate = new Promise<void>((r) => {
      release = r;
    }),
    ready = new Promise<void>((r) => {
      entered = r;
    });
  const put = s.cache.put.bind(s.cache);
  let held = false;
  s.cache.put = async (a, b) => {
    if (!held) {
      held = true;
      entered();
      await gate;
    }
    await put(a, b);
  };
  const pending = s.dispatch({ type: 'parts-start', expectedRevision: s.view().project!.revision });
  await ready;
  await s.dispatch({
    type: 'edit',
    target: 'project-name',
    id: null,
    parameterId: null,
    value: 'Manual edit kept',
    expectedRevision: s.view().project!.revision,
    groupId: null,
  });
  release();
  const result = await pending;
  assert.equal(result.view.errorCode, 'E_EDIT_STALE');
  assert.equal(s.view().project!.assembly, undefined);
  assert.equal(s.view().project!.displayName, 'Manual edit kept');
  await s.shutdown();
});
test('T110/T125: legacy 1.2 upgrades to a protected copy and unrelated input occlusion does not narrow the new authored rig', async () => {
  const { s, c, dir, bundled, bundledBytes, output } = await setup();
  const legacy = structuredClone(bundled);
  legacy.schemaVersion.minor = 2;
  legacy.provenance.limitations = ['OCCLUDED_USER_REPORTED'];
  const file = join(dir, 'legacy.2dsketch');
  await writeFile(file, await encodeBundle(legacy, bundledBytes, 'manual'));
  await s.openFile(file);
  const digest = sha256(await readFile(file));
  await s.dispatch({ type: 'parts-start', expectedRevision: s.view().project!.revision });
  assert.equal(s.view().project!.schemaVersion.minor, 3);
  assert.equal(s.view().project!.motion!.maxRollDegrees, 6);
  output(file);
  await assert.rejects(s.save(false), /E_SAVE_MIGRATION_TARGET/);
  output(join(dir, 'converted.2dsketch'));
  await s.save(false);
  assert.equal(sha256(await readFile(file)), digest);
  assert.ok(compatible(s.view().project!, c, c.items[0]!) === null);
  await s.shutdown();
});
