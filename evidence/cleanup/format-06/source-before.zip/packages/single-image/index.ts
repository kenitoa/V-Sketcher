import { assertSimpleSafe } from '../detail-editor/model';
import { randomUUID } from 'node:crypto';
import { assertProject, type Project, type Asset, type CharacterPart } from '../project-model';
import { authorRig, KEYS } from '../motion';
import { sha256 } from '../project-storage/archive';
import { assertReport, type StructureReport } from './types';
export * from './types';
export function structuredProject(
  input: Project,
  report: StructureReport,
  files: ReadonlyMap<string, Buffer>,
  early = false,
): { project: Project; bytes: Map<string, Buffer> } {
  assertSimpleSafe(input);
  assertReport(report);
  const p = structuredClone(input);
  const preparation = p.inputPreparation;
  if (!preparation || p.sourceType !== 'single-image' || report.status === 'failed' || !report.face)
    throw new Error('E_INPUT_STRUCTURE_FACE');
  const source = p.assets.find((a) => a.id === preparation.selectedAssetId)!;
  if (!source) throw new Error('E_INPUT_STRUCTURE_SOURCE');
  const w = p.canvas.width,
    h = p.canvas.height;
  for (const r of [report.face, ...report.regions.map((v) => v.rect)])
    if (r.x + r.width > w || r.y + r.height > h) throw new Error('E_INPUT_STRUCTURE_REPORT');
  p.schemaVersion.minor = Math.max(4, p.schemaVersion.minor);
  delete p.assembly;
  p.groups = [];
  p.parts = [];
  p.partBindings = [];
  delete p.motion;
  p.structure = {
    version: 1,
    inputAssetId: source.id,
    inputRevision: input.revision,
    configurationVersion: '1.0.0',
    report: structuredClone(report),
  };
  const bytes = new Map<string, Buffer>();
  const asset = (name: string, dimensions: Asset['dimensions'], origin: Asset['origin']): Asset => {
    const data = files.get(name);
    if (!data) throw new Error('E_INPUT_STRUCTURE_FILES');
    const digest = sha256(data);
    const a: Asset = {
      ...structuredClone(source),
      id: randomUUID(),
      kind: origin === 'auto-completion' ? 'supplement-image' : 'part-texture',
      origin,
      parentAssetIds: [source.id],
      storage: { path: `resources/${digest}.png` },
      fingerprint: { sha256: digest, bytes: data.length },
      dimensions,
      sourceRegion: { x: 0, y: 0, ...dimensions },
      sourceToEdited: [1, 0, 0, 1, 0, 0],
      producer: { name: 'single-image-structure', version: '1.0.0' },
    };
    p.assets.push(a);
    bytes.set(a.id, data);
    return a;
  };
  const part = (
    key: string,
    role: CharacterPart['role'],
    side: CharacterPart['side'],
    x: number,
    y: number,
    textures: CharacterPart['textures'],
    z: number,
  ): CharacterPart => ({
    id: randomUUID(),
    displayName: key,
    role,
    side,
    parentId: null,
    groupId: null,
    textures,
    localTransform: [1, 0, 0, 1, x, y],
    drawOrder: z,
    visible: true,
    opacity: 1,
    correctionOrigin: 'automatic',
    limitations:
      role === 'base'
        ? ['Hair/body remain a composite; no independent hidden-surface separation']
        : ['Estimated expression; confirm before larger motion'],
  });
  const texture = (a: Asset, state: string) => ({
    state,
    assetId: a.id,
    assetVersion: a.version,
    assetToLocal: [1, 0, 0, 1, 0, 0] as [number, number, number, number, number, number],
  });
  const base = early
    ? source
    : asset('structure-base.png', { width: w, height: h }, 'auto-completion');
  p.parts.push(
    part('캐릭터 원화 · 제한 고개', 'base', 'center', 0, 0, [texture(base, 'default')], 0),
  );
  for (const key of KEYS)
    if (!p.parameters.some((v) => v.previewKey === key))
      p.parameters.push({
        id: randomUUID(),
        displayName: key,
        semantic: key,
        unit: 'ratio',
        min: key.startsWith('head') ? -1 : 0,
        neutral: key.startsWith('eye') ? 1 : 0,
        max: 1,
        previewKey: key,
      });
  if (!early)
    for (const r of report.regions.filter((v) => v.enabled)) {
      const first = r.key === 'mouth' ? 'closed' : 'open',
        second = first === 'closed' ? 'open' : 'closed';
      const a = asset(
          `structure-${r.key}-${first}.png`,
          { width: r.rect.width, height: r.rect.height },
          'auto-preparation',
        ),
        b = asset(
          `structure-${r.key}-${second}.png`,
          { width: r.rect.width, height: r.rect.height },
          'auto-completion',
        );
      const v = part(
        r.key === 'mouth'
          ? '입 · 추정 열기'
          : r.key === 'eye_left'
            ? '왼쪽 눈 · 추정 감기'
            : '오른쪽 눈 · 추정 감기',
        r.key === 'mouth' ? 'mouth' : 'eye',
        r.key === 'mouth' ? 'center' : r.key === 'eye_left' ? 'character-left' : 'character-right',
        r.rect.x,
        r.rect.y,
        [texture(a, first), texture(b, second)],
        10,
      );
      p.parts.push(v);
      p.partBindings.push({
        id: randomUUID(),
        partId: v.id,
        parameterId: p.parameters.find((v) => v.previewKey === r.key)!.id,
        kind: 'state-blend',
        mapping: { minimumState: 'closed', maximumState: 'open' },
      });
    }
  p.provenance = {
    preparation: early
      ? 'Early preview: face ready; expression patches still preparing'
      : 'Single image automatic structure v1; original pixels and estimated expressions',
    limitations: [
      ...report.warnings,
      ...report.unconfirmed.map((v) => 'UNCONFIRMED:' + v),
      'Unseen surfaces not restored; small planar motion only',
    ],
  };
  p.motion = authorRig(p);
  p.motion.maxRollDegrees = report.maxRollDegrees;
  const ratio = report.face.width / p.motion.faceWidth;
  p.motion.faceWidth = report.face.width;
  for (const m of p.motion.meshes)
    for (const v of m.vertices) {
      v.minimum = [v.minimum[0] * ratio, v.minimum[1] * ratio];
      v.maximum = [v.maximum[0] * ratio, v.maximum[1] * ratio];
    }
  p.runtimeProfile = { ...p.runtimeProfile, mode: 'idle', fallbackExpressionId: null };
  for (const e of p.exportProfiles) e.parameterMap = [];
  if (!p.expressions.length)
    p.expressions = [
      {
        id: randomUUID(),
        displayName: '기본',
        values: p.parameters.map((v) => ({ parameterId: v.id, value: v.neutral, locked: false })),
        transitionMs: 150,
        release: 'live-input',
      },
    ];
  assertProject(p);
  return { project: p, bytes };
}
