import { referenceIssue } from '../expression-control';
import { separabilityError } from '../avatar-export/geometry';
import { createHash, randomUUID } from 'node:crypto';
import { validateProject, type Project } from '../project-model';
import { partIsVisible, partOpacity } from '../project-model/geometry';
import { projectToPreview } from '../project-model/preview';
import { transform } from '../coordinates';
import {
  CHECKER_VERSION,
  CONVERTER_VERSION,
  TARGET_ID,
  TARGETS,
  assertTargetOptions,
  type CheckIssue,
  type CheckResult,
  type TargetOptions,
  type ConversionCopy,
} from './types';
import type { InputBasis } from '../execution/changes';
const hash = (v: unknown) => createHash('sha256').update(JSON.stringify(v)).digest('hex');
export function inspectCompatibility(
  project: Project,
  basis: InputBasis,
  options: TargetOptions,
  available: ReadonlySet<string>,
  scene: CheckResult['scene'] = null,
): CheckResult {
  assertTargetOptions(options);
  const issues: CheckIssue[] = [];
  const add = (
    code: string,
    severity: CheckIssue['severity'],
    category: CheckIssue['category'],
    subjectId: string | null,
    message: string,
    impact: string,
    alternative: string,
    fix: CheckIssue['fix'] = null,
  ) =>
    issues.push({
      id: hash([code, subjectId, message]),
      code,
      severity,
      category,
      subjectId,
      message,
      impact,
      alternative,
      fix,
    });
  const invalid = validateProject(project);
  for (const item of invalid) {
    const match = /^\/(parts|parameters|partBindings|groups)\/(\d+)/.exec(item.location);
    const collection = match?.[1] as 'parts' | 'parameters' | 'partBindings' | 'groups' | undefined;
    const entry = collection ? project[collection][Number(match![2])] : undefined;
    const kind =
      collection === 'parts'
        ? 'part'
        : collection === 'parameters'
          ? 'parameter'
          : collection === 'partBindings'
            ? 'binding'
            : 'group';
    add(
      'MODEL_' + item.code,
      'block',
      'structure',
      entry?.id ?? null,
      '프로젝트 참조 또는 구조가 올바르지 않습니다.',
      '필수 부위·값이 누락될 수 있어 변환을 차단합니다.',
      '연결과 범위를 수정하고 다시 검사하세요.',
      entry ? { kind, id: entry.id } : null,
    );
  }
  if (!project.parts.length)
    add(
      'NO_PARTS',
      'block',
      'structure',
      null,
      '표시할 부위가 없습니다.',
      '빈 아바타가 생성됩니다.',
      '그림이나 파츠를 준비하세요.',
    );
  const target = TARGETS[0];
  if (project.parts.length > target.maxParts)
    add(
      'PART_LIMIT',
      'block',
      'structure',
      null,
      '초기 변환 어댑터의 64부위 한도를 넘습니다.',
      '자동으로 부위를 버리지 않습니다.',
      '구조를 검토하거나 후속 어댑터를 사용하세요.',
    );
  const used = new Set(project.parts.flatMap((p) => p.textures.map((t) => t.assetId)));
  let decoded = 0;
  for (const part of project.parts) {
    if (!part.textures.length)
      add(
        'PART_TEXTURE',
        'block',
        'resource',
        part.id,
        '부위 그림이 없습니다.',
        '외형을 잃을 수 있습니다.',
        '그림을 연결하세요.',
        { kind: 'part', id: part.id },
      );
    if (
      !part.displayName.trim() ||
      /[\\/:*?"<>|\x00-\x1f]/.test(part.displayName) ||
      part.displayName.normalize('NFC') !== part.displayName
    )
      add(
        'NODE_NAME',
        'warning',
        'conversion',
        part.id,
        '대상용 부위 이름을 정규화합니다.',
        '원본 이름은 유지하고 변환 사본에 안전한 고유 이름을 붙입니다.',
        '변환 사본의 이름을 확인하세요.',
        { kind: 'part', id: part.id },
      );
    if (part.color)
      add(
        'COLOR_BAKE',
        'warning',
        'conversion',
        part.id,
        '부위 색상 조절의 대상 텍스처 굽기가 필요합니다.',
        '색상을 생략하면 원화가 달라져 차단합니다.',
        '색상과 알파를 별도 내장 텍스처로 굽습니다. 필터 경계의 샘플링 차이를 변환 미리보기에서 확인하세요.',
        { kind: 'part', id: part.id },
      );
  }
  if (used.size > target.maxTextures)
    add(
      'TEXTURE_COUNT',
      'block',
      'resource',
      null,
      '초기 어댑터의 128텍스처 한도를 넘습니다.',
      '초과 텍스처를 버리지 않습니다.',
      '텍스처 구조를 검토하세요.',
    );
  for (const id of used) {
    const asset = project.assets.find((a) => a.id === id);
    if (!asset) {
      add(
        'ASSET_REFERENCE',
        'block',
        'resource',
        id,
        '그림 참조를 찾을 수 없습니다.',
        '필수 외형이 누락됩니다.',
        '해당 부위에 그림을 다시 연결하세요.',
      );
      continue;
    }
    if (!available.has(id))
      add(
        'ASSET_MISSING',
        'block',
        'resource',
        id,
        '그림 파일의 내용 또는 해시를 확인하지 못했습니다.',
        '누락·손상 파일은 묶지 않습니다.',
        '그림 파일을 다시 연결하고 검사하세요.',
        project.parts.find((p) => p.textures.some((t) => t.assetId === id))
          ? {
              kind: 'part',
              id: project.parts.find((p) => p.textures.some((t) => t.assetId === id))!.id,
            }
          : null,
      );
    decoded += asset.dimensions.width * asset.dimensions.height * 4;
    if (Math.max(asset.dimensions.width, asset.dimensions.height) > target.maxTextureEdge)
      add(
        'TEXTURE_SIZE',
        'block',
        'resource',
        id,
        '4096px를 넘는 그림은 초기 어댑터 범위 밖입니다.',
        '품질을 조용히 낮추지 않습니다.',
        '별도 사본으로 크기를 검토하세요.',
      );
    if (asset.colorSpace !== 'srgb')
      add(
        'COLOR_SPACE',
        'block',
        'resource',
        id,
        '그림 색 공간을 확정할 수 없습니다.',
        '변환 후 색 차이를 보장하지 못합니다.',
        'sRGB 원본을 준비하세요.',
      );
  }
  if (decoded > target.decodedBytes)
    add(
      'TEXTURE_BUDGET',
      'block',
      'resource',
      null,
      '합산 디코드 RGBA 256MiB 한도를 넘습니다.',
      '원화를 자동 축소하거나 누락하지 않습니다.',
      '부위와 그림 구성을 검토하세요.',
    );
  const names = new Set<string>(),
    sources = new Set<string>();
  for (const mapping of options.parameterMap) {
    if (
      !project.parameters.some((p) => p.id === mapping.parameterId) ||
      sources.has(mapping.parameterId) ||
      names.has(mapping.targetName.toLocaleLowerCase())
    )
      add(
        'PARAMETER_MAP',
        'block',
        'parameter',
        mapping.parameterId,
        '매개변수 연결이 없거나 이름이 중복됩니다.',
        '다른 제어로 덮어쓸 수 있어 차단합니다.',
        '대상 이름과 연결을 수정하세요.',
        project.parameters.some((p) => p.id === mapping.parameterId)
          ? { kind: 'parameter', id: mapping.parameterId }
          : null,
      );
    sources.add(mapping.parameterId);
    names.add(mapping.targetName.toLocaleLowerCase());
  }
  for (const key of ['eye_left', 'eye_right', 'mouth', 'head_yaw', 'head_roll']) {
    const p = project.parameters.find((p) => p.previewKey === key);
    if (!p) {
      add(
        'CORE_PARAMETER',
        'block',
        'parameter',
        null,
        `${key} 기본 제어가 없습니다.`,
        '필수 눈·입·고개 기능을 생략할 수 없습니다.',
        '움직임 연결을 준비하세요.',
      );
      continue;
    }
    if (!options.parameterMap.some((m) => m.parameterId === p.id))
      add(
        'CORE_MAP',
        'block',
        'parameter',
        p.id,
        '기본 제어의 대상 연결이 없습니다.',
        '핵심 동작 손실을 막기 위해 차단합니다.',
        '이 매개변수에 대상 이름을 지정하세요.',
        { kind: 'parameter', id: p.id },
      );
    if (
      !project.partBindings.some((b) => b.parameterId === p.id) &&
      !project.motion?.meshes.some((m) => m.yawParameterId === p.id || m.rollParameterId === p.id)
    )
      add(
        'CORE_BINDING',
        'block',
        'parameter',
        p.id,
        '기본 제어가 부위에 연결되지 않았습니다.',
        '움직이지 않는 제어가 생성됩니다.',
        '부위 연결을 수정하세요.',
        { kind: 'parameter', id: p.id },
      );
  }
  for (const p of project.parameters) {
    if (
      !Number.isFinite(p.min) ||
      (!(p.min < p.neutral && p.neutral < p.max) && p.previewKey?.startsWith('head')) ||
      p.min >= p.max
    )
      add(
        'PARAMETER_RANGE',
        'block',
        'parameter',
        p.id,
        '대상 매개변수 범위를 만들 수 없습니다.',
        '정규화 분모가 유효하지 않습니다.',
        '최소·중립·최대 범위를 수정하세요.',
        { kind: 'parameter', id: p.id },
      );
    if (!options.parameterMap.some((m) => m.parameterId === p.id))
      add(
        'UNMAPPED_PARAMETER',
        'block',
        'parameter',
        p.id,
        '매개변수의 대상 이름이 빠졌습니다.',
        '사용자 제어를 임의로 버리지 않습니다.',
        '명시적인 대상 이름을 지정하세요.',
        { kind: 'parameter', id: p.id },
      );
  }
  for (const e of project.expressions) {
    for (const v of e.values) {
      const p = project.parameters.find((p) => p.id === v.parameterId);
      if (!p || v.value < p.min || v.value > p.max)
        add(
          'EXPRESSION_REFERENCE',
          'block',
          'expression',
          e.id,
          '표정 값 또는 참조가 손상됐습니다.',
          '표정을 조용히 제외하지 않습니다.',
          '표정·입력 제어 화면에서 연결과 값을 수정하세요.',
          p ? { kind: 'parameter', id: p.id } : null,
        );
      if (referenceIssue(project, v))
        add(
          'EXPRESSION_SCOPE',
          'block',
          'expression',
          e.id,
          '부위 한정 표정의 대상 재현 검증이 필요합니다.',
          '끊기거나 변경된 표정을 조용히 제외하지 않습니다.',
          '표정 화면에서 다시 연결/제거를 검토한 뒤 재검사하세요.',
        );
    }
  }
  if (project.expressions.length)
    add(
      'EXPRESSION_POLICY',
      'warning',
      'expression',
      null,
      '표정 이름·값·잠금/해제 정책을 대상 프로필에서 다시 확인해야 합니다.',
      '로컬 카메라/마이크 설정과 전역 키는 자동 이전하지 않습니다.',
      '표정은 대상 애니메이션으로 옮깁니다. 입력 잠금/해제 우선순위는 대상에서 확인하세요.',
    );
  if (project.motion?.meshes.length)
    add(
      'SAMPLED_DEFORMATION',
      'warning',
      'conversion',
      null,
      '망 곡선을 65개 이상 키점으로 변환합니다.',
      '키점 사이는 대상의 선형 보간입니다. 원래 망과 가중치를 사용하며 평면 이동/회전으로 대체하지 않습니다.',
      '변환된 움직임 미리보기를 확인한 뒤 이 검사 범위에 동의하세요.',
    );
  let preview = scene;
  try {
    preview ??= projectToPreview(project);
  } catch {
    if (!invalid.length)
      add(
        'SCENE_MAPPING',
        'block',
        'conversion',
        null,
        '대상 검토용 장면을 구성하지 못했습니다.',
        '미리보기나 변환 사본을 만들 수 없는 입력은 통과로 표시하지 않습니다.',
        '그림의 알파 모드·연결·구조를 확인하세요.',
      );
  }
  for (const layer of preview?.layers ?? []) {
    if (layer.stateBlend === 'interpolate')
      add(
        'STATE_QUANTIZATION',
        'warning',
        'conversion',
        layer.id,
        '눈·입 픽셀 보간을 실제 중간 텍스처 65단계로 변환합니다.',
        '가장 가까운 상태로 전환하므로 연속 보간과 최대 약 1/128 입력 차이가 있습니다. 불투명도 교차로 알파를 바꾸지 않습니다.',
        '움직임 미리보기에서 확인하고 경고 범위에 동의하거나 원래 앱 내 실행을 사용하세요.',
        { kind: 'part', id: layer.id },
      );
    if (separabilityError(layer) > 0.02)
      add(
        'COUPLED_DEFORM',
        'block',
        'conversion',
        layer.id,
        '여러 변환의 교차 항을 현재 대상의 가산 망 연결로 보존할 수 없습니다.',
        '이 조합을 단순 변형으로 바꾸지 않고 내보내기를 차단합니다.',
        '해당 연결을 검토하거나 앱 내 실행을 사용하세요.',
        { kind: 'part', id: layer.id },
      );
  }
  for (const p of project.parameters)
    if (!p.previewKey)
      add(
        'CUSTOM_PARAMETER',
        'block',
        'parameter',
        p.id,
        '현재 변환기는 다섯 공통 제어만 변환합니다.',
        '사용자 매개변수를 버리지 않고 차단합니다.',
        '연결과 대상 지원 범위를 검토하세요.',
        { kind: 'parameter', id: p.id },
      );
  const copy: ConversionCopy = {
    version: 1,
    parts: [],
    parameters: [],
    textures: [],
    bindings: [],
    expressions: [],
    changes: [
      '별도 변환 검토 사본 · 원본 수정 없음',
      '중심 원점·반대 z·32비트 정수 UUID·안전한 내장 파일 이름',
    ],
  };
  if (!invalid.length && preview) {
    const all = structuredClone(project);
    for (const p of all.parts) p.visible = true;
    for (const g of all.groups) g.visible = true;
    const allScene = projectToPreview(all);
    const uuid = new Map<string, number>();
    let next = 1;
    for (const part of project.parts) uuid.set(part.id, next++);
    for (const p of project.parameters) uuid.set(p.id, next++);
    for (const layer of allScene.layers) {
      const part = project.parts.find((p) => p.id === layer.id)!;
      const mesh = layer.mesh;
      const points =
        mesh?.vertices.map((v) => v.position) ??
        (() => {
          const path = Object.values(layer.states)[0]!,
            g = layer.geometry?.[path];
          if (!g) return [] as [number, number][];
          const r = g.crop;
          return [
            [r.x, r.y],
            [r.x + r.width, r.y],
            [r.x + r.width, r.y + r.height],
            [r.x, r.y + r.height],
          ].map(([x, y]) => {
            const p = transform(g.matrix, { x: x!, y: y! });
            return [p.x, p.y] as [number, number];
          });
        })();
      copy.parts.push({
        sourceId: part.id,
        sourceName: part.displayName,
        parentSourceId: part.parentId,
        enabled: partIsVisible(project, part),
        opacity: partOpacity(project, part),
        uuid: uuid.get(part.id)!,
        name: 'part_' + String(uuid.get(part.id)).padStart(3, '0'),
        z: -layer.z,
        vertices: points.map((v) => [
          v[0] - project.canvas.width / 2,
          v[1] - project.canvas.height / 2,
        ]),
        indices: mesh ? [...mesh.triangles] : [0, 1, 2, 0, 2, 3],
      });
    }
    for (const p of project.parameters)
      copy.parameters.push({
        sourceId: p.id,
        uuid: uuid.get(p.id)!,
        name: options.parameterMap.find((m) => m.parameterId === p.id)?.targetName ?? 'unmapped',
        min: p.min,
        neutral: p.neutral,
        max: p.max,
      });
    for (const a of project.assets.filter((a) => used.has(a.id)))
      copy.textures.push({
        sourceId: a.id,
        name: `textures/${a.fingerprint.sha256}.png`,
        sha256: a.fingerprint.sha256,
        operation:
          a.mediaType === 'image/jpeg'
            ? 'jpeg-to-png-premultiply'
            : a.alphaMode === 'straight'
              ? 'straight-to-premultiplied'
              : 'copy',
      });
    for (const b of project.partBindings)
      copy.bindings.push({
        nodeUUID: uuid.get(b.partId)!,
        parameterUUID: uuid.get(b.parameterId)!,
        kind: b.kind,
        mapping: structuredClone(b.mapping),
      });
    for (const e of project.expressions)
      copy.expressions.push({
        sourceId: e.id,
        name: e.displayName,
        transitionMs: e.transitionMs,
        release: e.release,
        releaseMs: e.releaseMs ?? 0,
        values: e.values.map((v) => ({
          parameterUUID: uuid.get(v.parameterId) ?? 0,
          value: v.value,
          locked: v.locked,
        })),
      });
  }
  if (copy.textures.some((t) => t.operation !== 'copy'))
    add(
      'TEXTURE_ENCODING',
      'warning',
      'conversion',
      null,
      '대상용 PNG·premultiplied alpha 변환이 필요합니다.',
      '변환 준비 시 실제 PNG를 굽고 INP에 내장합니다.',
      '변환된 움직임과 대상의 실제 구동을 확인하세요.',
    );
  const signature = hash({
    basis,
    options,
    target: TARGETS[0],
    converter: CONVERTER_VERSION,
    checker: CHECKER_VERSION,
  });
  const warningScope = hash(issues.filter((i) => i.severity === 'warning'));
  return {
    id: randomUUID(),
    basis,
    targetId: TARGET_ID,
    targetVersion: '0.8.7',
    converterVersion: CONVERTER_VERSION,
    checkerVersion: CHECKER_VERSION,
    signature,
    status: issues.some((i) => i.severity === 'block')
      ? 'BLOCKED'
      : issues.length
        ? 'WARNING'
        : 'PASS',
    issues,
    warningScope,
    acknowledged: false,
    copy: invalid.length ? null : copy,
    scene: preview,
    settings: structuredClone(options),
  };
}
