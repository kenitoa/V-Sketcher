import type { InputBasis } from '../execution/changes';
import type { ExportProfile } from '../project-model';
import type { PreviewScene } from '../scene-core';
export const CHECKER_VERSION = '1.1.0';
export const CONVERTER_VERSION = '0.3.0';
export const TARGET_ID = 'inochi-session-0.8.7-inp';
export const TARGETS = [
  {
    id: TARGET_ID,
    name: 'Inochi Session',
    version: '0.8.7',
    sdk: '0.8.6',
    format: 'INP',
    status: 'inspection-supported',
    validation: '제품 INP 생성 · 65단계 상태/곡선 근사 경고 확인 · 독립 구동 검증 대상',
    maxParts: 64,
    maxTextures: 128,
    maxTextureEdge: 4096,
    decodedBytes: 268435456,
    description:
      '32비트 정수 UUID · 중심 원점 · 반대 z · PNG 텍스처 내장 · 기본 눈/입/고개와 표정 보존 검사',
  },
  {
    id: 'inochi-other',
    name: '다른 Inochi 버전',
    version: '기타',
    sdk: '미검증',
    format: 'INP',
    status: 'experimental',
    validation: '버전별 검증 필요',
    description: '현재 선택할 수 없습니다.',
  },
  {
    id: 'vrm',
    name: 'VRM / Live2D moc3 / VTube Studio',
    version: '미지원',
    sdk: '미지원',
    format: '기타',
    status: 'unsupported',
    validation: '초기 2D 대상에 포함되지 않음',
    description: 'INP와 다른 형식이며 별도 변환/구동 검증이 필요합니다.',
  },
] as const;
export interface TargetOptions {
  targetId: string;
  parameterMap: { parameterId: string; targetName: string }[];
}
export interface CheckIssue {
  id: string;
  code: string;
  severity: 'warning' | 'block';
  category: 'structure' | 'resource' | 'parameter' | 'expression' | 'conversion';
  subjectId: string | null;
  message: string;
  impact: string;
  alternative: string;
  fix: { kind: 'part' | 'parameter' | 'binding' | 'group'; id: string } | null;
}
export interface ConversionCopy {
  version: 1;
  parts: {
    sourceId: string;
    sourceName: string;
    parentSourceId: string | null;
    enabled: boolean;
    opacity: number;
    uuid: number;
    name: string;
    z: number;
    vertices: [number, number][];
    indices: number[];
  }[];
  parameters: {
    sourceId: string;
    uuid: number;
    name: string;
    min: number;
    neutral: number;
    max: number;
  }[];
  textures: {
    sourceId: string;
    name: string;
    sha256: string;
    operation: 'copy' | 'jpeg-to-png-premultiply' | 'straight-to-premultiplied';
  }[];
  bindings: { nodeUUID: number; parameterUUID: number; kind: string; mapping: unknown }[];
  expressions: {
    sourceId: string;
    name: string;
    transitionMs: number;
    release: string;
    releaseMs: number;
    values: { parameterUUID: number; value: number; locked: boolean }[];
  }[];
  changes: string[];
}
export interface CheckResult {
  id: string;
  basis: InputBasis;
  targetId: string;
  targetVersion: string;
  converterVersion: string;
  checkerVersion: string;
  signature: string;
  status: 'PASS' | 'WARNING' | 'BLOCKED';
  issues: CheckIssue[];
  warningScope: string;
  acknowledged: boolean;
  copy: ConversionCopy | null;
  scene: PreviewScene | null;
  settings: TargetOptions;
}
export interface CheckReply {
  ok: boolean;
  result?: CheckResult;
  errorCode?: string;
  stale?: boolean;
}
export interface CompatibilityAPI {
  inspect: (
    source: 'working' | 'execution',
    projectId: string,
    revision: number,
    options: TargetOptions,
  ) => Promise<CheckReply>;
  acknowledge: (
    id: string,
    signature: string,
    warningScope: string,
    options: TargetOptions,
  ) => Promise<CheckReply>;
  verify: (id: string, options: TargetOptions) => Promise<CheckReply>;
  release: (id: string) => Promise<void>;
}
export function assertTargetOptions(value: unknown): asserts value is TargetOptions {
  const v = value as TargetOptions;
  if (
    !v ||
    Object.keys(v).sort().join(',') !== 'parameterMap,targetId' ||
    v.targetId !== TARGET_ID ||
    !Array.isArray(v.parameterMap) ||
    v.parameterMap.length > 128 ||
    v.parameterMap.some(
      (m) =>
        !m ||
        Object.keys(m).sort().join(',') !== 'parameterId,targetName' ||
        typeof m.parameterId !== 'string' ||
        m.parameterId.length > 100 ||
        typeof m.targetName !== 'string' ||
        !m.targetName.trim() ||
        m.targetName.length > 120,
    )
  )
    throw new Error('E_EXPORT_TARGET');
}
export function assertExportProfile(value: unknown): asserts value is ExportProfile {
  const p = value as ExportProfile;
  if (
    !p ||
    Object.keys(p).sort().join(',') !==
      'converterVersion,displayName,format,id,parameterMap,revision,target,targetVersion' ||
    typeof p.id !== 'string' ||
    !/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,99}$/.test(p.id) ||
    typeof p.displayName !== 'string' ||
    !p.displayName.trim() ||
    p.displayName.length > 120 ||
    !Number.isSafeInteger(p.revision) ||
    p.revision < 1 ||
    p.target !== 'inochi2d' ||
    p.targetVersion !== '0.8.7' ||
    p.format !== 'inp' ||
    p.converterVersion !== CONVERTER_VERSION
  )
    throw new Error('E_EXPORT_TARGET');
  assertTargetOptions({ targetId: TARGET_ID, parameterMap: p.parameterMap });
}
