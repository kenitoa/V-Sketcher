import { NEUTRAL, type Parameters, type PreviewScene } from '../scene-core';
import { normalize } from '../motion';
import type { Project } from '../project-model';
import type { NativeBinding } from './inp';
import { parseINP } from './inp';
function value(binding: NativeBinding, axis: number[], q: number): unknown {
  let i = 0;
  while (i < axis.length - 2 && q > axis[i + 1]!) i++;
  const t = Math.max(0, Math.min(1, (q - axis[i]!) / (axis[i + 1]! - axis[i]!)));
  const a = binding.values[i]![0],
    b = binding.values[i + 1]![0];
  if (binding.interpolate_mode === 'Nearest') return t < 0.5 ? a : b;
  if (typeof a === 'number') return a + ((b as number) - a) * t;
  return (a as number[][]).map((v, j) => v.map((n, k) => n + ((b as number[][])[j]![k]! - n) * t));
}
export function nativePreview(
  parsed: ReturnType<typeof parseINP>,
  project: Project,
  input: Parameters,
  expressionId: string | null,
  url: (index: number) => string,
): PreviewScene {
  const values = new Map(
    project.parameters.map((p) => [
      p.id,
      p.previewKey ? input[p.previewKey] : normalize(p, p.neutral),
    ]),
  );
  if (expressionId) {
    const e = project.expressions.find((v) => v.id === expressionId);
    if (!e) throw new Error('E_AVATAR_EXPRESSION');
    for (const v of e.values) {
      const p = project.parameters.find((p) => p.id === v.parameterId)!;
      values.set(p.id, normalize(p, v.value));
    }
  }
  const opacity = new Map<number, number>(),
    delta = new Map<number, number[][]>();
  for (let i = 0; i < parsed.model.param.length; i++) {
    const native = parsed.model.param[i]!,
      source = project.parameters[i]!,
      q = values.get(source.id) ?? NEUTRAL[source.previewKey!],
      physical = source.previewKey?.startsWith('head')
        ? q < 0
          ? source.neutral + q * (source.neutral - source.min)
          : source.neutral + q * (source.max - source.neutral)
        : source.min + q * (source.max - source.min),
      u = (physical - source.min) / (source.max - source.min);
    for (const b of native.bindings) {
      const v = value(b, native.axis_points[0]!, u);
      if (b.param_name === 'opacity')
        opacity.set(b.node, (opacity.get(b.node) ?? 1) * (v as number));
      else {
        const current = delta.get(b.node) ?? (v as number[][]).map(() => [0, 0]);
        (v as number[][]).forEach((v, j) => {
          current[j]![0]! += v[0]!;
          current[j]![1]! += v[1]!;
        });
        delta.set(b.node, current);
      }
    }
  }
  const layers: PreviewScene['layers'] = [];
  for (const n of parsed.nodes.values()) {
    const o = (n.opacity ?? 1) * (opacity.get(n.uuid) ?? 1);
    if (n.type !== 'Part' || !n.enabled || o <= 0.000001) continue;
    const m = n.mesh!,
      path = url(n.textures![0]!),
      verts = Array.from({ length: m.verts.length / 2 }, (_, i) => ({
        position: [
          m.verts[i * 2]! + project.canvas.width / 2 + (delta.get(n.uuid)?.[i]?.[0] ?? 0),
          m.verts[i * 2 + 1]! + project.canvas.height / 2 + (delta.get(n.uuid)?.[i]?.[1] ?? 0),
        ] as [number, number],
        weight: 0,
        minimum: [0, 0] as [number, number],
        maximum: [0, 0] as [number, number],
      }));
    layers.push({
      id: 'node-' + n.uuid,
      z: -n.zsort,
      origin: [0, 0],
      opacity: o,
      bind: null,
      states: { base: path },
      meshUVs: Array.from(
        { length: verts.length },
        (_, i) => [m.uvs[i * 2]!, m.uvs[i * 2 + 1]!] as [number, number],
      ),
      mesh: {
        pivot: [0, 0],
        vertices: verts,
        triangles: m.indices,
        yaw: false,
        roll: false,
        maxRollDegrees: 0,
        curve: 'linear',
      },
    });
  }
  return {
    version: 1,
    name: project.displayName + ' · INP 변환 미리보기',
    canvas: [project.canvas.width, project.canvas.height],
    premultipliedTextures: true,
    layers,
  };
}
