import { contextBridge, ipcRenderer, webUtils } from 'electron';
import type { StudioInfo } from '../../packages/contracts';
import type {
  SessionCommand,
  SessionView,
  SessionReply,
} from '../../packages/project-session/contracts';
contextBridge.exposeInMainWorld(
  'studio',
  Object.freeze({
    image: Object.freeze({
      prepare: (v: unknown) => ipcRenderer.invoke('image-export:prepare', v),
      save: (id: string) => ipcRenderer.invoke('image-export:save', id),
      release: (id: string) => ipcRenderer.invoke('image-export:release', id),
    }),
    compatibility: Object.freeze({
      inspect: (source: string, projectId: string, revision: number, options: unknown) =>
        ipcRenderer.invoke('compatibility:command', 'inspect', {
          source,
          projectId,
          revision,
          options,
        }),
      verify: (id: string, options: unknown) =>
        ipcRenderer.invoke('compatibility:command', 'verify', { id, options }),
      acknowledge: (id: string, signature: string, warningScope: string, options: unknown) =>
        ipcRenderer.invoke('compatibility:command', 'acknowledge', {
          id,
          signature,
          warningScope,
          options,
        }),
      release: (id: string) => ipcRenderer.invoke('compatibility:command', 'release', { id }),
    }),
    broadcast: Object.freeze({
      preview: () => ipcRenderer.invoke('broadcast:command', 'preview'),
      view: () => ipcRenderer.invoke('broadcast:command', 'view'),
      start: (id: string) => ipcRenderer.invoke('broadcast:command', 'start', id),
      stop: () => ipcRenderer.invoke('broadcast:command', 'stop'),
      restart: () => ipcRenderer.invoke('broadcast:command', 'restart'),
      configure: (v: unknown) => ipcRenderer.invoke('broadcast:command', 'configure', v),
      restore: () => ipcRenderer.invoke('broadcast:command', 'restore'),
      rotate: () => ipcRenderer.invoke('broadcast:command', 'rotate'),
      copyURL: () => ipcRenderer.invoke('broadcast:command', 'copy'),
      confirm: (v: unknown) => ipcRenderer.invoke('broadcast:command', 'confirm', v),
      frame: (v: unknown) => ipcRenderer.send('broadcast:frame', v),
      subscribe: (listener: (v: unknown) => void) => {
        const receive = (_event: Electron.IpcRendererEvent, v: unknown) => listener(v);
        ipcRenderer.on('broadcast:changed', receive);
        return () => ipcRenderer.removeListener('broadcast:changed', receive);
      },
    }),
    avatar: Object.freeze({
      prepare: (id: string, checkId: string, options: unknown, demo: boolean) =>
        ipcRenderer.invoke('avatar-export:command', 'prepare', { id, checkId, options, demo }),
      preview: (id: string, values: unknown, expressionId: string | null) =>
        ipcRenderer.invoke('avatar-export:command', 'preview', { id, values, expressionId }),
      save: (id: string, sha: string) =>
        ipcRenderer.invoke('avatar-export:command', 'save', { id, sha }),
      cancel: (id: string) => ipcRenderer.invoke('avatar-export:command', 'cancel', { id }),
      list: () => ipcRenderer.invoke('avatar-export:command', 'list', {}),
      confirm: (id: string, version: string) =>
        ipcRenderer.invoke('avatar-export:command', 'confirm', { id, version }),
      relocate: (id: string) => ipcRenderer.invoke('avatar-export:command', 'relocate', { id }),
      reveal: (id: string) => ipcRenderer.invoke('avatar-export:command', 'reveal', { id }),
    }),
    settings: Object.freeze({
      view: () => ipcRenderer.invoke('settings:view'),
      save: (v: unknown) => ipcRenderer.invoke('settings:save', v),
      folder: (clear = false) => ipcRenderer.invoke('settings:folder', clear),
      metrics: () => ipcRenderer.invoke('settings:metrics'),
      diagnostic: (v: unknown) => ipcRenderer.invoke('settings:diagnostic', v),
      clearLogs: () => ipcRenderer.invoke('settings:clear-logs'),
      support: () => ipcRenderer.invoke('settings:support'),
      notices: () => ipcRenderer.invoke('settings:notices'),
      dataFolder: () => ipcRenderer.invoke('settings:data-folder'),
      subscribe: (fn: (v: unknown) => void) => {
        const handler = (_e: Electron.IpcRendererEvent, v: unknown) => fn(v);
        ipcRenderer.on('settings:changed', handler);
        return () => ipcRenderer.removeListener('settings:changed', handler);
      },
    }),
    run: Object.freeze({
      rollbackChange: (owner: string, id: string, base: string) =>
        ipcRenderer.invoke('run:rollback-change', owner, id, base),
      prepareChange: (request: unknown) => ipcRenderer.invoke('run:prepare-change', request),
      commitChange: (request: unknown) => ipcRenderer.invoke('run:commit-change', request),
      stop: (owner: string) => ipcRenderer.invoke('run:stop', owner),
      transition: (command: unknown, baseId: string) =>
        ipcRenderer.invoke('run:transition', command, baseId),
      inputBasis: (source: string, projectId: string, revision: number) =>
        ipcRenderer.invoke('run:input-basis', source, projectId, revision),
      prepare: (value: unknown) => ipcRenderer.invoke('run:prepare', value),
      release: (id: string) => ipcRenderer.invoke('run:release', id),
      preferences: () => ipcRenderer.invoke('run:preferences'),
      configure: (value: unknown) => ipcRenderer.invoke('run:configure', value),
      active: (id: string, active: boolean) => ipcRenderer.invoke('run:active', id, active),
      context: (suspended: boolean, editing = false) =>
        ipcRenderer.invoke('run:context', suspended, editing),
      subscribe: (listener: (v: unknown) => void) => {
        const receive = (_event: Electron.IpcRendererEvent, v: unknown) => listener(v);
        ipcRenderer.on('run:shortcut', receive);
        return () => ipcRenderer.removeListener('run:shortcut', receive);
      },
    }),
    microphone: Object.freeze({
      begin: (owner?: string | null) => ipcRenderer.invoke('microphone:begin', owner),
      end: (owner?: string | null) => ipcRenderer.invoke('microphone:end', owner),
      profiles: () => ipcRenderer.invoke('microphone:profiles'),
      save: (value: unknown) => ipcRenderer.invoke('microphone:save', value),
    }),
    tracking: Object.freeze({
      begin: (owner?: string | null) => ipcRenderer.invoke('tracking:begin', owner),
      end: (owner?: string | null) => ipcRenderer.invoke('tracking:end', owner),
      frame: (seq: number, jpeg: Uint8Array, owner?: string | null) =>
        ipcRenderer.invoke('tracking:frame', seq, jpeg, owner),
      profiles: () => ipcRenderer.invoke('tracking:profiles'),
      saveCalibration: (value: unknown) => ipcRenderer.invoke('tracking:calibration', value),
    }),
    info: (): Promise<StudioInfo> => ipcRenderer.invoke('studio:info'),
    health: (): Promise<{ ready: boolean }> => ipcRenderer.invoke('studio:health'),
    projects: Object.freeze({
      dropImage: (file: File): Promise<SessionReply> => {
        const path = webUtils.getPathForFile(file);
        if (!path) return Promise.reject(new Error('E_INPUT_NATIVE_FILE'));
        return ipcRenderer.invoke('projects:drop-image', path);
      },
      view: (): Promise<SessionView> => ipcRenderer.invoke('projects:view'),
      command: (command: SessionCommand): Promise<SessionReply> =>
        ipcRenderer.invoke('projects:command', command),
      subscribe: (listener: (view: SessionView) => void): (() => void) => {
        const receive = (_event: Electron.IpcRendererEvent, view: SessionView): void =>
          listener(view);
        ipcRenderer.on('projects:changed', receive);
        return () => ipcRenderer.removeListener('projects:changed', receive);
      },
    }),
  }),
);
