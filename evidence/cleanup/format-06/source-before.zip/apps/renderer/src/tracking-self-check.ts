import { clickCommittedControl } from './ui-check-control';
import type {
  SessionView,
  SessionCommand,
  SessionReply,
} from '../../../packages/project-session/contracts';
import type { CameraRuntime } from './camera-runtime';
import { defaultTracking } from '../../../packages/tracking';
export async function checkTrackingUI(host: {
  current: () => SessionView | null;
  command: (c: SessionCommand) => Promise<SessionReply>;
  settled: () => Promise<unknown>;
  runtime: CameraRuntime;
}) {
  const r = host.runtime;
  let stage = 'initial';
  const pause = () =>
    new Promise<void>((resolve) =>
      requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
    );
  const verify = (v: unknown, code: string) => {
    if (!v) throw new Error(code);
  };
  const until = async (fn: () => unknown) => {
    const end = Date.now() + 180000;
    while (!fn()) {
      if (Date.now() > end) {
        window.editorFailureState = {
          trackingStage: stage,
          state: r.state,
          error: r.errorCode,
          faces: r.result?.faces.length,
          target: r.target.state,
          calibration: r.calibration.state,
          samples: r.calibration.count,
          frames: r.frames,
        };
        throw new Error('E_TRACKING_UI_TIMEOUT');
      }
      await new Promise((resolve) => setTimeout(resolve, 25));
    }
    await pause();
  };
  const current = () => host.current()!.project!;
  const click = async (selector: string) => {
    stage = selector;
    await clickCommittedControl(selector, host.current);
    await host.settled();
    await pause();
  };
  const tracked = () => r.target.state === 'tracked';
  const target = async () => {
    await until(() => r.state === 'open' && (r.result?.faces.length ?? 0) > 0 && r.frames >= 3);
    for (let attempt = 0; attempt < 4; attempt++) {
      if (tracked()) return;
      await click('[data-camera-target="0"]');
      const start = r.frames,
        end = performance.now() + 8000;
      while (!tracked() && r.frames < start + 4 && performance.now() < end)
        await new Promise((resolve) => setTimeout(resolve, 30));
      if (tracked()) return;
    }
    verify(false, 'E_TRACKING_UI_RESELECT');
  };
  const calibrate = async (ready = true) => {
    const deadline = performance.now() + 90000;
    let attempts = 0;
    while (performance.now() < deadline) {
      await target();
      await click('[data-camera-calibrate]');
      const end = performance.now() + 12000;
      while (
        performance.now() < end &&
        tracked() &&
        r.calibration.state === 'collecting' &&
        (ready || r.calibration.count <= 1)
      )
        await new Promise((resolve) => setTimeout(resolve, 30));
      if (r.calibration.state === 'ready' || (!ready && r.calibration.count > 1)) return;
      if (++attempts >= 6) break;
    }
    verify(false, 'E_TRACKING_UI_STABLE_CALIBRATION');
  };
  const media = navigator.mediaDevices,
    enumerate = media.enumerateDevices,
    get = media.getUserMedia;
  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 480;
  const ctx = canvas.getContext('2d')!;
  const image = new Image();
  const project = (await (
    await fetch('assets/preview-project.json')
  ).json()) as import('../../../packages/project-model').Project;
  const asset = project.assets.find((a) => a.id === project.inputAssetIds[0])!;
  image.src = 'assets/preview/' + asset.fingerprint.sha256 + '.png';
  await image.decode();
  let animation = 0,
    dark = false,
    tick = 0;
  const captureTracks: CanvasCaptureMediaStreamTrack[] = [];
  const draw = () => {
    ctx.fillStyle = '#777';
    ctx.fillRect(0, 0, 640, 480);
    if (!dark) ctx.drawImage(image, 300, 50, 650, 650, 80, 0, 480, 480);
    else {
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, 640, 480);
    }
    ctx.fillStyle = ++tick % 2 ? '#ff0000' : '#0000ff';
    ctx.fillRect(0, 476, 4, 4);
    for (const track of captureTracks) if (track.readyState === 'live') track.requestFrame();
  };
  draw();
  const drawTimer = setInterval(draw, 50);
  Object.defineProperty(media, 'enumerateDevices', {
    configurable: true,
    value: async () => [
      {
        kind: 'videoinput',
        deviceId: 'tracking-fixture',
        groupId: 'fixture',
        label: '합성 영상 · 실제 장치 미사용',
        toJSON: () => ({}),
      },
    ],
  });
  Object.defineProperty(media, 'getUserMedia', {
    configurable: true,
    value: async () => {
      const stream = canvas.captureStream(20);
      captureTracks.push(stream.getVideoTracks()[0] as CanvasCaptureMediaStreamTrack);
      return stream;
    },
  });
  const routes: Record<string, unknown>[] = [];
  try {
    for (const route of ['parts', 'single-image', 'split-image'] as const) {
      await host.command({ type: 'new', name: '카메라 매핑 검증 · ' + route, sourceType: route });
      await pause();
      await click('[data-step="prepare"]');
      if (route === 'parts')
        await host.command({ type: 'parts-start', expectedRevision: current().revision });
      else if (route === 'single-image') {
        await host.command({ type: 'import-image' });
        await until(() => !host.current()!.input!.busy);
        const d = host.current()!.input!.draft!;
        await host.command({
          type: 'input-apply',
          draftId: d.id,
          selection: {
            rect: { x: 0, y: 0, ...d.probe.size },
            masks: [],
            occluded: false,
            backgroundTolerance: null,
          },
        });
        await until(() => !host.current()!.input!.busy);
        await host.command({
          type: 'structure-start',
          expectedRevision: current().revision,
          completion: 'estimated',
        });
        await until(() => !host.current()!.structure!.busy);
        await host.command({ type: 'structure-apply', expectedRevision: current().revision });
      } else {
        await click('[data-split-load="example"]');
        await until(
          () => !host.current()!.split!.busy && document.querySelector('[data-split-prepare]'),
        );
        await click('[data-split-prepare]');
        await until(() => !host.current()!.split!.busy);
        await click('[data-split-apply]');
        await click('[data-split-close]');
      }
      await click('[data-step="motion"]');
      await until(() => window.previewProbe?.().ready);
      await click('[data-camera-open]');
      await until(() => {
        const options = [
          ...(document.querySelector<HTMLSelectElement>('[data-camera-device]')?.options ?? []),
        ];
        return (
          options.some((o) => o.value === '') && options.some((o) => o.value === 'tracking-fixture')
        );
      });
      const frozen = JSON.stringify(current());
      let startupRetries = 0;
      for (let attempt = 0; attempt < 3; attempt++) {
        await click('[data-camera-start]');
        await until(
          () => r.state === 'failed' || (r.state === 'open' && (r.result?.faces.length ?? 0) > 0),
        );
        if (r.state === 'open') break;
        startupRetries++;
      }
      verify(r.state === 'open', 'E_TRACKING_UI_START');
      await target();
      verify(!document.querySelector('.camera-source canvas'), 'E_TRACKING_UI_PREVIEW_DEFAULT');
      await click('[data-camera-preview]');
      await until(() => !!document.querySelector('.camera-source canvas'));
      const beforeMirror = JSON.stringify(r.player.controls.snapshot().values);
      await click('[data-camera-mirror]');
      verify(
        r.previewCanvas.className.includes('mirrored') === r.mirror &&
          JSON.stringify(current()) === frozen,
        'E_TRACKING_UI_MIRROR',
      );
      void beforeMirror;
      await calibrate(false);
      const old = JSON.stringify(r.profile);
      await click('[data-camera-cancel]');
      verify(
        JSON.stringify(r.profile) === old && r.calibration.candidate === null,
        'E_TRACKING_UI_CANCEL',
      );
      await calibrate();
      await click('[data-camera-calibration-apply]');
      await until(() => !!r.profile && r.calibration.state !== 'ready');
      verify(JSON.stringify(current()) === frozen, 'E_TRACKING_UI_MACHINE_ONLY');
      const baseline = JSON.stringify(r.profile);
      dark = true;
      await until(() => !!r.result && r.result.brightness < 35);
      verify(JSON.stringify(r.profile) === baseline, 'E_TRACKING_UI_DARK_PRESERVATION');
      dark = false;
      await until(() => !!r.result?.faces.length);
      await target();
      const config = defaultTracking();
      config.channels.find((c) => c.key === 'head_yaw')!.invert = true;
      await host.command({
        type: 'tracking-settings',
        expectedRevision: current().revision,
        value: config,
      });
      await pause();
      verify(
        !host.current()!.errorCode &&
          current().tracking?.channels.find((c) => c.key === 'head_yaw')!.invert,
        'E_TRACKING_UI_SETTINGS',
      );
      await host.command({ type: 'undo' });
      verify(!current().tracking, 'E_TRACKING_UI_UNDO');
      await host.command({ type: 'redo' });
      verify(!!current().tracking, 'E_TRACKING_UI_REDO');
      await click('[data-camera-preview]');
      r.stop();
      verify(r.video.srcObject === null && !r.player.cameraLive, 'E_TRACKING_UI_STOP');
      await click('[data-camera-close]');
      const appearance = JSON.stringify({
          parts: current().parts,
          expressions: current().expressions,
        }),
        mapping = JSON.stringify(current().tracking);
      await host.command({ type: 'save' });
      verify(!host.current()!.dirty, 'E_TRACKING_UI_SAVE');
      await host.command({ type: 'duplicate' });
      await host.command({ type: 'recent', id: host.current()!.recent[0]!.id });
      verify(
        JSON.stringify(current().tracking) === mapping &&
          JSON.stringify({ parts: current().parts, expressions: current().expressions }) ===
            appearance,
        'E_TRACKING_UI_REOPEN',
      );
      routes.push({
        route,
        passed: true,
        startupRetries,
        actualRoutePreparation: true,
        syntheticMediaOnly: true,
        realWorkerInference: true,
        separateOpenAndDetection: true,
        optInPreview: true,
        mirrorViewOnly: true,
        stableCalibration: true,
        cancelPreservesBaseline: true,
        simulatedDarkInput: true,
        machineProfileSeparate: true,
        mappingUndoRedo: true,
        saveDuplicateReopen: true,
        rawVideoExcludedFromProject: true,
      });
      await click('[data-step="motion"]');
      await click('[data-camera-open]');
      if (route !== 'split-image') await click('[data-camera-close]');
    }
    return {
      passed: true,
      routes,
      devicesOpened: false,
      syntheticCanvasMedia: true,
      actualLocalInference: true,
      realEnvironment: 'NOT_RUN',
      m0: 'HOLD',
    };
  } finally {
    r.stop();
    clearInterval(drawTimer);
    cancelAnimationFrame(animation);
    r.showPreview = false;
    Object.defineProperty(media, 'enumerateDevices', { configurable: true, value: enumerate });
    Object.defineProperty(media, 'getUserMedia', { configurable: true, value: get });
  }
}
