import type {
  SessionView,
  SessionCommand,
  SessionReply,
} from '../../../packages/project-session/contracts';
import type { RunRuntime } from './run-runtime';
import type { CameraRuntime } from './camera-runtime';
import type { MicrophoneRuntime } from './microphone-runtime';
import { clickCommittedControl } from './ui-check-control';
import { settings } from '../../../packages/expression-control';
export async function checkRuntimeChangesUI(host: {
  current: () => SessionView | null;
  command: (c: SessionCommand) => Promise<SessionReply>;
  settled: () => Promise<unknown>;
  runtime: RunRuntime;
  camera: CameraRuntime;
  microphone: MicrophoneRuntime;
}) {
  const r = host.runtime,
    media = navigator.mediaDevices,
    originalGet = media.getUserMedia,
    originalEnum = media.enumerateDevices,
    preferences = structuredClone(r.preferences);
  let stage = 'prepare',
    completed = false,
    gumCalls = 0;
  const pause = (ms = 60) => new Promise((resolve) => setTimeout(resolve, ms));
  const current = () => host.current()!.project!;
  const verify = (v: unknown, code: string) => {
    if (!v) throw new Error(code);
  };
  const until = async (fn: () => unknown) => {
    const end = performance.now() + 65000;
    while (!fn()) {
      window.editorFailureState = {
        runtimeChangeStage: stage,
        state: r.state,
        change: r.changeState,
        error: r.changeError ?? r.errorCode,
        revision: current()?.revision,
        runRevision: r.lease?.revision,
        liveSurfaces: r.surface.stats().live,
        camera: r.camera.state,
        microphone: r.microphone.state,
      };
      if (performance.now() > end) throw new Error('E_RUNTIME_CHANGE_UI_TIMEOUT');
      await pause();
    }
  };
  const click = async (selector: string) => {
    stage = selector;
    await clickCommittedControl(selector, host.current);
    await host.settled();
    if (selector === '[data-run-edit]')
      await until(() => !document.querySelector('[data-run-panel]'));
    await pause();
  };
  const choose = async (mode: string) => {
    stage = 'mode:' + mode;
    await until(() => !!document.querySelector('[data-run-mode]'));
    const el = document.querySelector<HTMLSelectElement>('[data-run-mode]')!;
    el.value = mode;
    el.dispatchEvent(new Event('change', { bubbles: true }));
    await new Promise<void>((resolve) =>
      requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
    );
  };
  const opacity = async (value: number) => {
    await host.command({
      type: 'edit',
      target: 'part-opacity',
      id: current().parts[0]!.id,
      parameterId: null,
      value,
      expectedRevision: current().revision,
      groupId: null,
    });
    verify(!host.current()!.errorCode, 'E_RUNTIME_EDIT');
  };
  const hash = () => r.surface.measure()?.pixelHash;
  const records: Record<string, unknown>[] = [],
    saved: { route: string; a: string; b: string; projectId: string }[] = [];
  let audio: AudioContext | null = null,
    osc: OscillatorNode | null = null,
    timer: ReturnType<typeof setInterval> | undefined;
  const streams: MediaStream[] = [];
  Object.defineProperty(media, 'enumerateDevices', { configurable: true, value: async () => [] });
  Object.defineProperty(media, 'getUserMedia', {
    configurable: true,
    value: async () => {
      gumCalls++;
      throw new DOMException('Denied', 'NotAllowedError');
    },
  });
  try {
    for (const route of ['parts', 'single-image', 'split-image'] as const) {
      stage = route;
      await host.command({ type: 'new', name: '실행 변경 · ' + route, sourceType: route });
      await click('[data-step="prepare"]');
      if (route === 'parts')
        await host.command({ type: 'parts-start', expectedRevision: current().revision });
      else if (route === 'single-image') {
        await host.command({ type: 'import-image' });
        await until(() => !host.current()!.input!.busy);
        const d = host.current()!.input!.draft!;
        await host.command({
          type: 'input-apply',
          draftId: d.id,
          selection: {
            rect: { x: 0, y: 0, ...d.probe.size },
            masks: [],
            occluded: false,
            backgroundTolerance: null,
          },
        });
        await until(() => !host.current()!.input!.busy);
        await host.command({
          type: 'structure-start',
          expectedRevision: current().revision,
          completion: 'estimated',
        });
        await until(() => !host.current()!.structure!.busy);
        await host.command({ type: 'structure-apply', expectedRevision: current().revision });
      } else {
        await click('[data-split-load="example"]');
        await until(
          () => !host.current()!.split!.busy && document.querySelector('[data-split-prepare]'),
        );
        await click('[data-split-prepare]');
        await until(() => !host.current()!.split!.busy);
        await click('[data-split-apply]');
        await click('[data-split-close]');
      }
      await host.command({ type: 'save' });
      const a = host.current()!.recent[0]!.id;
      await host.command({ type: 'duplicate' });
      await host.command({ type: 'save' });
      const b = host.current()!.recent[0]!.id;
      await host.command({ type: 'recent', id: a });
      saved.push({ route, a, b, projectId: current().projectId });
      await click('[data-run-open]');
      await click('[data-run-start]');
      await until(() => r.active);
      const owner = r.ownerId;
      await click('[data-run-edit]');
      verify(!!document.querySelector('[data-run-dock]') && r.active, 'E_RUNTIME_EDITOR_RETURN');
      const created = r.surface.stats().created;
      const slider = document.querySelector<HTMLInputElement>('[data-run-live-gain]')!;
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(
        slider,
        '0.6',
      );
      slider.dispatchEvent(new Event('input', { bubbles: true }));
      await host.settled();
      await until(
        () =>
          r.lease?.project.tracking?.channels.find((c) => c.key === 'head_yaw')?.gain === 0.6 &&
          r.changeState === 'idle',
      );
      verify(
        r.surface.stats().created === created && r.ownerId === owner,
        'E_RUNTIME_CONTROL_REUSE',
      );
      const mouth = current().parameters.find((p) => p.previewKey === 'mouth')!;
      await host.command({
        type: 'expression-edit',
        expectedRevision: current().revision,
        operation: {
          kind: 'save',
          id: null,
          name: '실행 중 표정',
          values: [{ parameterId: mouth.id, value: mouth.max, locked: true }],
          transitionMs: 0,
          releaseMs: 100,
          release: 'live-input',
        },
      });
      const expression = current().expressions.at(-1)!;
      await host.command({
        type: 'expression-edit',
        expectedRevision: current().revision,
        operation: {
          kind: 'settings',
          value: { ...settings(current()), shortcuts: [expression.id, null, null] },
        },
      });
      await until(() => r.lease?.revision === current().revision && r.changeState === 'idle');
      verify(r.action('expression-1'), 'E_RUNTIME_LIVE_EXPRESSION');
      verify(
        r.player.controls.snapshot().activeId === expression.id,
        'E_RUNTIME_EXPRESSION_SOURCE',
      );
      r.action('release');
      await pause(200);
      r.action('neutral');
      const oldId = r.lease!.requestId,
        oldRevision = r.lease!.revision,
        before = hash();
      await opacity(0.55);
      await pause(300);
      verify(r.lease!.requestId === oldId && hash() === before, 'E_RUNTIME_WORK_ISOLATION');
      const priorSurfaces = r.surface.stats().created;
      const prepareButton = document.querySelector<HTMLButtonElement>('[data-run-change-prepare]')!;
      prepareButton.click();
      prepareButton.click();
      await until(() => r.changeState === 'ready');
      verify(r.surface.stats().created === priorSurfaces + 1, 'E_RUNTIME_DUPLICATE_PREPARE');
      verify(
        r.surface.stats().live === 2 && r.lease!.requestId === oldId && hash() === before,
        'E_RUNTIME_CANDIDATE_ISOLATION',
      );
      await click('[data-run-change-cancel]');
      await until(() => r.changeState === 'idle');
      verify(
        r.surface.stats().live === 1 && current().parts[0]!.opacity === 0.55,
        'E_RUNTIME_CANCEL',
      );
      await click('[data-run-change-prepare]');
      await until(() => r.changeState === 'ready');
      await opacity(0.35);
      verify(
        !(await r.commitChanges()) && r.changeError === 'E_RUN_STALE',
        'E_RUNTIME_STALE_COMMIT',
      );
      verify(
        r.lease!.revision === oldRevision && current().parts[0]!.opacity === 0.35,
        'E_RUNTIME_NEWER_EDIT',
      );
      await click('[data-run-change-prepare]');
      await until(() => r.changeState === 'ready');
      await click('[data-run-change-apply]');
      await until(() => r.lease!.revision === current().revision && r.changeState === 'idle');
      verify(hash() !== before && r.surface.stats().live === 1, 'E_RUNTIME_GPU_PUBLICATION');
      await opacity(0.7);
      r.exportSource = 'working';
      const work = await r.basis(host.current()!);
      r.exportSource = 'execution';
      const execution = await r.basis(host.current()!);
      verify(
        work &&
          execution &&
          work.revision !== execution.revision &&
          work.fingerprint !== execution.fingerprint,
        'E_RUNTIME_INPUT_BASIS',
      );
      await click('[data-run-dock-save]');
      await until(() => !host.current()!.saving && !host.current()!.dirty);
      verify(
        host.current()!.savedRevision === current().revision &&
          r.lease!.revision !== current().revision,
        'E_RUNTIME_WORK_SAVE',
      );
      const stable = hash(),
        stableId = r.lease!.requestId,
        originalPrepare = r.surface.prepare.bind(r.surface);
      r.surface.prepare = async (lease, player) => {
        const damaged = structuredClone(lease);
        for (const layer of damaged.scene.layers)
          for (const key of Object.keys(layer.states))
            layer.states[key] = 'assets/missing-runtime-change.png';
        return originalPrepare(damaged, player);
      };
      try {
        verify(!(await r.applyChanges(host.current()!)), 'E_RUNTIME_INJECTED_LOAD');
      } finally {
        r.surface.prepare = originalPrepare;
      }
      verify(
        r.lease!.requestId === stableId &&
          hash() === stable &&
          r.surface.stats().live === 1 &&
          current().parts[0]!.opacity === 0.7,
        'E_RUNTIME_FAILED_KEEP',
      );
      await click('[data-run-change-prepare]');
      await until(() => r.changeState === 'ready');
      await click('[data-run-change-apply]');
      await until(() => r.lease!.revision === current().revision && r.changeState === 'idle');
      const head = current().parameters.find((p) => p.previewKey === 'head_yaw')!;
      await host.command({
        type: 'motion-parameter',
        expectedRevision: current().revision,
        id: head.id,
        min: head.min,
        neutral: head.neutral,
        max: head.max * 0.9,
      });
      await click('[data-run-change-prepare]');
      await until(() => r.changeState === 'ready');
      await click('[data-run-change-restart]');
      await until(() => r.lease!.revision === current().revision && r.changeState === 'idle');
      verify(r.ownerId === owner && r.surface.stats().live === 1, 'E_RUNTIME_LOGICAL_RESTART');
      let transition = host.command({ type: 'recent', id: b });
      await click('[data-run-transition-cancel]');
      await transition;
      verify(current().projectId === saved.at(-1)!.projectId, 'E_RUNTIME_TRANSITION_CANCEL');
      const runProject = r.lease!.project.projectId;
      transition = host.command({ type: 'recent', id: b });
      await click('[data-run-transition-keep]');
      await transition;
      verify(
        current().projectId !== runProject && r.lease!.project.projectId === runProject,
        'E_RUNTIME_TRANSITION_KEEP',
      );
      transition = host.command({ type: 'recent', id: a });
      await click('[data-run-transition-switch]');
      await transition;
      await until(
        () => r.lease!.sessionId === host.current()!.sessionId && r.changeState === 'idle',
      );
      verify(r.surface.stats().live === 1, 'E_RUNTIME_TRANSITION_SWAP');
      await host.command({ type: 'import-image' });
      verify(host.current()!.errorCode === 'E_RUN_HEAVY' && r.active, 'E_RUNTIME_DEFER');
      await click('[data-run-dock-stop]');
      await until(() => r.state === 'idle');
      verify(r.surface.stats().live === 0 && gumCalls === 0, 'E_RUNTIME_OWNER_RELEASE');
      records.push({
        route,
        passed: true,
        actualRoutePreparation: true,
        validatedImmediateControls: true,
        expressionSnapshotApplied: true,
        workingAndExecutionSeparate: true,
        candidateGPUIsolation: true,
        duplicatePrepareSuppressed: true,
        prepareCancel: true,
        staleCommitRejected: true,
        realGPUReplacement: true,
        rendererFailureKeepsHealthy: true,
        logicalRestart: true,
        transitionCancelKeepSwitch: true,
        explicitInputBasis: true,
        workingSavePinned: true,
        heavyDeferred: true,
        noUnneededDeviceOpen: true,
        allSurfacesReleased: true,
      });
    }
    // The supported alternative after deferral is an actual stopped-run import, with no stale apply.
    await host.command({ type: 'new', name: '보류 해제 검증', sourceType: 'single-image' });
    await host.command({ type: 'import-image' });
    await until(() => !host.current()!.input!.busy);
    verify(!!host.current()!.input!.draft, 'E_RUNTIME_DEFER_ALTERNATIVE');
    await host.command({ type: 'input-cancel' });
    await host.command({ type: 'recent', id: saved.at(-1)!.a });
    await host.command({
      type: 'expression-edit',
      expectedRevision: current().revision,
      operation: {
        kind: 'settings',
        value: { ...settings(current()), mouth: 'microphone', alternate: true },
      },
    });
    audio = new AudioContext();
    osc = audio.createOscillator();
    const gain = audio.createGain();
    gain.gain.value = 0.2;
    osc.connect(gain);
    osc.start();
    await audio.resume();
    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 480;
    const ctx = canvas.getContext('2d')!,
      image = new Image();
    const source = await (await fetch('assets/preview-project.json')).json();
    image.src =
      'assets/preview/' +
      source.assets.find((a: { id: string }) => a.id === source.inputAssetIds[0]).fingerprint
        .sha256 +
      '.png';
    await image.decode();
    let tick = 0;
    const draw = () => {
      ctx.fillStyle = '#777';
      ctx.fillRect(0, 0, 640, 480);
      ctx.drawImage(image, 300, 50, 650, 650, 80, 0, 480, 480);
      ctx.fillStyle = ++tick % 2 ? 'red' : 'blue';
      ctx.fillRect(0, 476, 4, 4);
    };
    draw();
    timer = setInterval(draw, 50);
    Object.defineProperty(media, 'enumerateDevices', {
      configurable: true,
      value: async () => [
        { kind: 'audioinput', deviceId: 'change-audio', label: '합성 음량', groupId: 'fixture' },
        { kind: 'videoinput', deviceId: 'change-video', label: '합성 얼굴', groupId: 'fixture' },
      ],
    });
    Object.defineProperty(media, 'getUserMedia', {
      configurable: true,
      value: async (c: MediaStreamConstraints) => {
        gumCalls++;
        if (c.audio) {
          const destination = audio!.createMediaStreamDestination();
          gain.connect(destination);
          const track = destination.stream.getAudioTracks()[0]!,
            actual = track.getSettings();
          Object.defineProperty(track, 'getSettings', {
            value: () => ({ ...actual, deviceId: 'change-audio' }),
          });
          streams.push(destination.stream);
          return destination.stream;
        }
        const stream = canvas.captureStream(20);
        streams.push(stream);
        return stream;
      },
    });
    await click('[data-run-open]');
    await choose('camera-microphone');
    await click('[data-run-start]');
    await until(() => r.active && r.camera.frames > 1 && r.microphone.blocks > 3);
    await click('[data-run-edit]');
    const root = r.ownerId,
      video = streams.find((s) => s.getVideoTracks().length)!.getVideoTracks()[0]!,
      sound = streams.find((s) => s.getAudioTracks().length)!.getAudioTracks()[0]!;
    let frames = r.camera.frames,
      blocks = r.microphone.blocks;
    host.camera.stop();
    await host.microphone.stop();
    await until(() => r.camera.frames > frames && r.microphone.blocks > blocks);
    verify(
      video.readyState === 'live' && sound.readyState === 'live',
      'E_RUNTIME_EDITOR_END_OWNER',
    );
    const originalProject = r.lease!.project.projectId;
    const transition = host.command({ type: 'recent', id: saved.at(-1)!.b });
    await click('[data-run-transition-keep]');
    await transition;
    frames = r.camera.frames;
    blocks = r.microphone.blocks;
    await until(() => r.camera.frames > frames && r.microphone.blocks > blocks);
    verify(
      r.lease!.project.projectId === originalProject && current().projectId !== originalProject,
      'E_RUNTIME_INPUT_SOURCE',
    );
    await host.command({
      type: 'expression-edit',
      expectedRevision: current().revision,
      operation: {
        kind: 'settings',
        value: { ...settings(current()), mouth: 'microphone', alternate: true },
      },
    });
    await click('[data-run-change-prepare]');
    await until(() => r.changeState === 'ready');
    await click('[data-run-change-restart]');
    await until(
      () => r.lease!.project.projectId === current().projectId && r.changeState === 'idle',
    );
    frames = r.camera.frames;
    blocks = r.microphone.blocks;
    await until(() => r.camera.frames > frames && r.microphone.blocks > blocks);
    verify(
      r.ownerId === root &&
        gumCalls === 2 &&
        video.readyState === 'live' &&
        sound.readyState === 'live',
      'E_RUNTIME_REBIND_NO_DUPLICATE',
    );
    const mouth = current().parameters.find((p) => p.previewKey === 'mouth')!;
    await until(() => r.player.controls.snapshot().owners.get(mouth.id) === 'microphone');
    await r.stop();
    verify(
      streams.every((s) => s.getTracks().every((t) => t.readyState === 'ended')) &&
        r.surface.stats().live === 0,
      'E_RUNTIME_FULL_RELEASE',
    );
    await host.command({ type: 'recent', id: saved.at(-1)!.a });
    await r.start(host.current()!, 'manual', {
      camera: '',
      microphone: '',
      cameraAvailable: false,
      microphoneAvailable: false,
    });
    verify(r.active, 'E_RUNTIME_FINAL_START');
    r.action('neutral');
    await opacity(0.5);
    await until(() => !!document.querySelector('[data-run-dock]'));
    completed = true;
    return {
      passed: true,
      routes: records,
      actualAudioWorklet: true,
      actualLocalInference: true,
      syntheticMediaOnly: true,
      devicesOpened: false,
      deviceRequests: gumCalls,
      editorCleanupCannotRevokeRun: true,
      projectRebindKeepsBothStreams: true,
      modeOwnerStable: true,
      physicalDevices: 'NOT_RUN',
      osGlobalKeyDelivery: 'NOT_RUN',
      deferredWorkAvailableAfterStop: true,
      rawAudioSaved: false,
      cameraFramesSaved: false,
      m0: 'HOLD',
    };
  } finally {
    if (!completed) await r.stop();
    await r.configure(preferences);
    if (timer) clearInterval(timer);
    streams.forEach((s) => s.getTracks().forEach((t) => t.stop()));
    osc?.stop();
    await audio?.close();
    Object.defineProperty(media, 'getUserMedia', { configurable: true, value: originalGet });
    Object.defineProperty(media, 'enumerateDevices', { configurable: true, value: originalEnum });
  }
}
