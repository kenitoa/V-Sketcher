import type { Project } from '../../../packages/project-model';
import type { MotionPlayer } from '../../../packages/motion';
import {
  TargetLock,
  NeutralCalibration,
  TrackingMapper,
  assertDetection,
  cameraError,
  type Detection,
  type Calibration,
  type Box,
  type Face,
} from '../../../packages/tracking';
export class CameraRuntime {
  owner: string | null = null;
  private closing: Promise<unknown> = Promise.resolve();
  private listeners = new Set<() => void>();
  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }
  private notify(): void {
    queueMicrotask(() => this.listeners.forEach((fn) => fn()));
  }
  readonly previewCanvas = document.createElement('canvas');
  readonly video = document.createElement('video');
  readonly target = new TargetLock();
  readonly calibration = new NeutralCalibration();
  private mapper = new TrackingMapper();
  state: 'idle' | 'connecting' | 'open' | 'failed' = 'idle';
  errorCode: string | null = null;
  workerStartReason = 'none';
  result: Detection | null = null;
  selected: Face | null = null;
  profile: Calibration | null = null;
  profileKey = '';
  frames = 0;
  stale = 0;
  lastFrame = 0;
  resolution = '';
  deviceId = '';
  sourceLabel = '';
  mirror = true;
  showPreview = false;
  reviewPrompt = '';
  reviewCanStart = false;
  reviewStartRequested = false;
  private readCheckDeferred = false;
  private generation = 0;
  private stream: MediaStream | null = null;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private lastVideoTime = -1;
  private sequence = 0;
  private project: Project | null = null;
  private busy = false;
  private settingsKey = '';
  constructor(readonly player: MotionPlayer) {
    this.video.muted = true;
    this.video.playsInline = true;
    this.video.autoplay = true;
  }
  setProject(p: Project | null, generation: string): void {
    const key = JSON.stringify(p?.tracking ?? null);
    if (this.project?.projectId !== p?.projectId || this.session !== generation) {
      this.stop();
      this.session = generation;
    }
    if (this.settingsKey !== key) {
      this.mapper.reset();
      this.settingsKey = key;
    }
    this.project = p;
  }
  private session = '';
  private mappingSince = 0;
  adoptProject(p: Project, session: string, restart = false): void {
    const key = JSON.stringify(p.tracking ?? null);
    if (restart || key !== this.settingsKey) {
      this.mapper.reset();
      this.player.controls.clearInput('camera');
      this.calibration.cancel();
    }
    if (restart) {
      this.mappingSince = performance.now();
      this.target.reset();
      this.selected = null;
    }
    this.project = p;
    this.session = session;
    this.settingsKey = key;
  }
  resources(): { liveTracks: number; state: string } {
    return {
      liveTracks: this.stream?.getTracks().filter((t) => t.readyState === 'live').length ?? 0,
      state: this.state,
    };
  }
  stopped(): Promise<unknown> {
    return this.closing;
  }
  async devices(): Promise<MediaDeviceInfo[]> {
    try {
      return (await navigator.mediaDevices.enumerateDevices()).filter(
        (d) => d.kind === 'videoinput',
      );
    } catch {
      this.errorCode = 'E_CAMERA_PERMISSION';
      return [];
    }
  }
  async start(deviceId: string): Promise<void> {
    this.stop();
    const generation = ++this.generation;
    this.state = 'connecting';
    this.errorCode = null;
    this.notify();
    this.frames = 0;
    this.stale = 0;
    this.result = null;
    this.selected = null;
    this.target.reset();
    this.mapper.reset();
    this.profile = null;
    this.profileKey = '';
    let stream: MediaStream | null = null;
    try {
      await this.closing;
      if (generation !== this.generation) return;
      const ready = await window.studio.tracking.begin(this.owner);
      if (generation !== this.generation) return;
      this.workerStartReason = ready.reason ?? 'none';
      if (!ready.ok) throw new Error(ready.errorCode ?? 'E_TRACKING_WORKER');
      stream = await navigator.mediaDevices.getUserMedia({
        video: {
          ...(deviceId ? { deviceId: { exact: deviceId } } : {}),
          width: { ideal: 640 },
          height: { ideal: 480 },
          frameRate: { ideal: 20, max: 30 },
        },
        audio: false,
      });
      if (generation !== this.generation) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      this.stream = stream;
      this.video.srcObject = stream;
      await this.video.play();
      if (generation !== this.generation) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      const track = stream.getVideoTracks()[0]!;
      const s = track.getSettings();
      this.deviceId = s.deviceId ?? deviceId;
      this.sourceLabel = track.label;
      this.resolution = `${s.width ?? this.video.videoWidth}×${s.height ?? this.video.videoHeight}`;
      const data = new TextEncoder().encode(
        'tracking-1|' + (s.deviceId ?? deviceId) + '|' + this.resolution,
      );
      this.profileKey = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', data)))
        .map((v) => v.toString(16).padStart(2, '0'))
        .join('');
      const profiles = await window.studio.tracking.profiles();
      if (generation !== this.generation) return;
      if (!profiles.ok) this.errorCode = 'E_TRACKING_CALIBRATION';
      this.profile = profiles.profiles.find((p) => p.profileKey === this.profileKey) ?? null;
      track.onended = () => {
        if (generation === this.generation) {
          this.stop();
          this.state = 'failed';
          this.errorCode = 'E_CAMERA_READ';
          this.notify();
        }
      };
      this.lastVideoTime = -1;
      this.readCheckDeferred = false;
      this.state = 'open';
      this.player.controls.recoveryEnabled = true;
      this.player.cameraLive = true;
      this.player.synthetic.camera = false;
      this.lastFrame = performance.now();
      this.notify();
      this.loop(generation);
    } catch (error) {
      stream?.getTracks().forEach((t) => t.stop());
      if (generation !== this.generation) return;
      this.stop();
      this.state = 'failed';
      this.errorCode =
        error instanceof Error &&
        ['E_TRACKING_WORKER', 'E_TRACKING_TIMEOUT', 'E_CAMERA_PERMISSION'].includes(error.message)
          ? error.message
          : cameraError(error instanceof DOMException ? error.name : 'unknown');
      this.notify();
    }
  }
  stop(): void {
    ++this.generation;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.stream?.getTracks().forEach((t) => {
      t.onended = null;
      t.stop();
    });
    this.stream = null;
    this.video.pause();
    this.video.srcObject = null;
    this.previewCanvas.width = this.previewCanvas.height = 1;
    this.deviceId = '';
    this.sourceLabel = '';
    this.player.cameraLive = false;
    this.player.controls.clearInput('camera');
    this.mapper.reset();
    this.calibration.cancel();
    this.result = null;
    this.selected = null;
    this.target.reset();
    this.state = 'idle';
    this.busy = false;
    this.notify();
    this.closing = Promise.allSettled([this.closing, window.studio.tracking.end(this.owner)]).then(
      () => undefined,
    );
  }
  select(box: Box): void {
    this.calibration.cancel();
    this.target.select(box, performance.now());
    this.mapper.reset();
    this.player.controls.clearInput('camera');
  }
  beginCalibration(): void {
    if (this.state === 'open' && this.selected) this.calibration.start(performance.now());
  }
  async applyCalibration(): Promise<boolean> {
    const value = this.calibration.candidate;
    if (!value || value.profileKey !== this.profileKey) return false;
    const generation = this.generation;
    const reply = await window.studio.tracking.saveCalibration(value);
    if (generation !== this.generation) return false;
    if (!reply.ok) {
      this.errorCode = 'E_TRACKING_CALIBRATION';
      return false;
    }
    this.profile = structuredClone(value);
    this.mapper.reset();
    this.calibration.cancel();
    this.errorCode = null;
    return true;
  }
  private loop(generation: number): void {
    if (generation !== this.generation || this.state !== 'open') return;
    const scheduled = performance.now();
    this.timer = setTimeout(() => void this.capture(generation, scheduled), 50);
  }
  private async capture(generation: number, scheduled: number): Promise<void> {
    if (generation !== this.generation || this.busy) return;
    this.busy = true;
    try {
      if (
        this.video.readyState < 2 ||
        this.video.videoWidth === 0 ||
        this.video.currentTime <= this.lastVideoTime
      ) {
        if (performance.now() - this.lastFrame > 3000) {
          if (performance.now() - scheduled >= 500 && !this.readCheckDeferred) {
            this.readCheckDeferred = true;
            return;
          }
          this.stop();
          this.state = 'failed';
          this.errorCode = 'E_CAMERA_READ';
          this.notify();
        }
        return;
      }
      this.readCheckDeferred = false;
      this.lastVideoTime = this.video.currentTime;
      const width = Math.min(640, this.video.videoWidth),
        ratio = Math.min(width / this.video.videoWidth, 480 / this.video.videoHeight);
      const canvas = this.previewCanvas;
      canvas.width = Math.round(this.video.videoWidth * ratio);
      canvas.height = Math.round(this.video.videoHeight * ratio);
      canvas
        .getContext('2d', { alpha: false, willReadFrequently: true, colorSpace: 'srgb' })!
        .drawImage(this.video, 0, 0, canvas.width, canvas.height);
      const captured = performance.now();
      const blob = await new Promise<Blob | null>((r) => canvas.toBlob(r, 'image/jpeg', 0.65));
      if (!blob) throw new Error('E_TRACKING_RESULT');
      const reply = await window.studio.tracking.frame(
        ++this.sequence,
        new Uint8Array(await blob.arrayBuffer()),
        this.owner,
      );
      if (generation !== this.generation) return;
      if (captured < this.mappingSince) {
        this.stale++;
        return;
      }
      if (!reply.ok || !reply.result) throw new Error('E_TRACKING_RESULT');
      assertDetection(reply.result);
      this.result = reply.result;
      this.frames++;
      this.lastFrame = performance.now();
      this.selected = this.target.update(this.result.faces, this.lastFrame);
      this.calibration.sample(
        this.selected,
        this.selected?.brightness ?? this.result.brightness,
        captured,
        this.profileKey,
      );
      if (this.selected && this.project) {
        const values = this.mapper.map(this.project, this.selected.values, this.profile, captured);
        if (performance.now() - captured <= 300) this.player.feedCamera(values, captured);
        else this.stale++;
      }
      this.errorCode = null;
    } catch {
      if (generation === this.generation) {
        this.stop();
        this.state = 'failed';
        this.errorCode = 'E_TRACKING_RESULT';
        this.notify();
      }
    } finally {
      this.busy = false;
      if (generation === this.generation) this.loop(generation);
    }
  }
}
