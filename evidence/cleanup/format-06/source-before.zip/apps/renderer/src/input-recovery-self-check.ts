import { clickCommittedControl } from './ui-check-control';
import type {
  SessionView,
  SessionCommand,
  SessionReply,
} from '../../../packages/project-session/contracts';
import type { CameraRuntime } from './camera-runtime';
import type { MicrophoneRuntime } from './microphone-runtime';
import { settings } from '../../../packages/expression-control';
export async function checkInputRecoveryUI(host: {
  current: () => SessionView | null;
  command: (c: SessionCommand) => Promise<SessionReply>;
  settled: () => Promise<unknown>;
  camera: CameraRuntime;
  mic: MicrophoneRuntime;
}) {
  const { camera, mic } = host;
  let stage = 'prepare',
    currentRoute = 'initial';
  const pause = (ms = 60) => new Promise((r) => setTimeout(r, ms));
  const verify = (v: unknown, code: string) => {
    if (!v) {
      window.editorFailureState = {
        code,
        inputStage: stage,
        route: currentRoute,
        microphoneState: mic.state,
        microphoneError: mic.errorCode,
        microphone: mic.diagnostics(),
        lastFailure: mic.lastFailure,
        controlOwners: [...mic.player.controls.snapshot().owners.values()],
        rms: mic.rms,
        mouth: mic.mouth,
        cameraState: camera.state,
        cameraAge: performance.now() - camera.lastFrame,
      };
      throw new Error(code);
    }
  };
  const current = () => host.current()!.project!;
  const until = async (fn: () => unknown) => {
    const end = performance.now() + 45000;
    while (!fn()) {
      window.editorFailureState = {
        inputStage: stage,
        route: currentRoute,
        cameraError: camera.errorCode,
        cameraWorkerStart: camera.workerStartReason,
        sourceAudioState: audio.state,
        receiverState: (mic as unknown as { context: AudioContext | null }).context?.state,
        trackMuted: (mic as unknown as { stream: MediaStream | null }).stream?.getAudioTracks()[0]
          ?.muted,
        sourceAudioTime: audio.currentTime,
        lastMicAge: performance.now() - mic.lastInput,
        lastCameraAge: performance.now() - camera.lastFrame,
        microphone: mic.state,
        micError: mic.errorCode,
        blocks: mic.blocks,
        calibration: mic.calibration.state,
        rms: mic.rms,
        camera: camera.state,
        faces: camera.result?.faces.length,
        target: camera.target.state,
      };
      if (performance.now() > end) throw new Error('E_INPUT_RECOVERY_UI_TIMEOUT');
      await pause();
    }
  };
  const click = async (selector: string) => {
    stage = selector;
    await clickCommittedControl(selector, host.current);
    await host.settled();
    await pause();
  };
  const media = navigator.mediaDevices,
    originalGet = media.getUserMedia,
    originalEnum = media.enumerateDevices;
  const audio = new AudioContext(),
    osc = audio.createOscillator(),
    gain = audio.createGain(),
    destination = audio.createMediaStreamDestination();
  osc.frequency.value = 220;
  gain.gain.value = 0.004;
  osc.connect(gain);
  gain.connect(destination);
  osc.start();
  await audio.resume();
  const audioStreams: MediaStream[] = [];
  const videoStreams: MediaStream[] = [];
  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 480;
  const ctx = canvas.getContext('2d')!,
    image = new Image();
  const p = await (await fetch('assets/preview-project.json')).json();
  image.src =
    'assets/preview/' +
    p.assets.find((a: { id: string }) => a.id === p.inputAssetIds[0]).fingerprint.sha256 +
    '.png';
  await image.decode();
  let dark = false,
    tick = 0;
  const draw = () => {
    ctx.fillStyle = '#777';
    ctx.fillRect(0, 0, 640, 480);
    if (!dark) ctx.drawImage(image, 300, 50, 650, 650, 80, 0, 480, 480);
    else {
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, 640, 480);
    }
    ctx.fillStyle = ++tick % 2 ? 'red' : 'blue';
    ctx.fillRect(0, 476, 4, 4);
    for (const stream of videoStreams) {
      const track = stream.getVideoTracks()[0] as CanvasCaptureMediaStreamTrack;
      if (track.readyState === 'live') track.requestFrame();
    }
  };
  draw();
  const timer = setInterval(draw, 50);
  Object.defineProperty(media, 'enumerateDevices', {
    configurable: true,
    value: async () => [
      {
        kind: 'audioinput',
        deviceId: 'audio-fixture',
        label: '합성 음량 · 실제 마이크 미사용',
        groupId: 'fixture',
      },
      {
        kind: 'videoinput',
        deviceId: 'video-fixture',
        label: '합성 얼굴 · 실제 카메라 미사용',
        groupId: 'fixture',
      },
    ],
  });
  Object.defineProperty(media, 'getUserMedia', {
    configurable: true,
    value: async (c: MediaStreamConstraints) => {
      if (c.audio) {
        const fresh = audio.createMediaStreamDestination();
        gain.connect(fresh);
        const stream = fresh.stream;
        const track = stream.getAudioTracks()[0]!,
          actual = track.getSettings();
        Object.defineProperty(track, 'getSettings', {
          value: () => ({ ...actual, deviceId: 'audio-fixture' }),
        });
        audioStreams.push(stream);
        return stream;
      }
      const stream = canvas.captureStream(20);
      videoStreams.push(stream);
      return stream;
    },
  });
  const routes: Record<string, unknown>[] = [];
  try {
    for (const route of ['parts', 'single-image', 'split-image'] as const) {
      currentRoute = route;
      gain.gain.value = 0.004;
      dark = false;
      await host.command({ type: 'new', name: '입력 복구 검증 · ' + route, sourceType: route });
      await click('[data-step="prepare"]');
      if (route === 'parts')
        await host.command({ type: 'parts-start', expectedRevision: current().revision });
      else if (route === 'single-image') {
        await host.command({ type: 'import-image' });
        await until(() => !host.current()!.input!.busy);
        const d = host.current()!.input!.draft!;
        await host.command({
          type: 'input-apply',
          draftId: d.id,
          selection: {
            rect: { x: 0, y: 0, ...d.probe.size },
            masks: [],
            occluded: false,
            backgroundTolerance: null,
          },
        });
        await until(() => !host.current()!.input!.busy);
        await host.command({
          type: 'structure-start',
          expectedRevision: current().revision,
          completion: 'estimated',
        });
        await until(() => !host.current()!.structure!.busy);
        await host.command({ type: 'structure-apply', expectedRevision: current().revision });
      } else {
        await click('[data-split-load="example"]');
        await until(
          () => !host.current()!.split!.busy && document.querySelector('[data-split-prepare]'),
        );
        await click('[data-split-prepare]');
        await until(() => !host.current()!.split!.busy);
        await click('[data-split-apply]');
        await click('[data-split-close]');
      }
      await click('[data-step="motion"]');
      await until(() => window.previewProbe?.().ready);
      await click('[data-input-open]');
      await click('[data-mic-start]');
      await until(() => mic.state === 'open' && mic.blocks >= 3);
      const frozen = JSON.stringify(current());
      await click('[data-mic-calibrate]');
      await until(() => mic.calibration.state === 'ready');
      await click('[data-mic-apply]');
      await until(() => mic.calibration.state !== 'ready');
      verify(JSON.stringify(current()) === frozen, 'E_INPUT_DEVICE_PROJECT_SEPARATION');
      const floor = mic.profile!.noiseFloor;
      await click('[data-mic-calibrate]');
      await pause(200);
      await click('[data-mic-cancel]');
      verify(mic.profile!.noiseFloor === floor, 'E_INPUT_CANCEL_FLOOR');
      const sensitivity = document.querySelector<HTMLInputElement>(
        '[data-mic-setting="sensitivity"]',
      )!;
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')!.set!.call(
        sensitivity,
        '8',
      );
      sensitivity.dispatchEvent(new Event('input', { bubbles: true }));
      await click('[data-mic-save]');
      await until(() => mic.profile!.sensitivity === 8);
      await host.command({
        type: 'expression-edit',
        expectedRevision: current().revision,
        operation: { kind: 'settings', value: { ...settings(current()), mouth: 'microphone' } },
      });
      const mouth = current().parameters.find((p) => p.previewKey === 'mouth')!;
      gain.gain.value = 0.22;
      await until(
        () =>
          mic.mouth > 0.4 && mic.player.controls.snapshot().owners.get(mouth.id) === 'microphone',
      );
      const maxMouth = mic.mouth;
      let originalCompareClock = 'NOT_APPLICABLE';
      await click('[data-input-close]');
      const original = document.querySelector<HTMLButtonElement>('[data-original]');
      if (original && !original.disabled) {
        await click('[data-original]');
        await click('[data-input-open]');
        await until(
          () =>
            mic.player.controls.snapshot().values.get(mouth.id)! >
            mouth.neutral + (mouth.max - mouth.neutral) * 0.3,
        );
        originalCompareClock = 'passed';
        await click('[data-input-close]');
        await click('[data-original]');
      }
      await click('[data-input-open]');
      gain.gain.value = 0.004;
      await until(() => mic.mouth < 0.05 && mic.blocks > 10);
      verify(mic.state === 'open', 'E_INPUT_SILENCE_NOT_FAILURE');
      await click('[data-input-camera-reconnect]');
      let cameraStartupRetries = 0;
      for (let attempt = 0; attempt < 3; attempt++) {
        await click('[data-camera-start]');
        await until(
          () =>
            camera.state === 'failed' || (camera.state === 'open' && !!camera.result?.faces.length),
        );
        if (camera.state === 'open') break;
        cameraStartupRetries++;
      }
      verify(camera.state === 'open', 'E_INPUT_CAMERA_START');
      if (camera.target.state !== 'tracked') {
        await click('[data-camera-target="0"]');
        await until(() => camera.target.state === 'tracked');
      }
      await click('[data-camera-close]');
      await click('[data-input-open]');
      let coldStartMicReconnects = 0;
      if (mic.state !== 'open') {
        coldStartMicReconnects++;
        await click('[data-mic-start]');
        await until(() => mic.state === 'open' && mic.blocks > 2);
      }
      gain.gain.value = 0.22;
      dark = true;
      await until(() => camera.result?.faces.length === 0);
      await pause(1100);
      verify(
        mic.state === 'open' &&
          mic.player.controls.snapshot().owners.get(mouth.id) === 'microphone',
        'E_INPUT_CAMERA_LOSS_AUDIO',
      );
      dark = false;
      await until(() => !!camera.result?.faces.length);
      camera.select(camera.result!.faces[0]!.box);
      await until(() => camera.target.state === 'tracked');
      await until(
        () =>
          mic.state === 'open' &&
          mic.mouth > 0.4 &&
          mic.player.controls.snapshot().owners.get(mouth.id) === 'microphone' &&
          performance.now() - mic.lastInput < 150,
      );
      const before = JSON.stringify({ parts: current().parts, motion: current().motion });
      await host.command({
        type: 'expression-edit',
        expectedRevision: current().revision,
        operation: {
          kind: 'save',
          id: null,
          name: '입 고정',
          values: [{ parameterId: mouth.id, value: mouth.neutral, locked: true }],
          transitionMs: 0,
          releaseMs: 200,
          release: 'live-input',
        },
      });
      const expression = current().expressions.at(-1)!;
      mic.player.controls.activate(expression.id, performance.now());
      await pause(300);
      verify(
        mic.player.controls.snapshot().owners.get(mouth.id) === 'expression-locked',
        'E_INPUT_EXPRESSION_LOCK',
      );
      const releaseStarted = performance.now();
      mic.player.controls.release(releaseStarted);
      await until(
        () =>
          mic.player.controls.snapshot().owners.get(mouth.id) === 'microphone' &&
          mic.lastInput >= releaseStarted,
      );
      const expressionReleaseRecoveryMs = performance.now() - releaseStarted;
      verify(expressionReleaseRecoveryMs <= 1000, 'E_INPUT_EXPRESSION_RELEASE');
      const stream = audioStreams.at(-1)!;
      stream.getAudioTracks()[0]!.stop();
      stream.getAudioTracks()[0]!.dispatchEvent(new Event('ended'));
      await until(() => mic.state === 'failed');
      verify(camera.state === 'open', 'E_INPUT_AUDIO_LOSS_CAMERA');
      await pause(800);
      verify(
        mic.player.controls.snapshot().owners.get(mouth.id) !== 'microphone',
        'E_INPUT_STALE_OPEN_MOUTH',
      );
      await click('[data-mic-start]');
      await until(() => mic.state === 'open' && mic.blocks > 2);
      verify(
        mic.profile!.noiseFloor === floor && mic.profile!.sensitivity === 8,
        'E_INPUT_RECONNECT_PROFILE',
      );
      // Suspend the actual receiving AudioContext: no level callbacks, independent display clock/watchdog must recover.
      await (mic as unknown as { context: AudioContext }).context.suspend();
      await until(() => mic.state === 'failed');
      verify(
        mic.errorCode === 'E_MIC_READ' && camera.state === 'open',
        'E_INPUT_CALLBACK_WATCHDOG',
      );
      await click('[data-mic-start]');
      await until(() => mic.state === 'open' && mic.blocks > 2);
      const activeBlocks = mic.blocks;
      camera.stop();
      await until(() => mic.blocks > activeBlocks + 2);
      verify(mic.state === 'open', 'E_INPUT_STOP_CAMERA_INDEPENDENCE');
      await click('[data-mic-stop]');
      await until(() => mic.state === 'idle');
      verify(
        audioStreams.every((s) => s.getTracks().every((t) => t.readyState === 'ended')),
        'E_INPUT_TRACK_CLEANUP',
      );
      verify(
        JSON.stringify({ parts: current().parts, motion: current().motion }) === before,
        'E_INPUT_APPEARANCE_PRESERVED',
      );
      await click('[data-input-close]');
      await host.command({ type: 'save' });
      verify(!host.current()!.dirty, 'E_INPUT_SAVE');
      const policy = JSON.stringify(current().expressionSettings);
      await host.command({ type: 'duplicate' });
      await host.command({ type: 'recent', id: host.current()!.recent[0]!.id });
      verify(
        JSON.stringify(current().expressionSettings) === policy &&
          mic.state === 'idle' &&
          camera.state === 'idle',
        'E_INPUT_REOPEN',
      );
      routes.push({
        route,
        passed: true,
        actualRoutePreparation: true,
        realAudioWorklet: true,
        independentDisplayClock: true,
        originalCompareClock,
        cameraStartupRetries,
        coldStartMicReconnects,
        syntheticDeviceIdentityStable: true,
        syntheticMediaOnly: true,
        validSilence: true,
        noiseCalibration: true,
        cancelPreservesFloor: true,
        deviceSettingsOnly: true,
        sensitivityApplied: true,
        measuredSyntheticMouth: maxMouth,
        cameraOcclusionAndMicIndependent: true,
        simulatedTrackEnded: true,
        watchdogWithoutCallbacks: true,
        expressionPriority: true,
        expressionReleaseRecoveryMs,
        manualReconnect: true,
        projectSaveReopen: true,
        appearancePreserved: true,
        rawAudioExcluded: true,
      });
      await click('[data-step="motion"]');
      await click('[data-input-open]');
      if (route !== 'split-image') await click('[data-input-close]');
    }
    await until(() => !!document.querySelector('[data-expression-preview="ready"]'));
    await pause(150);
    return {
      passed: true,
      routes,
      devicesOpened: false,
      physicalUnplug: 'NOT_RUN',
      actualHumanVoice: 'NOT_RUN',
      syntheticAudioGraph: true,
      actualLocalFaceInference: true,
      automaticReconnect: false,
      pcmSaved: false,
      framesSaved: false,
      m0: 'HOLD',
    };
  } finally {
    await mic.stop();
    camera.stop();
    clearInterval(timer);
    audioStreams.forEach((s) => s.getTracks().forEach((t) => t.stop()));
    videoStreams.forEach((s) => s.getTracks().forEach((t) => t.stop()));
    destination.stream.getTracks().forEach((t) => t.stop());
    osc.stop();
    await audio.close();
    Object.defineProperty(media, 'getUserMedia', { configurable: true, value: originalGet });
    Object.defineProperty(media, 'enumerateDevices', { configurable: true, value: originalEnum });
  }
}
