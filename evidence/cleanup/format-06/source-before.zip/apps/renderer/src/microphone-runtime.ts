import type { Project } from '../../../packages/project-model';
import type { MotionPlayer } from '../../../packages/motion';
import {
  AudioClock,
  InputWatchdog,
  MicrophoneMapper,
  NoiseCalibration,
  microphoneDefaults,
  assertMicrophoneProfile,
  type MicrophoneProfile,
} from '../../../packages/input-control';
export const microphoneErrors: Record<string, string> = {
  E_MIC_PERMISSION: '마이크 접근이 거부됐어요. Windows 개인정보 설정을 확인해 주세요.',
  E_MIC_MISSING: '선택한 마이크를 찾지 못했어요. 목록을 새로 고르고 연결해 주세요.',
  E_MIC_OPEN: '마이크를 열지 못했어요. 다른 앱의 점유·장치·드라이버 상태를 확인해 주세요.',
  E_MIC_READ: '마이크 입력이 끊겼어요. 장치를 다시 선택하고 연결해 주세요.',
  E_MIC_AUDIO: '오디오 분석을 시작하지 못했어요. 마이크를 중지하고 다시 연결해 주세요.',
  E_MIC_PROFILE: '장치 설정을 저장하지 못했어요. 이전 설정을 유지합니다.',
};
async function bounded<T>(action: Promise<T>, ms: number): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      action,
      new Promise<T>((_, reject) => {
        timer = setTimeout(() => reject(new Error('E_MIC_AUDIO')), ms);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}
export class MicrophoneRuntime {
  owner: string | null = null;
  state: 'idle' | 'connecting' | 'open' | 'failed' = 'idle';
  errorCode: string | null = null;
  deviceId = '';
  sourceLabel = '';
  reviewPrompt = '';
  profile: MicrophoneProfile | null = null;
  rms = 0;
  peak = 0;
  mouth = 0;
  blocks = 0;
  lastInput = 0;
  readonly calibration = new NoiseCalibration();
  private generation = 0;
  private stream: MediaStream | null = null;
  private context: AudioContext | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private node: AudioWorkletNode | null = null;
  private watchdog: ReturnType<typeof setInterval> | null = null;
  private mapper = new MicrophoneMapper();
  private project: Project | null = null;
  private session = '';
  private mappingSince = 0;
  private listeners = new Set<() => void>();
  private received = 0;
  private rejectedStale = 0;
  private rejectedMuted = 0;
  private lastAge: number | null = null;
  lastFailure: Record<string, unknown> | null = null;
  resources(): { liveTracks: number; audioContext: boolean; state: string } {
    return {
      liveTracks: this.stream?.getTracks().filter((t) => t.readyState === 'live').length ?? 0,
      audioContext: this.context !== null,
      state: this.state,
    };
  }
  diagnostics(): Record<string, unknown> {
    return {
      received: this.received,
      accepted: this.blocks,
      stale: this.rejectedStale,
      muted: this.rejectedMuted,
      ageMs: this.lastAge,
      contextState: this.context?.state ?? 'none',
      trackState: this.stream?.getAudioTracks()[0]?.readyState ?? 'none',
      trackMuted: this.stream?.getAudioTracks()[0]?.muted ?? false,
    };
  }
  private closing: Promise<unknown> = Promise.resolve();
  constructor(readonly player: MotionPlayer) {}
  subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  }
  private notify(): void {
    queueMicrotask(() => this.listeners.forEach((fn) => fn()));
  }
  setProject(p: Project | null, session: string): void {
    if (p?.projectId !== this.project?.projectId || session !== this.session) {
      void this.stop();
      this.session = session;
    }
    this.project = p;
  }
  adoptProject(p: Project, session: string, restart = false): void {
    this.project = p;
    this.session = session;
    if (restart) {
      this.mappingSince = performance.now();
      this.mapper.reset();
      this.player.controls.clearInput('microphone');
    }
  }
  async devices(): Promise<MediaDeviceInfo[]> {
    try {
      return (await navigator.mediaDevices.enumerateDevices()).filter(
        (d) => d.kind === 'audioinput',
      );
    } catch {
      this.errorCode = 'E_MIC_PERMISSION';
      return [];
    }
  }
  async stop(): Promise<void> {
    ++this.generation;
    this.stream?.getTracks().forEach((t) => {
      t.onended = null;
      t.stop();
    });
    this.stream = null;
    if (this.watchdog) clearInterval(this.watchdog);
    this.watchdog = null;
    if (this.node) {
      this.node.port.onmessage = null;
      this.node.port.close();
      this.node.onprocessorerror = null;
      this.node.disconnect();
    }
    this.node = null;
    this.source?.disconnect();
    this.source = null;
    const context = this.context;
    this.context = null;
    this.player.microphoneLive = false;
    this.player.controls.clearInput('microphone');
    this.mapper.reset();
    this.calibration.cancel();
    this.state = 'idle';
    this.rms = this.peak = this.mouth = 0;
    this.deviceId = '';
    this.sourceLabel = '';
    this.notify();
    this.closing = Promise.allSettled([
      this.closing,
      context?.close(),
      window.studio.microphone.end(this.owner),
    ]).then(() => undefined);
    await this.closing;
  }
  private fail(code: string): void {
    this.lastFailure = this.diagnostics();
    void this.stop();
    this.state = 'failed';
    this.errorCode = code;
    this.notify();
  }
  async start(deviceId: string): Promise<void> {
    const stopped = this.stop(),
      generation = this.generation;
    await stopped;
    if (generation !== this.generation) return;
    this.state = 'connecting';
    this.errorCode = null;
    this.profile = null;
    this.blocks = 0;
    this.received = this.rejectedStale = this.rejectedMuted = 0;
    this.lastAge = null;
    this.lastFailure = null;
    this.notify();
    let stream: MediaStream | null = null;
    let context: AudioContext | null = null;
    try {
      if (!(await window.studio.microphone.begin(this.owner))) throw new Error('E_MIC_AUDIO');
      stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          ...(deviceId ? { deviceId: { exact: deviceId } } : {}),
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false,
        },
        video: false,
      });
      if (generation !== this.generation) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      this.stream = stream;
      context = new AudioContext({ latencyHint: 'interactive' });
      this.context = context;
      await bounded(
        context.audioWorklet.addModule(
          new URL('assets/audio-level-worklet.js', document.baseURI).href,
        ),
        5000,
      );
      await bounded(context.resume(), 3000);
      if (generation !== this.generation) {
        await context.close();
        return;
      }
      const track = stream.getAudioTracks()[0]!;
      this.deviceId = track.getSettings().deviceId ?? deviceId;
      this.sourceLabel = track.label;
      const hash = await crypto.subtle.digest(
        'SHA-256',
        new TextEncoder().encode('microphone-1|' + this.deviceId + '|' + context.sampleRate),
      );
      if (generation !== this.generation) return;
      const key = Array.from(new Uint8Array(hash))
          .map((v) => v.toString(16).padStart(2, '0'))
          .join(''),
        saved = await window.studio.microphone.profiles();
      if (generation !== this.generation) return;
      this.profile = saved.profiles.find((v) => v.key === key) ?? microphoneDefaults(key);
      if (!saved.ok) this.errorCode = 'E_MIC_PROFILE';
      const node = new AudioWorkletNode(context, 'local-level', {
        numberOfInputs: 1,
        numberOfOutputs: 1,
        outputChannelCount: [1],
      });
      this.node = node;
      this.source = context.createMediaStreamSource(stream);
      this.source.connect(node);
      node.connect(context.destination);
      const clock = new AudioClock(),
        runningContext = context;
      let previous = -1;
      node.port.onmessage = (event) => {
        if (generation !== this.generation) return;
        this.received++;
        if (track.muted) {
          this.rejectedMuted++;
          return;
        }
        const v = event.data as { rms: number; peak: number; time: number; frames: number };
        const now = performance.now();
        if (
          !v ||
          Object.keys(v).sort().join(',') !== 'frames,peak,rms,time' ||
          ![v.rms, v.peak, v.time, v.frames].every(Number.isFinite) ||
          v.rms < 0 ||
          v.rms > 1 ||
          v.peak < 0 ||
          v.peak > 1 ||
          !Number.isSafeInteger(v.frames) ||
          v.frames <= previous
        )
          return;
        const time =
          runningContext.state === 'running'
            ? clock.map(v.time, runningContext.currentTime, now)
            : null;
        this.lastAge = clock.lastAgeMs;
        if (time === null || time < this.mappingSince) {
          this.rejectedStale++;
          return;
        }
        previous = v.frames;
        this.lastInput = now;
        this.blocks++;
        this.rms = v.rms;
        this.peak = v.peak;
        this.calibration.sample(v.rms, time);
        const q = this.mapper.map(v.rms, this.profile!, time);
        if (q !== null) {
          this.mouth = q;
          const p = this.project,
            param = p?.parameters.find((v) => v.previewKey === 'mouth');
          if (param) {
            const baseline =
              p!.motion?.settings.pose.find((v) => v.parameterId === param.id)?.value ??
              param.neutral;
            this.player.feedMicrophone(
              new Map([[param.id, baseline + q * (param.max - baseline)]]),
              time,
            );
          }
        }
      };
      node.onprocessorerror = () => {
        if (generation === this.generation) this.fail('E_MIC_AUDIO');
      };
      track.onended = () => {
        if (generation === this.generation) this.fail('E_MIC_READ');
      };
      this.lastInput = performance.now();
      this.state = 'open';
      this.player.microphoneLive = true;
      this.player.synthetic.microphone = false;
      this.player.controls.recoveryEnabled = true;
      const watchdog = new InputWatchdog(performance.now());
      this.watchdog = setInterval(() => {
        if (generation === this.generation && watchdog.expired(performance.now(), this.lastInput))
          this.fail('E_MIC_READ');
      }, 100);
      this.notify();
    } catch (error) {
      stream?.getTracks().forEach((t) => t.stop());
      if (context && context !== this.context) await context.close().catch(() => {});
      if (generation !== this.generation) return;
      const name = error instanceof DOMException ? error.name : '';
      this.fail(
        name === 'NotAllowedError'
          ? 'E_MIC_PERMISSION'
          : name === 'NotFoundError' || name === 'OverconstrainedError'
            ? 'E_MIC_MISSING'
            : name === 'NotReadableError'
              ? 'E_MIC_OPEN'
              : 'E_MIC_AUDIO',
      );
    }
  }
  beginCalibration(): void {
    if (this.state === 'open') this.calibration.begin(performance.now());
  }
  async save(value: MicrophoneProfile): Promise<boolean> {
    try {
      assertMicrophoneProfile(value);
    } catch {
      this.errorCode = 'E_MIC_PROFILE';
      return false;
    }
    if (!this.profile || value.key !== this.profile.key) return false;
    const generation = this.generation;
    if (!(await window.studio.microphone.save(value))) {
      this.errorCode = 'E_MIC_PROFILE';
      return false;
    }
    if (generation !== this.generation) return false;
    this.profile = structuredClone(value);
    this.mapper.reset();
    this.errorCode = null;
    return true;
  }
  async applyCalibration(): Promise<boolean> {
    if (this.calibration.state !== 'ready' || this.calibration.candidate === null || !this.profile)
      return false;
    const saved = await this.save({ ...this.profile, noiseFloor: this.calibration.candidate });
    if (saved) this.calibration.cancel();
    return saved;
  }
}
