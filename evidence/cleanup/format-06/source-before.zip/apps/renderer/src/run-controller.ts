import { MotionPlayer } from '../../../packages/motion';
import {
  availableRunActions,
  checkReadiness,
  defaultRunPreferences,
  eventAccelerator,
  freezeSnapshot,
  needsCamera,
  needsMicrophone,
  type RunAction,
  type RunLease,
  type RunMode,
  type RunPreferences,
  type ShortcutStatus,
} from '../../../packages/execution';
import {
  classifyChange,
  type RunChange,
  type InputBasis,
} from '../../../packages/execution/changes';
import type { SessionView } from '../../../packages/project-session/contracts';
import { CameraRuntime } from './camera-runtime';
import { MicrophoneRuntime } from './microphone-runtime';
import { RunSurface, type PreparedSurface } from './run-surface';
export type RunState = 'idle' | 'starting' | 'normal' | 'limited' | 'stopping' | 'failed';
export interface RunDevices {
  camera: string;
  microphone: string;
  cameraAvailable: boolean | null;
  microphoneAvailable: boolean | null;
}
export class RunRuntime {
  readonly player = new MotionPlayer();
  readonly camera = new CameraRuntime(this.player);
  readonly microphone = new MicrophoneRuntime(this.player);
  readonly surface = new RunSurface();
  lease: RunLease | null = null;
  state: RunState = 'idle';
  errorCode: string | null = null;
  hidden = false;
  preferences: RunPreferences = defaultRunPreferences();
  statuses: ShortcutStatus[] = [];
  settingsEditing = false;
  composition = false;
  lastAction: RunAction | null = null;
  changeState: 'idle' | 'preparing' | 'ready' | 'committing' = 'idle';
  changeError: string | null = null;
  autoApply = true;
  exportSource: 'working' | 'execution' = 'working';
  private outputAt = 0;
  private outputSeq = 0;
  private publishOutput(
    now: number,
    parameters: import('../../../packages/scene-core').Parameters,
    force = false,
  ): void {
    if (!this.lease || !this.active || (!force && now - this.outputAt < 1000 / 30)) return;
    this.outputAt = now;
    window.studio.broadcast.frame({
      sourceId: this.lease.requestId,
      seq: ++this.outputSeq,
      parameters,
      hidden: this.hidden,
    });
  }
  private generation = 0;
  private requestId: string | null = null;
  private rootId: string | null = null;
  private playerGeneration = '';
  private closing: Promise<unknown> = Promise.resolve();
  private animation = 0;
  private listeners = new Set<() => void>();
  private unsubscribe: () => void;
  private changeGeneration = 0;
  private candidateId: string | null = null;
  private candidate: {
    lease: RunLease;
    surface: PreparedSurface | null;
    baseId: string;
    kind: RunChange['kind'];
  } | null = null;
  private changeClosing: Promise<unknown> = Promise.resolve();
  private autoTimer: ReturnType<typeof setTimeout> | null = null;
  private latest: SessionView | null = null;
  private attempted = '';
  private boundaries = new Set<(ok: boolean) => void>();
  constructor(private beforeStart: () => Promise<void>) {
    this.unsubscribe = window.studio.run.subscribe((e) => {
      if (e.requestId === this.requestId && this.active && !this.blocked(!document.hasFocus()))
        this.action(e.action);
    });
  }
  get active(): boolean {
    return this.state === 'normal' || this.state === 'limited';
  }
  get ownerId(): string | null {
    return this.rootId;
  }
  get preparedRevision(): number | null {
    return this.candidate?.lease.revision ?? null;
  }
  subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  }
  private notify(): void {
    for (const fn of this.listeners) fn();
  }
  async init(): Promise<void> {
    const p = await window.studio.run.preferences();
    this.preferences = p.value;
    this.statuses = p.statuses;
    if (!p.ok) this.errorCode = 'E_RUN_PREFERENCES';
    this.notify();
  }
  async configure(value: RunPreferences): Promise<boolean> {
    const reply = await window.studio.run.configure(value);
    this.statuses = reply.statuses;
    if (reply.ok) {
      this.preferences = structuredClone(value);
      this.errorCode = null;
    } else this.errorCode = reply.errorCode ?? 'E_RUN_PREFERENCES';
    this.notify();
    return reply.ok;
  }
  async context(editing = this.settingsEditing): Promise<void> {
    this.settingsEditing = editing;
    if (!editing) await Promise.resolve();
    this.statuses = await window.studio.run.context(this.blocked(false), editing);
    this.notify();
  }
  blocked(outside = false): boolean {
    const element = document.activeElement as HTMLElement | null;
    return (
      this.settingsEditing ||
      this.changeState === 'committing' ||
      (!outside &&
        (this.composition ||
          !!element?.closest('input,textarea,select,[contenteditable="true"]') ||
          [...document.querySelectorAll('[role="dialog"][aria-modal="true"]')].some(
            (d) => !d.querySelector('[data-run-panel]'),
          )))
    );
  }
  connectKeyboard(): () => void {
    const key = (e: KeyboardEvent) => this.key(e),
      context = () => void this.context(),
      start = () => {
        this.composition = true;
        void this.context();
      },
      end = () => {
        this.composition = false;
        void this.context();
      };
    document.addEventListener('keydown', key, true);
    document.addEventListener('focusin', context);
    document.addEventListener('focusout', context);
    window.addEventListener('focus', context);
    window.addEventListener('blur', context);
    document.addEventListener('compositionstart', start);
    document.addEventListener('compositionend', end);
    return () => {
      document.removeEventListener('keydown', key, true);
      document.removeEventListener('focusin', context);
      document.removeEventListener('focusout', context);
      window.removeEventListener('focus', context);
      window.removeEventListener('blur', context);
      document.removeEventListener('compositionstart', start);
      document.removeEventListener('compositionend', end);
    };
  }
  key(event: KeyboardEvent): boolean {
    if (!this.active || event.repeat || event.isComposing || this.blocked()) return false;
    const chord = eventAccelerator(event);
    const binding = this.preferences.bindings.find(
      (b) => b.enabled && b.scope === 'local' && b.accelerator === chord,
    );
    if (!binding) return false;
    event.preventDefault();
    event.stopImmediatePropagation();
    return this.action(binding.action);
  }
  async start(
    view: SessionView,
    mode: RunMode,
    devices: RunDevices,
    allowLimited = false,
  ): Promise<void> {
    const stopped = this.stop(),
      generation = this.generation;
    await stopped;
    if (generation !== this.generation) return;
    const available = new Set(
      view.project?.assets
        .filter((a) => !view.issues.some((i) => i.assetId === a.id))
        .map((a) => a.id),
    );
    const readiness = checkReadiness(
      view.project,
      mode,
      available,
      { camera: devices.cameraAvailable, microphone: devices.microphoneAvailable },
      view.jobs.some((j) =>
        ['QUEUED', 'RUNNING', 'RESULT_READY', 'CANCEL_REQUESTED'].includes(j.state),
      ),
    );
    if (!readiness.canStart && !(allowLimited && readiness.canStartLimited)) {
      this.state = 'failed';
      this.errorCode =
        readiness.issues.find((i) => i.severity === 'block')?.code ?? 'E_RUN_PREPARE';
      this.notify();
      return;
    }
    const id = crypto.randomUUID();
    this.rootId = this.requestId = id;
    this.state = 'starting';
    this.errorCode = null;
    this.hidden = false;
    this.lastAction = null;
    this.player.neutralHold = false;
    this.notify();
    try {
      await this.beforeStart();
      if (generation !== this.generation) return;
      const reply = await window.studio.run.prepare({
        requestId: id,
        sessionId: view.sessionId!,
        revision: view.project!.revision,
        mode,
      });
      if (generation !== this.generation) {
        await window.studio.run.stop(id);
        return;
      }
      if (!reply.ok || !reply.lease) throw new Error(reply.errorCode ?? 'E_RUN_PREPARE');
      this.lease = freezeSnapshot(reply.lease);
      this.playerGeneration = id;
      this.player.setProject(
        this.lease.project,
        new Set(this.lease.scene.layers.map((l) => l.id)),
        id,
      );
      this.player.automaticBlink = mode === 'automatic';
      this.camera.owner = this.microphone.owner = id;
      this.camera.setProject(this.lease.project, id);
      this.microphone.setProject(this.lease.project, id);
      const prepared = await this.surface.prepare(this.lease, this.player);
      if (generation !== this.generation) {
        this.surface.discard(id);
        return;
      }
      this.surface.commit(prepared, this.player.frame(performance.now()).parameters, this.hidden);
      this.notify();
      this.clock();
      await Promise.allSettled([
        needsCamera(mode) && devices.cameraAvailable !== false
          ? this.camera.start(devices.camera)
          : Promise.resolve(),
        needsMicrophone(mode) && devices.microphoneAvailable !== false
          ? this.microphone.start(devices.microphone)
          : Promise.resolve(),
      ]);
      if (generation !== this.generation) return;
      if (
        !allowLimited &&
        ((needsCamera(mode) && this.camera.state !== 'open') ||
          (needsMicrophone(mode) && this.microphone.state !== 'open'))
      )
        throw new Error('E_RUN_DEVICE');
      this.state = 'normal';
      this.updateState(performance.now());
      this.statuses = await window.studio.run.active(id, true);
      this.notify();
      this.observe(view);
    } catch (e) {
      if (generation !== this.generation) return;
      const code = this.code(e, 'E_RUN_START');
      const stopped = this.stop(),
        stopping = this.generation;
      await stopped;
      if (stopping !== this.generation) return;
      this.state = 'failed';
      this.errorCode = code;
      this.notify();
    }
  }
  private code(e: unknown, fallback: string): string {
    return e instanceof Error && /^E_[A-Z_]{1,48}$/.test(e.message) ? e.message : fallback;
  }
  private clock(): void {
    if (this.animation) cancelAnimationFrame(this.animation);
    const tick = (now: number) => {
      if (!this.lease) return;
      try {
        const frame = this.player.frame(now);
        this.surface.draw(frame.parameters, this.hidden);
        this.updateState(now);
        this.publishOutput(now, frame.parameters);
      } catch {
        void this.failRender();
        return;
      }
      this.animation = requestAnimationFrame(tick);
    };
    this.animation = requestAnimationFrame(tick);
  }
  private updateState(now: number): void {
    if (!this.active || !this.lease) return;
    const mode = this.lease.mode;
    const degraded =
      this.lease.issues.some((i) => i.severity === 'warning') ||
      (needsCamera(mode) &&
        (this.camera.state !== 'open' ||
          !this.camera.selected ||
          now - this.camera.lastFrame > 300 ||
          !this.camera.profile)) ||
      (needsMicrophone(mode) &&
        (this.microphone.state !== 'open' ||
          !this.microphone.blocks ||
          now - this.microphone.lastInput > 150));
    const next = degraded ? 'limited' : 'normal';
    if (next !== this.state) {
      this.state = next;
      this.notify();
    }
  }
  async failRender(): Promise<void> {
    const stopped = this.stop(),
      generation = this.generation;
    await stopped;
    if (generation !== this.generation) return;
    this.state = 'failed';
    this.errorCode = 'E_RUN_RENDER';
    this.notify();
  }
  changeFor(view: SessionView): RunChange | null {
    if (!this.lease || !view.project) return null;
    return view.sessionId !== this.lease.sessionId
      ? { kind: 'restart', reason: 'project' }
      : classifyChange(this.lease.project, view.project);
  }
  observe(view: SessionView): void {
    this.latest = view;
    if (this.autoTimer) clearTimeout(this.autoTimer);
    this.autoTimer = null;
    const change = this.changeFor(view),
      key = view.sessionId + ':' + view.project?.revision;
    if (
      !this.active ||
      !this.autoApply ||
      this.changeState !== 'idle' ||
      change?.kind !== 'immediate' ||
      view.editingGroup ||
      view.saving ||
      this.attempted === key
    )
      return;
    this.autoTimer = setTimeout(() => {
      this.autoTimer = null;
      void this.applyChanges(view);
    }, 180);
  }
  setAutoApply(value: boolean): void {
    this.autoApply = value;
    if (this.latest) this.observe(this.latest);
    this.notify();
  }
  async prepareChanges(view: SessionView): Promise<boolean> {
    const kind = this.changeFor(view)?.kind;
    if (!this.active || !this.lease || !this.rootId || !view.project || !kind || kind === 'none')
      return false;
    if (this.changeState !== 'idle') return false;
    const generation = ++this.changeGeneration,
      owner = this.rootId,
      base = this.lease.requestId,
      id = crypto.randomUUID();
    this.candidateId = id;
    this.changeState = 'preparing';
    this.changeError = null;
    this.attempted = view.sessionId + ':' + view.project.revision;
    this.notify();
    try {
      await this.changeClosing;
      if (generation !== this.changeGeneration || !this.active) return false;
      const reply = await window.studio.run.prepareChange({
        ownerId: owner,
        baseId: base,
        requestId: id,
        sessionId: view.sessionId!,
        revision: view.project.revision,
      });
      if (generation !== this.changeGeneration) {
        await window.studio.run.release(id);
        return false;
      }
      if (!reply.ok || !reply.lease) throw new Error(reply.errorCode ?? 'E_RUN_CHANGE');
      const lease = freezeSnapshot(reply.lease);
      let surface: PreparedSurface | null = null;
      if (kind !== 'immediate') {
        const warm = new MotionPlayer();
        warm.setProject(lease.project, new Set(lease.scene.layers.map((l) => l.id)), id);
        warm.automaticBlink = lease.mode === 'automatic';
        surface = await this.surface.prepare(lease, warm);
      }
      if (generation !== this.changeGeneration) {
        this.surface.discard(id);
        await window.studio.run.release(id);
        return false;
      }
      this.candidate = { lease, surface, baseId: base, kind };
      this.changeState = 'ready';
      this.notify();
      return true;
    } catch (e) {
      if (generation !== this.changeGeneration) return false;
      this.surface.discard(id);
      await window.studio.run.release(id);
      if (generation !== this.changeGeneration) return false;
      this.candidateId = null;
      this.candidate = null;
      this.changeState = 'idle';
      this.changeError = this.code(e, 'E_RUN_CHANGE');
      this.notify();
      return false;
    }
  }
  private boundary(): Promise<boolean> {
    return new Promise((resolve) => {
      const done = (ok: boolean) => {
        this.boundaries.delete(done);
        resolve(ok);
      };
      this.boundaries.add(done);
      requestAnimationFrame(() => done(true));
    });
  }
  async commitChanges(restart = false): Promise<boolean> {
    const c = this.candidate,
      old = this.lease,
      owner = this.rootId,
      generation = this.changeGeneration;
    if (!c || !old || !owner || this.changeState !== 'ready') return false;
    if (c.kind === 'restart' && !restart) {
      this.changeError = 'E_RUN_RESTART';
      this.notify();
      return false;
    }
    this.changeState = 'committing';
    this.notify();
    let committed = false;
    const oldPlayerGeneration = this.playerGeneration,
      expression = this.player.controls.snapshot().activeId;
    try {
      await window.studio.run.context(true, true);
      if (generation !== this.changeGeneration || !this.active) return false;
      const reply = await window.studio.run.commitChange({
        ownerId: owner,
        baseId: c.baseId,
        requestId: c.lease.requestId,
        restart,
      });
      if (!reply.ok) throw new Error(reply.errorCode ?? 'E_RUN_CHANGE');
      committed = true;
      this.requestId = c.lease.requestId;
      if (!(await this.boundary()) || generation !== this.changeGeneration || !this.active)
        return false;
      try {
        this.playerGeneration = restart ? c.lease.requestId : this.playerGeneration;
        this.player.setProject(
          c.lease.project,
          new Set(c.lease.scene.layers.map((l) => l.id)),
          this.playerGeneration,
        );
        this.player.controls.recoveryEnabled =
          this.camera.state === 'open' || this.microphone.state === 'open';
        this.camera.adoptProject(c.lease.project, this.playerGeneration, restart);
        this.microphone.adoptProject(c.lease.project, this.playerGeneration, restart);
        if (c.surface)
          this.surface.commit(
            c.surface,
            this.player.frame(performance.now()).parameters,
            this.hidden,
          );
        else this.surface.draw(this.player.frame(performance.now()).parameters, this.hidden);
        this.surface.retag(c.lease);
        this.lease = c.lease;
      } catch (e) {
        this.playerGeneration = oldPlayerGeneration;
        this.player.setProject(
          old.project,
          new Set(old.scene.layers.map((l) => l.id)),
          oldPlayerGeneration,
        );
        this.camera.adoptProject(old.project, oldPlayerGeneration, true);
        this.microphone.adoptProject(old.project, oldPlayerGeneration, true);
        if (expression && old.project.expressions.some((v) => v.id === expression))
          this.player.controls.activate(expression, performance.now());
        throw e;
      }
      this.candidate = null;
      this.candidateId = null;
      await window.studio.run.release(old.requestId);
      if (generation !== this.changeGeneration) return false;
      this.changeState = 'idle';
      this.changeError = null;
      this.statuses = await window.studio.run.active(c.lease.requestId, true);
      await this.context(false);
      this.updateState(performance.now());
      this.notify();
      if (this.latest) this.observe(this.latest);
      return true;
    } catch (e) {
      if (generation !== this.changeGeneration) return false;
      if (committed) {
        const rolled = await window.studio.run.rollbackChange(
          owner,
          c.lease.requestId,
          old.requestId,
        );
        if (!rolled.ok) {
          await this.stop();
          this.errorCode = 'E_RUN_CHANGE';
          return false;
        }
        this.requestId = old.requestId;
      }
      this.surface.discard(c.lease.requestId);
      await window.studio.run.release(c.lease.requestId);
      this.candidate = null;
      this.candidateId = null;
      this.changeState = 'idle';
      this.changeError = this.code(e, 'E_RUN_CHANGE');
      await this.context(false);
      this.notify();
      return false;
    }
  }
  async applyChanges(view: SessionView, restart = false): Promise<boolean> {
    return (await this.prepareChanges(view)) ? this.commitChanges(restart) : false;
  }
  async cancelChange(): Promise<void> {
    if (this.changeState === 'committing') return;
    ++this.changeGeneration;
    const id = this.candidateId;
    this.candidateId = null;
    this.candidate = null;
    this.changeState = 'idle';
    if (id) {
      this.surface.discard(id);
      this.changeClosing = window.studio.run.release(id);
      await this.changeClosing;
    }
    this.notify();
  }
  async basis(view: SessionView): Promise<InputBasis | null> {
    const p = this.exportSource === 'execution' ? this.lease?.project : view.project;
    if (!p) return null;
    const result = await window.studio.run.inputBasis(this.exportSource, p.projectId, p.revision);
    return result.ok ? (result.basis ?? null) : null;
  }
  action(action: RunAction): boolean {
    if (
      !this.active ||
      !this.lease ||
      this.changeState === 'committing' ||
      !availableRunActions(this.lease.project, this.lease.mode).includes(action)
    )
      return false;
    this.lastAction = action;
    const now = performance.now();
    if (action === 'neutral') this.player.neutralHold = !this.player.neutralHold;
    else if (action === 'release') this.player.controls.release(now);
    else if (action === 'hide') this.hidden = !this.hidden;
    else if (action === 'recalibrate') {
      if (!this.camera.selected) {
        this.errorCode = 'E_RUN_CALIBRATION';
        this.notify();
        return false;
      }
      this.camera.beginCalibration();
    } else if (action === 'stop') void this.stop();
    else {
      const slot = Number(action.slice(-1)) - 1,
        id = this.lease.project.expressionSettings?.shortcuts[slot];
      if (id) this.player.controls.activate(id, now);
    }
    if (this.active) {
      const p = this.player.frame(now).parameters;
      this.surface.draw(p, this.hidden);
      this.publishOutput(now, p, true);
    }
    this.notify();
    return true;
  }
  async reconnect(which: 'camera' | 'microphone', deviceId: string): Promise<void> {
    if (!this.active || !this.lease) return;
    const id = this.requestId;
    if (which === 'camera' && needsCamera(this.lease.mode)) await this.camera.start(deviceId);
    else if (which === 'microphone' && needsMicrophone(this.lease.mode))
      await this.microphone.start(deviceId);
    if (id === this.requestId) this.updateState(performance.now());
  }
  async stop(): Promise<void> {
    const generation = ++this.generation;
    ++this.changeGeneration;
    if (this.autoTimer) clearTimeout(this.autoTimer);
    this.autoTimer = null;
    for (const done of [...this.boundaries]) done(false);
    this.surface.clear();
    const owner = this.rootId;
    this.rootId = this.requestId = null;
    this.candidateId = null;
    this.candidate = null;
    this.changeState = 'idle';
    this.changeError = null;
    if (!owner && !this.lease) {
      await this.closing;
      if (generation === this.generation) {
        this.state = 'idle';
        this.notify();
      }
      return;
    }
    this.state = 'stopping';
    if (this.animation) cancelAnimationFrame(this.animation);
    this.animation = 0;
    this.camera.stop();
    const pending = Promise.allSettled([
      this.camera.stopped(),
      this.microphone.stop(),
      owner ? window.studio.run.stop(owner) : Promise.resolve(),
      window.studio.run.context(false, false),
      this.changeClosing,
    ]);
    this.closing = Promise.allSettled([this.closing, pending]).then(() => undefined);
    await this.closing;
    if (generation !== this.generation) return;
    this.lease = null;
    this.player.neutralHold = false;
    this.player.automaticBlink = false;
    this.player.setProject(null);
    this.hidden = false;
    this.settingsEditing = false;
    this.state = 'idle';
    this.notify();
  }
  async dispose(): Promise<void> {
    await this.stop();
    this.unsubscribe();
    this.listeners.clear();
  }
}
