import { clickCommittedControl } from './ui-check-control';
import type {
  SessionCommand,
  SessionReply,
  SessionView,
} from '../../../packages/project-session/contracts';
import { layerCorners } from '../../../packages/editor-view';
import { focusable } from './ui-foundations';
import { checkVisibleContrast } from './contrast-self-check';
const wait = (ms = 25): Promise<void> => new Promise((r) => setTimeout(r, ms));
export async function checkEditorUI(host: {
  current: () => SessionView | null;
  command: (c: SessionCommand) => Promise<SessionReply>;
  settled: () => Promise<unknown>;
}): Promise<Record<string, unknown>> {
  let phase = 'START';
  const verify = (v: unknown, code = 'E_EDITOR_' + phase): void => {
    if (!v) throw new Error(code);
  };
  const until = async (predicate: () => unknown): Promise<void> => {
    const start = performance.now();
    while (!predicate()) {
      if (performance.now() - start > 10000) throw new Error('E_EDITOR_UI_TIMEOUT');
      await wait(20);
    }
  };
  const click = async (selector: string): Promise<void> => {
    await clickCommittedControl(selector, host.current);
    await wait();
    await host.settled();
    await new Promise<void>((resolve) =>
      requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
    );
    await wait();
  };
  phase = 'PREVIEW';
  await window.projectSelfCheckCapture!();
  await until(() => window.previewProbe?.().ready);
  await click('[data-step="appearance"]');
  const original = JSON.stringify(host.current()!.project);
  const p = host.current()!.project!;
  const part = p.parts[1]!;
  await click(`[data-part-id="${part.id}"]`);
  verify(document.querySelector<HTMLSelectElement>('[data-part-select]')?.value === part.id);
  const layer = host.current()!.scene!.layers.find((l) => l.id === part.id)!;
  const corners = layerCorners(layer);
  const xs = corners.map((p) => p.x);
  const ys = corners.map((p) => p.y);
  let point: { x: number; y: number } | null = null;
  for (let y = 1; y < 12 && !point; y++)
    for (let x = 1; x < 12; x++) {
      const candidate = {
        x: Math.min(...xs) + ((Math.max(...xs) - Math.min(...xs)) * x) / 12,
        y: Math.min(...ys) + ((Math.max(...ys) - Math.min(...ys)) * y) / 12,
      };
      if (window.previewProbe!().hit(candidate) === part.id) {
        point = candidate;
        break;
      }
    }
  verify(point, 'E_EDITOR_ALPHA_HIT');
  await click(`[data-part-id="${p.parts[0]!.id}"]`);
  const pick = async (): Promise<void> => {
    const target = document.querySelector<HTMLElement>('[data-viewport]')!;
    const at = window.previewProbe!().toClient(point!);
    target.dispatchEvent(
      new PointerEvent('pointerdown', {
        clientX: at.x,
        clientY: at.y,
        button: 0,
        pointerId: 1,
        bubbles: true,
      }),
    );
    target.dispatchEvent(
      new PointerEvent('pointerup', {
        clientX: at.x,
        clientY: at.y,
        button: 0,
        pointerId: 1,
        bubbles: true,
      }),
    );
    await wait();
    verify(
      document.querySelector('[data-viewport]')?.getAttribute('data-selected') === part.id,
      'E_EDITOR_POINTER_SELECT',
    );
  };
  phase = 'PICK';
  await pick();
  await click('[data-zoom-in]');
  await pick();
  const stage = document.querySelector<HTMLElement>('[data-viewport]')!;
  stage.dispatchEvent(
    new KeyboardEvent('keydown', { key: 'ArrowRight', shiftKey: true, bubbles: true }),
  );
  await wait();
  verify(window.previewProbe!().view.pan.x === 20);
  await pick();
  await click('[data-hand]');
  const box = stage.getBoundingClientRect();
  stage.dispatchEvent(
    new PointerEvent('pointerdown', {
      clientX: box.x + 100,
      clientY: box.y + 100,
      button: 0,
      pointerId: 2,
      bubbles: true,
    }),
  );
  stage.dispatchEvent(
    new PointerEvent('pointermove', {
      clientX: box.x + 140,
      clientY: box.y + 120,
      pointerId: 2,
      bubbles: true,
    }),
  );
  stage.dispatchEvent(
    new PointerEvent('pointerup', {
      clientX: box.x + 140,
      clientY: box.y + 120,
      pointerId: 2,
      bubbles: true,
    }),
  );
  await wait();
  verify(window.previewProbe!().view.pan.x === 60);
  await click('[data-hand]');
  await pick();
  phase = 'COMPARE';
  const bg = document.querySelector<HTMLSelectElement>('[data-background]')!;
  bg.value = 'dark';
  bg.dispatchEvent(new Event('change', { bubbles: true }));
  await click('[data-guides]');
  verify(stage.classList.contains('bg-dark'));
  await click('[data-original]');
  await until(() => window.previewProbe!().ready && window.previewProbe!().compare);
  verify(window.previewProbe!().report!.textureCount === 1);
  await click('[data-original]');
  await until(() => window.previewProbe!().ready && !window.previewProbe!().compare);
  await click('[data-fit]');
  verify(window.previewProbe!().view.zoom === 1 && window.previewProbe!().view.pan.x === 0);
  phase = 'VIEW_DATA';
  verify(JSON.stringify(host.current()!.project) === original, 'E_EDITOR_VIEW_MUTATED_DATA');
  phase = 'STEP_EDIT';
  const field = document.querySelector<HTMLInputElement>('[data-part-name]')!;
  field.focus();
  field.value = '내가 고른 눈';
  field.dispatchEvent(
    new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true }),
  );
  document.querySelector<HTMLButtonElement>('[data-step="prepare"]')!.focus();
  await host.settled();
  await new Promise<void>((resolve) =>
    requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
  );
  await wait();
  verify(host.current()!.project!.parts[1]!.displayName === '내가 고른 눈', 'E_EDITOR_RENAME');
  await click('[data-step="prepare"]');
  await click('[data-step="review"]');
  await click('[data-step="appearance"]');
  verify(
    document.querySelector<HTMLInputElement>('[data-part-name]')?.value === '내가 고른 눈',
    'E_EDITOR_STEP_RESTORE',
  );
  await click('[data-project="undo"]');
  verify(
    JSON.stringify(host.current()!.project!.parts) === JSON.stringify(p.parts),
    'E_EDITOR_UNDO',
  );
  phase = 'STEP_DONE';
  await click('[data-appearance-done]');
  verify(document.querySelector('[data-step="appearance"]')?.textContent?.includes('완료'));
  await click('[data-step="review"]');
  phase = 'RESOURCE_CHECK';
  await click('[data-project="check-resources"]');
  await until(() => host.current()?.jobs.at(-1)?.state === 'SUCCEEDED');
  await until(
    () =>
      document.querySelector('[data-task-state]')?.getAttribute('data-task-state') === 'SUCCEEDED',
  );
  verify(document.querySelector('[data-task-state]')?.textContent?.includes('완료'));
  phase = 'NOTICE';
  const current = host.current()!.project!;
  const invalid = await host.command({
    type: 'edit',
    target: 'part-role',
    id: current.parts[1]!.id,
    parameterId: null,
    value: 'invalid-role',
    expectedRevision: current.revision,
    groupId: null,
  });
  verify(invalid.view.errorCode === 'E_PROJECT_SCHEMA');
  await wait();
  verify(document.querySelector('[role="alert"]')?.textContent?.includes('유지'));
  await click('[data-notice-action]');
  await until(() => document.activeElement?.hasAttribute('data-part-name'));
  phase = 'FOCUS';
  const helpButton = document.querySelector<HTMLButtonElement>('[data-help]')!;
  helpButton.focus();
  await click('[data-help]');
  const dialog = document.querySelector<HTMLElement>('[role="dialog"]')!;
  verify(dialog.contains(document.activeElement) && document.getElementById('root')!.inert);
  const savedBeforeModalShortcut = host.current()!.project!.savedRevision;
  document.dispatchEvent(
    new KeyboardEvent('keydown', { key: 's', ctrlKey: true, bubbles: true, cancelable: true }),
  );
  await host.settled();
  await new Promise<void>((resolve) =>
    requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
  );
  await wait();
  verify(
    host.current()!.project!.savedRevision === savedBeforeModalShortcut,
    'E_EDITOR_MODAL_SHORTCUT',
  );
  const items = focusable(dialog);
  items.at(-1)!.focus();
  document.dispatchEvent(
    new KeyboardEvent('keydown', { key: 'Tab', bubbles: true, cancelable: true }),
  );
  verify(document.activeElement === items[0]);
  document.dispatchEvent(
    new KeyboardEvent('keydown', { key: 'Tab', shiftKey: true, bubbles: true, cancelable: true }),
  );
  verify(document.activeElement === items.at(-1));
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  await wait();
  verify(
    !document.querySelector('[role="dialog"]') &&
      document.activeElement === helpButton &&
      !document.getElementById('root')!.inert,
  );
  phase = 'CONTRAST';
  const contrast = checkVisibleContrast();
  window.editorFailureState = { contrast };
  verify(contrast.passed);
  phase = 'NEW_CANCEL';
  const before = JSON.stringify(host.current()!.project);
  await click('[data-new-project]');
  await click('[data-new-route="single-image"]');
  await click('[data-new-cancel]');
  verify(JSON.stringify(host.current()!.project) === before);
  await host.command({ type: 'check-resources' });
  await until(() => host.current()?.jobs.at(-1)?.state === 'SUCCEEDED');
  phase = 'ROUTES';
  const routes = host
    .current()!
    .recent.filter((r) => ['parts', 'single-image', 'split-image'].includes(r.sourceType));
  const seen = new Set<string>();
  for (const r of routes) {
    if (seen.has(r.sourceType)) continue;
    await host.command({ type: 'recent', id: r.id });
    await wait();
    verify(
      document.querySelectorAll('[data-step]').length === 4 &&
        document.querySelector('[data-viewport]'),
    );
    seen.add(r.sourceType);
  }
  verify(seen.size === 3);
  await host.command({ type: 'close' });
  await wait();
  return {
    passed: true,
    contrast,
    threeRouteCommonScreen: true,
    alphaAwarePointerSelection: true,
    listSelectionSynced: true,
    zoomPanFit: true,
    viewDoesNotEditProject: true,
    originalActualTexture: true,
    backgroundAndGuidesLocal: true,
    stageEditPreserved: true,
    stageCompletionExplicit: true,
    realResourceCheck: true,
    structuredErrorFixFocus: true,
    modalFocusTrapAndRestore: true,
    modalShortcutBlocked: true,
    newRouteCancelPreserved: true,
    keyboardViewport: true,
    scope:
      'Scripted DOM events and actual GPU/IPC/files; not manual novice or assistive-technology certification',
  };
}
