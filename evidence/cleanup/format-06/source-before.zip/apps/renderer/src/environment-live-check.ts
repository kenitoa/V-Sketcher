import type { RunRuntime } from './run-runtime';
import type {
  SessionView,
  SessionCommand,
  SessionReply,
} from '../../../packages/project-session/contracts';
/** Explicit developer CLI only. Raw video is displayed in memory and is never an artifact. */
export async function checkEnvironmentLive(host: {
  current: () => SessionView | null;
  command: (c: SessionCommand) => Promise<SessionReply>;
  run: RunRuntime;
}) {
  const { run } = host,
    pause = (ms: number) => new Promise((r) => setTimeout(r, ms));
  await host.command({ type: 'new', name: '실제 실행 연결 확인', sourceType: 'parts' });
  await host.command({ type: 'sample' });
  const panel = document.createElement('dialog');
  panel.className = 'environment-live-dialog';
  panel.innerHTML =
    '<h2>실제 장치 연결 확인</h2><p>본인의 실사 얼굴이 보이는 카메라와 사용할 마이크를 선택하세요. 영상·원음은 저장하지 않습니다.</p><div class="live-device-controls"><label>카메라 <select data-live-camera></select></label><label>마이크 <select data-live-microphone></select></label><button data-live-refresh>목록 새로 확인</button><button data-live-connect>선택 장치 연결</button></div><div class="live-device-previews"><canvas data-live-video width="480" height="360"></canvas><div data-live-character></div></div><p data-live-status></p><label class="live-device-attestation"><input data-live-attest type="checkbox">미리보기 영상에 제 실사 얼굴이 보입니다</label><div class="live-device-actions"><button data-live-calibrate>정면 중립 보정 시작</button><button data-live-apply>보정 후보 적용</button><button data-live-select>검출된 얼굴 다시 선택</button></div><p data-live-calibration></p><div class="live-device-actions"><button data-live-start disabled>실제 시험 시작</button><button data-live-cancel>취소·장치 해제</button></div><h3 data-live-step>장치를 연결하고 얼굴·마이크 상태를 확인하세요.</h3>';
  document.body.appendChild(panel);
  panel.showModal();
  const el = <T extends HTMLElement>(selector: string) => panel.querySelector<T>(selector)!,
    camera = el<HTMLSelectElement>('[data-live-camera]'),
    mic = el<HTMLSelectElement>('[data-live-microphone]'),
    video = el<HTMLCanvasElement>('[data-live-video]');
  el('[data-live-character]').appendChild(run.surface.element);
  run.surface.element.style.height = '360px';
  let cancelled = false,
    started = false,
    connecting = false,
    phase = 'prepare';
  const measures: {
    phase: string;
    faces: number;
    brightness: number;
    cameraAge: number;
    micAge: number;
    rms: number;
    values: Record<string, number>;
  }[] = [];
  const list = async () => {
    const ds = await navigator.mediaDevices.enumerateDevices();
    for (const [select, kind] of [
      [camera, 'videoinput'],
      [mic, 'audioinput'],
    ] as const) {
      const old = select.value;
      select.replaceChildren();
      const def = document.createElement('option');
      def.value = '';
      def.textContent = 'Windows 기본 장치';
      select.appendChild(def);
      for (const [i, d] of ds.filter((d) => d.kind === kind).entries()) {
        const option = document.createElement('option');
        option.value = d.deviceId;
        option.textContent = d.label || `${kind === 'videoinput' ? '카메라' : '마이크'} ${i + 1}`;
        select.appendChild(option);
      }
      if ([...select.options].some((o) => o.value === old)) select.value = old;
    }
  };
  el('[data-live-refresh]').onclick = () => void list();
  el('[data-live-connect]').onclick = () => {
    if (connecting) return;
    connecting = true;
    void run
      .start(
        host.current()!,
        'camera-microphone',
        {
          camera: camera.value,
          microphone: mic.value,
          cameraAvailable: true,
          microphoneAvailable: true,
        },
        true,
      )
      .then(list)
      .finally(() => {
        connecting = false;
      });
  };
  el('[data-live-select]').onclick = () => {
    const faces = run.camera.result?.faces ?? [];
    if (faces.length === 1) run.camera.select(faces[0]!.box);
  };
  el('[data-live-calibrate]').onclick = () => run.camera.beginCalibration();
  el('[data-live-apply]').onclick = () => void run.camera.applyCalibration();
  el('[data-live-start]').onclick = () => {
    started = true;
  };
  el('[data-live-cancel]').onclick = () => {
    cancelled = true;
  };
  panel.addEventListener('cancel', (e) => {
    e.preventDefault();
    cancelled = true;
  });
  await list();
  const sample = () => {
    const c = run.camera,
      m = run.microphone,
      now = performance.now(),
      ready =
        run.active &&
        c.state === 'open' &&
        !!c.selected &&
        c.selected.brightness >= 35 &&
        now - c.lastFrame < 400 &&
        m.state === 'open' &&
        m.blocks > 0 &&
        now - m.lastInput < 250 &&
        el<HTMLInputElement>('[data-live-attest]').checked;
    el<HTMLButtonElement>('[data-live-start]').disabled = !ready;
    el<HTMLButtonElement>('[data-live-select]').disabled = run.camera.result?.faces.length !== 1;
    el('[data-live-status]').textContent =
      `카메라 ${c.state} · 처리 ${c.frames}프레임 · 영상 밝기 ${c.result?.brightness.toFixed(0) ?? '대기'} /255 · 얼굴 ${c.result?.faces.length ?? 0}명 · 선택 얼굴 밝기 ${c.selected?.brightness.toFixed(0) ?? '미검출'} /255 · 마이크 ${m.state} · 음량 ${m.rms.toFixed(4)}`;
    el('[data-live-calibration]').textContent =
      `보정: ${c.calibration.state} · ${c.profile ? '적용된 중립 기준 있음' : '적용된 중립 기준 없음'}`;
    if (c.previewCanvas.width > 1)
      video.getContext('2d')!.drawImage(c.previewCanvas, 0, 0, 480, 360);
    if (phase !== 'prepare')
      measures.push({
        phase,
        faces: c.result?.faces.length ?? 0,
        brightness: c.selected?.brightness ?? 0,
        cameraAge: now - c.lastFrame,
        micAge: now - m.lastInput,
        rms: m.rms,
        values: { ...(c.selected?.values ?? {}) },
      });
    window.environmentLiveState = {
      phase,
      ready,
      faces: c.result?.faces.length ?? 0,
      camera: c.state,
      frameCount: c.frames,
      frameAgeMs: c.lastFrame ? Math.max(0, now - c.lastFrame) : null,
      previewBrightness: c.result?.brightness ?? null,
      inferenceMs: c.result?.inferenceMs ?? null,
      blocks: m.blocks,
      cameraError: c.errorCode,
      microphoneError: m.errorCode,
      microphone: m.state,
      microphoneDiagnostics: m.diagnostics(),
      microphoneFailure: m.lastFailure,
    };
  };
  const timer = setInterval(sample, 100),
    deadline = Date.now() + 600000;
  try {
    while (!started && !cancelled && Date.now() < deadline) await pause(100);
    if (!started) throw new Error('E_LIVE_CANCELLED');
    await window.studio.broadcast.start(run.lease!.requestId);
    const steps: [string, number, string][] = [
      ['front', 6000, '정면을 편하게 유지해 주세요.'],
      ['motion', 10000, '눈을 여러 번 깜빡이고 고개를 좌우로 천천히 움직여 주세요.'],
      ['quiet', 6000, '말하지 않고 조용히 있어 주세요.'],
      ['speech', 10000, '계속 편하게 말해 주세요. 마지막에는 저장 표정도 자동 시험합니다.'],
    ];
    for (const [key, ms, instruction] of steps) {
      phase = key;
      el('[data-live-step]').textContent = instruction;
      const until = Date.now() + ms;
      while (Date.now() < until) {
        if (cancelled) throw new Error('E_LIVE_CANCELLED');
        await pause(100);
      }
    }
    const ranges = (key: string) => {
        const values = measures
          .filter((s) => s.phase === 'motion' && s.faces > 0)
          .map((s) => s.values[key]!)
          .filter(Number.isFinite);
        return values.length ? Math.max(...values) - Math.min(...values) : 0;
      },
      average = (key: 'quiet' | 'speech') => {
        const values = measures.filter((s) => s.phase === key).map((s) => s.rms);
        return values.reduce((a, b) => a + b, 0) / Math.max(1, values.length);
      };
    const measuredSamples = measures.length;
    const good =
        measures.filter(
          (s) => s.faces > 0 && s.brightness >= 35 && s.cameraAge < 500 && s.micAge < 300,
        ).length / Math.max(1, measures.length),
      yaw = ranges('head_yaw'),
      eyes = Math.max(ranges('eye_left'), ranges('eye_right')),
      quiet = average('quiet'),
      speech = average('speech');
    const expression = run.lease!.project.expressions.at(-1);
    if (expression) {
      run.player.controls.activate(expression.id, performance.now());
      phase = 'expression';
      el('[data-live-step]').textContent = '저장 표정을 4초간 확인합니다.';
      await pause(4000);
      run.player.controls.release(performance.now());
    }
    const passed =
      good >= 0.8 && yaw >= 5 && eyes >= 0.08 && speech > quiet * 1.25 && speech > 0.001;
    await run.stop();
    return {
      passed,
      method: 'HUMAN_STARTED_REAL_MEDIA_STREAMS',
      realFacePreviewAttested: true,
      actualDeviceSelectionByUser: true,
      samples: measuredSamples,
      validInputFraction: good,
      headYawRangeDegrees: yaw,
      eyeRange: eyes,
      quietRms: quiet,
      speechRms: speech,
      expressionPlayed: !!expression,
      editorAndExecutionResourcesReleased:
        run.camera.resources().liveTracks === 0 &&
        run.microphone.resources().liveTracks === 0 &&
        !run.microphone.resources().audioContext,
      rawCameraFramesStored: false,
      rawAudioStored: false,
      profileApplied: !!run.camera.profile,
      physicalDeviceCompatibilityApproval: false,
      scope:
        'Live connection, changes and explicit resource release; not complete T190 protocol, all hardware compatibility, performance latency or M0 acceptance',
      m0: 'HOLD',
    };
  } finally {
    clearInterval(timer);
    await run.stop();
    window.environmentLiveState = { phase: 'finished', ready: false };
    panel.close();
    panel.remove();
    run.surface.element.style.height = '';
  }
}
