import { clickCommittedControl } from './ui-check-control';
import type {
  SessionCommand,
  SessionReply,
  SessionView,
} from '../../../packages/project-session/contracts';
import type { SplitDraft, LayerConfig } from '../../../packages/split-image/types';
import { effective } from '../../../packages/split-image/types';
import { AvatarRenderer } from '../../../packages/avatar-renderer';
import type { PreviewScene, Parameters } from '../../../packages/scene-core';
export interface SplitFixtureRow {
  name: string;
  sourceId: string;
  origin: [number, number];
  role: LayerConfig['role'];
  side: LayerConfig['side'];
  z: number;
  visible: boolean;
  opacity: number;
  usage: LayerConfig['usage'];
  variantOf: string | null;
  state: LayerConfig['state'];
}
export async function splitPixels(scene: PreviewScene, d: SplitDraft) {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 640;
  const r = new AvatarRenderer(canvas, scene);
  await r.load(document.baseURI);
  r.draw();
  r.gl.finish();
  const read = () => {
      const p = new Uint8Array(512 * 640 * 4);
      r.gl.readPixels(0, 0, 512, 640, r.gl.RGBA, r.gl.UNSIGNED_BYTE, p);
      return p;
    },
    neutral = read();
  const ref = document.createElement('canvas');
  ref.width = d.canvas.width;
  ref.height = d.canvas.height;
  const ctx = ref.getContext('2d')!;
  for (const l of [...d.layers]
    .sort((a, b) => a.z - b.z || (a.sourceId < b.sourceId ? -1 : 1))
    .filter((l) => l.usage !== 'alternative' && effective(d, l).visible)) {
    const image = new Image();
    image.src = `assets/session/${d.id}/${l.imageHash}.png`;
    await image.decode();
    ctx.globalAlpha = effective(d, l).opacity;
    ctx.drawImage(image, ...l.origin);
  }
  const small = document.createElement('canvas');
  small.width = 512;
  small.height = 640;
  const c = small.getContext('2d')!;
  c.drawImage(ref, 0, 0, 512, 640);
  const cpu = c.getImageData(0, 0, 512, 640).data;
  let total = 0,
    alpha = 0;
  for (let y = 0; y < 640; y++)
    for (let x = 0; x < 512; x++) {
      const a = (y * 512 + x) * 4,
        b = ((639 - y) * 512 + x) * 4;
      for (let k = 0; k < 4; k++) {
        const expected = k === 3 ? cpu[a + k]! : (cpu[a + k]! * cpu[a + 3]!) / 255;
        const diff = Math.abs(expected - neutral[b + k]!);
        total += diff;
        if (k === 3) alpha += diff;
      }
    }
  const defaults = scene.defaults!,
    inputs: Parameters[] = [{ ...defaults }];
  for (const key of Object.keys(defaults) as (keyof Parameters)[])
    for (const value of [key.startsWith('head') ? -1 : 0, 0.5, 1])
      inputs.push({ ...defaults, [key]: value });
  for (const head_yaw of [-1, 0, 1])
    for (const head_roll of [-1, 0, 1]) inputs.push({ ...defaults, head_yaw, head_roll });
  const hashes = new Set<string>(),
    sheet = document.createElement('canvas');
  sheet.width = 1280;
  sheet.height = Math.ceil(inputs.length / 5) * 320;
  const s = sheet.getContext('2d')!;
  s.fillStyle = '#302737';
  s.fillRect(0, 0, sheet.width, sheet.height);
  const uploads = r.report().staticBufferUploads;
  let i = 0;
  for (const input of inputs) {
    r.draw(input);
    r.gl.finish();
    hashes.add(String(r.report().pixelHash));
    s.drawImage(canvas, (i % 5) * 256, Math.floor(i / 5) * 320, 256, 320);
    i++;
  }
  const info = r.report();
  r.dispose();
  window.splitExtremeData = sheet.toDataURL('image/png');
  return {
    passed:
      total / cpu.length < 1 &&
      alpha / (512 * 640) < 1 &&
      hashes.size >= 10 &&
      info.glError === 0 &&
      info.staticBufferUploads === uploads,
    frames: i,
    uniqueFrames: hashes.size,
    neutralMeanDifference: total / cpu.length,
    neutralAlphaMeanDifference: alpha / (512 * 640),
    glClean: info.glError === 0,
    buffersStable: info.staticBufferUploads === uploads,
    reference:
      'Independent Canvas2D composition of source PNG coordinates/order/group alpha, compared with common GPU premultiplied pixels',
  };
}
export async function checkSplitUI(
  host: {
    current: () => SessionView | null;
    command: (c: SessionCommand) => Promise<SessionReply>;
    settled: () => Promise<unknown>;
  },
  rows: SplitFixtureRow[],
) {
  let control = 'initial';
  const pause = () =>
    new Promise<void>((r) => requestAnimationFrame(() => requestAnimationFrame(() => r())));
  const verify = (value: unknown, code: string) => {
    if (!value) throw new Error(code);
  };
  const until = async (test: () => boolean) => {
    const start = Date.now();
    while (!test()) {
      const v = host.current();
      window.editorFailureState = {
        splitControl: control,
        sequence: v?.sequence,
        errorCode: v?.errorCode,
        splitState: v?.split?.state,
        splitError: v?.split?.errorCode,
      };
      if (Date.now() - start > 150000) throw new Error('E_SPLIT_UI_TIMEOUT');
      await new Promise((r) => setTimeout(r, 30));
    }
    await pause();
  };
  const click = async (selector: string) => {
    control = selector;
    await clickCommittedControl(selector, host.current);
    await host.settled();
    await pause();
  };
  const wait = async () => {
    await until(() => !host.current()?.split?.busy);
    verify(!host.current()!.split!.errorCode, 'E_SPLIT_UI_PROCESSING');
  };
  const field = async (selector: string, value: string | number) => {
    control = selector;
    await pause();
    const input = document.querySelector<HTMLInputElement | HTMLSelectElement>(selector);
    verify(input, 'E_SPLIT_UI_FIELD');
    const proto =
      input instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value')!.set!.call(input, String(value));
    input!.dispatchEvent(
      new Event(input instanceof HTMLSelectElement ? 'change' : 'input', { bubbles: true }),
    );
    await pause();
  };
  await host.command({ type: 'new', sourceType: 'split-image', name: '분리 그림 검증' });
  await until(() => host.current()?.project?.sourceType === 'split-image');
  await click('[data-step="prepare"]');
  const before = JSON.stringify(host.current()!.project),
    projectId = host.current()!.project!.projectId;
  await click('[data-split-load="example"]');
  await wait();
  await until(() => !!document.querySelector('[data-split-select]'));
  const d = host.current()!.split!.draft!;
  verify(
    d.layers.length === 16 &&
      d.layers.some((l) => l.image.empty) &&
      d.layers.some((l) => !l.visible),
    'E_SPLIT_UI_PRESERVATION',
  );
  verify(new Set(d.layers.map((l) => l.name)).size < d.layers.length, 'E_SPLIT_UI_DUPLICATE_NAMES');
  const first = d.layers[0]!;
  await field('[data-split-parent]', first.id);
  verify(
    document.querySelector<HTMLButtonElement>('[data-split-prepare]')!.disabled,
    'E_SPLIT_UI_CYCLE_BLOCK',
  );
  await field('[data-split-parent]', first.parentId ?? '');
  const position = document.querySelector<HTMLInputElement>('[data-split-position="0"]')!.value;
  await click('[data-split-mirror]');
  verify(
    document.querySelector<HTMLInputElement>('[data-split-position="0"]')!.value === position,
    'E_SPLIT_UI_MIRROR_MODEL',
  );
  await click('[data-split-mirror]');
  await click('[data-split-zoom]');
  await click('[data-split-zoom]');
  const svg = document.querySelector<SVGSVGElement>('[data-split-canvas-svg]')!;
  verify(
    Number(svg.getAttribute('viewBox')!.split(' ')[2]) === d.canvas.width / 4,
    'E_SPLIT_UI_ZOOM',
  );
  const a = svg.createSVGPoint();
  a.x = first.origin[0];
  a.y = first.origin[1];
  const b = svg.createSVGPoint();
  b.x = a.x + 3;
  b.y = a.y + 2;
  const aa = a.matrixTransform(svg.getScreenCTM()!),
    bb = b.matrixTransform(svg.getScreenCTM()!);
  svg.dispatchEvent(
    new PointerEvent('pointerdown', { bubbles: true, pointerId: 1, clientX: aa.x, clientY: aa.y }),
  );
  svg.dispatchEvent(
    new PointerEvent('pointermove', { bubbles: true, pointerId: 1, clientX: bb.x, clientY: bb.y }),
  );
  svg.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerId: 1 }));
  await pause();
  verify(
    Number(document.querySelector<HTMLInputElement>('[data-split-position="0"]')!.value) ===
      first.origin[0] + 3,
    'E_SPLIT_UI_POINTER',
  );
  await field('[data-split-position="0"]', first.origin[0]);
  await field('[data-split-position="1"]', first.origin[1]);
  await click('[data-split-prepare]');
  await wait();
  verify(JSON.stringify(host.current()!.project) === before, 'E_SPLIT_UI_PREMATURE_APPLY');
  verify(document.querySelectorAll('[data-split-motion]').length === 2, 'E_SPLIT_UI_COMPARE');
  const pixels = await splitPixels(host.current()!.split!.scene!, host.current()!.split!.draft!);
  verify(pixels.passed, 'E_SPLIT_UI_PIXELS');
  await click('[data-split-play]');
  await click('[data-split-play]');
  await click('[data-split-apply]');
  verify(
    host.current()!.project!.projectId === projectId && host.current()!.project!.split,
    'E_SPLIT_UI_APPLY',
  );
  await click('[data-split-close]');
  await host.command({ type: 'undo' });
  verify(!host.current()!.project!.split, 'E_SPLIT_UI_UNDO');
  await host.command({ type: 'redo' });
  verify(host.current()!.project!.split, 'E_SPLIT_UI_REDO');
  const originalHashes = host.current()!.project!.split!.draft.layers.map((l) => l.sourceHash),
    ids = host.current()!.project!.parts.map((p) => p.id);
  await host.command({ type: 'save' });
  await host.command({ type: 'duplicate' });
  verify(host.current()!.project!.projectId !== projectId, 'E_SPLIT_UI_DUPLICATE');
  await host.command({ type: 'recent', id: host.current()!.recent[0]!.id });
  verify(
    JSON.stringify(host.current()!.project!.parts.map((p) => p.id)) === JSON.stringify(ids),
    'E_SPLIT_UI_REOPEN_IDS',
  );
  verify(
    JSON.stringify(host.current()!.project!.split!.draft.layers.map((l) => l.sourceHash)) ===
      JSON.stringify(originalHashes),
    'E_SPLIT_UI_REOPEN_HASH',
  );
  await click('[data-step="prepare"]');
  await click('[data-split-export]');
  verify(!host.current()!.errorCode && host.current()!.split!.exported, 'E_SPLIT_UI_EXPORT');
  await click('[data-step="motion"]');
  verify(
    document.querySelectorAll('[data-motion-key]:enabled').length === 5,
    'E_SPLIT_UI_COMMON_MOTION',
  );
  await click('[data-motion-all]');
  await click('[data-motion-stop]');
  await click('[data-step="prepare"]');
  await click('[data-split-edit]');
  await wait();
  await until(() => !!document.querySelector('[data-split-prepare]'));
  verify(
    JSON.stringify(host.current()!.split!.draft!.layers.map((l) => l.id)) === JSON.stringify(ids),
    'E_SPLIT_UI_REGUIDE_IDS',
  );
  await click('[data-split-close]');
  await host.command({ type: 'split-cancel' });
  await click('[data-split-load="folder"]');
  await wait();
  await until(() => !!document.querySelector('[data-split-select]'));
  const folder = host.current()!.split!.draft!,
    folderBefore = JSON.stringify(host.current()!.project);
  verify(
    folder.layers.every((l) => !l.roleConfirmed && !l.positionConfirmed) &&
      folder.omitted.length === 1,
    'E_SPLIT_UI_AMBIGUOUS',
  );
  await click('[data-split-layout="cropped"]');
  await click('[data-split-omitted]');
  const lookup = new Map(
    rows.map((row) => [row.sourceId, folder.layers.find((l) => l.sourceName === row.name)!.id]),
  );
  for (const row of rows) {
    await field('[data-split-select]', lookup.get(row.sourceId)!);
    for (const [selector, value] of [
      ['[data-split-position="0"]', row.origin[0]],
      ['[data-split-position="1"]', row.origin[1]],
      ['[data-split-role]', row.role],
      ['[data-split-side]', row.side],
      ['[data-split-order]', row.z],
      ['[data-split-usage]', row.usage],
    ] as const)
      await field(selector, value);
    if (row.usage === 'alternative') {
      await field('[data-split-variant]', lookup.get(row.variantOf!)!);
      await field('[data-split-state-kind]', row.state);
    }
    if (document.querySelector<HTMLInputElement>('[data-split-visible]')!.checked !== row.visible)
      await click('[data-split-visible]');
    await click('[data-split-confirm]');
  }
  await click('[data-split-prepare]');
  await wait();
  verify(JSON.stringify(host.current()!.project) === folderBefore, 'E_SPLIT_UI_FOLDER_ISOLATION');
  const folderPixels = await splitPixels(
    host.current()!.split!.scene!,
    host.current()!.split!.draft!,
  );
  verify(folderPixels.passed, 'E_SPLIT_UI_FOLDER_GPU');
  await click('[data-split-apply]');
  await click('[data-split-close]');
  const saved = JSON.stringify(host.current()!.project!.split);
  await host.command({ type: 'save' });
  await host.command({ type: 'recent', id: host.current()!.recent[0]!.id });
  verify(JSON.stringify(host.current()!.project!.split) === saved, 'E_SPLIT_UI_FOLDER_REOPEN');
  await click('[data-step="prepare"]');
  await click('[data-split-edit]');
  await wait();
  await until(() => !!document.querySelector('[data-split-prepare]'));
  await click('[data-split-prepare]');
  await wait();
  await click('[data-split-play]');
  await until(() => document.querySelectorAll('[data-split-ready="true"]').length === 2);
  await new Promise((r) => setTimeout(r, 400));
  document.querySelector('[data-split-motion="candidate"]')!.scrollIntoView({ block: 'center' });
  await pause();
  return {
    passed: true,
    manifest: true,
    ambiguousFolderRepair: true,
    emptyHiddenDuplicateNames: true,
    cycleBlocked: true,
    zoomPointer: true,
    mirrorViewOnly: true,
    reviewBeforeApply: true,
    compare: true,
    commonFiveControls: true,
    undoRedo: true,
    saveDuplicateReopen: true,
    reguide: true,
    sourceHashesPreserved: true,
    sourceBundleExport: true,
    pixels,
    folderPixels,
    devicesOpened: false,
  };
}
