import { clickCommittedControl } from './ui-check-control';
import type {
  SessionCommand,
  SessionReply,
  SessionView,
} from '../../../packages/project-session/contracts';
import type { Project, PreviewKey } from '../../../packages/project-model';
import { previewParameters } from '../../../packages/project-model/preview';
import { AvatarRenderer } from '../../../packages/avatar-renderer';
import type { PreviewScene } from '../../../packages/scene-core';
async function pixels(
  before: Project,
  original: PreviewScene,
  after: Project,
  candidate: PreviewScene,
) {
  const canvas = document.createElement('canvas');
  canvas.width = 384;
  canvas.height = 480;
  const sheet = document.createElement('canvas');
  sheet.width = 1152;
  sheet.height = 480;
  const ctx = sheet.getContext('2d')!,
    frames: Uint8Array[][] = [[], []];
  let clean = true,
    stable = true;
  const keys: PreviewKey[] = ['head_yaw', 'head_roll'];
  for (const [row, project, scene] of [
    [0, before, original],
    [1, after, candidate],
  ] as const) {
    const r = new AvatarRenderer(canvas, scene);
    await r.load(document.baseURI);
    const uploads = r.report().staticBufferUploads;
    let col = 0;
    for (const key of keys)
      for (const point of ['min', 'neutral', 'max'] as const) {
        const values = new Map(project.parameters.map((p) => [p.id, p.neutral])),
          p = project.parameters.find((p) => p.previewKey === key);
        if (p) values.set(p.id, point === 'min' ? p.min : point === 'max' ? p.max : p.neutral);
        r.draw(previewParameters(project, values));
        r.gl.finish();
        const bytes = new Uint8Array(384 * 480 * 4);
        r.gl.readPixels(0, 0, 384, 480, r.gl.RGBA, r.gl.UNSIGNED_BYTE, bytes);
        frames[row]!.push(bytes);
        ctx.drawImage(canvas, col * 192, row * 240, 192, 240);
        ctx.fillStyle = '#fff';
        ctx.font = '11px sans-serif';
        ctx.fillText(key + ' ' + point, col * 192 + 5, row * 240 + 15);
        col++;
      }
    const info = r.report();
    clean &&= info.glError === 0;
    stable &&= info.staticBufferUploads === uploads;
    r.dispose();
  }
  let neutralTotal = 0,
    extremeChanged = 0;
  for (let frame = 0; frame < 6; frame++)
    for (let i = 0; i < frames[0]![frame]!.length; i++) {
      const delta = Math.abs(frames[0]![frame]![i]! - frames[1]![frame]![i]!);
      if (frame === 1 || frame === 4) neutralTotal += delta;
      else if (delta > 1) extremeChanged++;
    }
  const mean = neutralTotal / (384 * 480 * 4 * 2);
  return {
    passed: clean && stable && mean < 0.02 && extremeChanged > 0,
    frames: 12,
    neutralMeanDifference: mean,
    extremeChangedChannels: extremeChanged,
    glClean: clean,
    buffersStable: stable,
    png: sheet.toDataURL('image/png'),
  };
}
export async function checkDetailUI(host: {
  current: () => SessionView | null;
  command: (c: SessionCommand) => Promise<SessionReply>;
  settled: () => Promise<unknown>;
}) {
  let control = 'initial';
  const pause = () =>
    new Promise<void>((r) => requestAnimationFrame(() => requestAnimationFrame(() => r())));
  const verify = (v: unknown, code: string) => {
    if (!v) throw new Error(code);
  };
  const until = async (fn: () => boolean) => {
    const end = Date.now() + 300000;
    while (!fn()) {
      const v = host.current();
      window.editorFailureState = {
        detailControl: control,
        sequence: v?.sequence,
        errorCode: v?.errorCode,
        detailError: v?.detail?.errorCode,
        busy: v?.detail?.busy,
        selected: document.querySelector<HTMLSelectElement>('[data-detail-select]')?.value,
      };
      if (Date.now() > end) throw new Error('E_DETAIL_UI_TIMEOUT');
      await new Promise((r) => setTimeout(r, 25));
    }
    await pause();
  };
  const click = async (selector: string) => {
    control = selector;
    await clickCommittedControl(selector, host.current);
    await host.settled();
    await pause();
  };
  const field = async (selector: string, value: string | number) => {
    control = selector;
    await pause();
    const el = document.querySelector<HTMLInputElement | HTMLSelectElement>(selector);
    verify(el, 'E_DETAIL_UI_FIELD');
    Object.getOwnPropertyDescriptor(
      el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype,
      'value',
    )!.set!.call(el, String(value));
    el!.dispatchEvent(
      new Event(el instanceof HTMLSelectElement ? 'change' : 'input', { bubbles: true }),
    );
    await pause();
  };
  const current = () => host.current()!.project!,
    wait = async () => {
      await until(() => !host.current()!.detail?.busy);
      verify(!host.current()!.detail?.errorCode, 'E_DETAIL_UI_PROCESSING');
    };
  const apply = async () => {
    verify(host.current()!.detail!.canApply, 'E_DETAIL_UI_REVIEW');
    await click('[data-detail-apply]');
    await wait();
    verify(!host.current()!.errorCode, 'E_DETAIL_UI_APPLY');
  };
  const report: Record<string, unknown>[] = [];
  const contact = document.createElement('canvas');
  contact.width = 1152;
  contact.height = 1440;
  const ctx = contact.getContext('2d')!;
  for (const [routeIndex, route] of (['parts', 'single-image', 'split-image'] as const).entries()) {
    await host.command({ type: 'new', name: '세부 편집 검증 · ' + route, sourceType: route });
    await pause();
    await click('[data-step="prepare"]');
    if (route === 'parts') {
      await host.command({ type: 'parts-start', expectedRevision: current().revision });
    } else if (route === 'single-image') {
      await host.command({ type: 'import-image' });
      await until(() => !host.current()!.input!.busy);
      const draft = host.current()!.input!.draft!;
      await host.command({
        type: 'input-apply',
        draftId: draft.id,
        selection: {
          rect: { x: 0, y: 0, ...draft.probe.size },
          masks: [],
          occluded: false,
          backgroundTolerance: null,
        },
      });
      await until(() => !host.current()!.input!.busy);
      await host.command({
        type: 'structure-start',
        expectedRevision: current().revision,
        completion: 'estimated',
      });
      await until(() => !host.current()!.structure!.busy);
      verify(host.current()!.structure!.canApply, 'E_DETAIL_UI_SINGLE_PREPARATION');
      await host.command({ type: 'structure-apply', expectedRevision: current().revision });
    } else {
      await click('[data-split-load="example"]');
      await until(
        () => !host.current()!.split!.busy && !!document.querySelector('[data-split-prepare]'),
      );
      await click('[data-split-prepare]');
      await until(() => !host.current()!.split!.busy);
      await click('[data-split-apply]');
      await click('[data-split-close]');
    }
    verify(!host.current()!.errorCode, 'E_DETAIL_UI_ROUTE');
    await click('[data-step="appearance"]');
    const source = structuredClone(current()),
      id = source.parts.find((v) => v.role === 'head' || v.role === 'base')!.id,
      projectId = source.projectId,
      hashes = source.inputAssetIds.map(
        (id) => source.assets.find((a) => a.id === id)!.fingerprint.sha256,
      );
    await click(`[data-part-id="${id}"]`);
    await click('[data-detail-open]');
    await until(() => !!document.querySelector('[data-detail-editor]'));
    verify(document.getElementById('root')!.inert, 'E_DETAIL_UI_MODAL');
    verify(
      document.querySelector<HTMLSelectElement>('[data-detail-select]')!.value === id &&
        current().projectId === projectId,
      'E_DETAIL_UI_SELECTION',
    );
    const before = JSON.stringify(current());
    await field('[data-detail-relation="parentId"]', id);
    await click('[data-detail-part-preview]');
    verify(
      host.current()!.errorCode === 'E_REFERENCE_CYCLE' && JSON.stringify(current()) === before,
      'E_DETAIL_UI_CYCLE',
    );
    await field(
      '[data-detail-relation="parentId"]',
      source.parts.find((v) => v.id === id)!.parentId ?? '',
    );
    await field('[data-detail-name]', '상세 조정 · ' + route);
    await field(
      '[data-detail-field="order"]',
      source.parts.find((v) => v.id === id)!.drawOrder + 1,
    );
    await click('[data-detail-part-preview]');
    verify(
      JSON.stringify(current()) === before &&
        host.current()!.detail!.impact &&
        !host.current()!.detail!.impact!.presentationOnly,
      'E_DETAIL_UI_ISOLATION',
    );
    await apply();
    const originalMesh = structuredClone(current().motion!.meshes.find((m) => m.partId === id)!),
      others = JSON.stringify(current().motion!.meshes.filter((m) => m.partId !== id));
    await field('[data-detail-field="pivot-0"]', originalMesh.pivot[0] + 3);
    await click('[data-detail-mesh-preview]');
    const candidate = host.current()!.detail!.project!;
    verify(
      JSON.stringify(candidate.motion!.meshes.filter((m) => m.partId !== id)) === others,
      'E_DETAIL_UI_OTHER_MESH',
    );
    const gpu = await pixels(
      current(),
      host.current()!.scene!,
      candidate,
      host.current()!.detail!.scene!,
    );
    const { png, ...result } = gpu;
    verify(gpu.passed, 'E_DETAIL_UI_GPU');
    const image = new Image();
    image.src = png;
    await image.decode();
    ctx.drawImage(image, 0, routeIndex * 480);
    for (const point of ['min', 'neutral', 'max']) {
      await click(`[data-detail-point="${point}"]`);
      await until(() => document.querySelectorAll('[data-detail-ready="true"]').length === 2);
    }
    await apply();
    await click('[data-detail-map-zoom]');
    const svg = document.querySelector<SVGSVGElement>('[data-detail-map]')!,
      dot = document.querySelector<SVGCircleElement>('[data-detail-vertex-dot="0"]')!;
    const q = svg.createSVGPoint();
    q.x = Number(dot.getAttribute('cx'));
    q.y = Number(dot.getAttribute('cy'));
    const a = q.matrixTransform(svg.getScreenCTM()!);
    dot.dispatchEvent(
      new PointerEvent('pointerdown', { bubbles: true, pointerId: 1, clientX: a.x, clientY: a.y }),
    );
    await pause();
    q.x += 1;
    const b = q.matrixTransform(svg.getScreenCTM()!);
    svg.dispatchEvent(
      new PointerEvent('pointermove', { bubbles: true, pointerId: 1, clientX: b.x, clientY: b.y }),
    );
    svg.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerId: 1 }));
    await pause();
    verify(
      Math.abs(
        Number(
          document.querySelector<HTMLInputElement>('[data-detail-field="position-0"]')!.value,
        ) -
          originalMesh.vertices[0]!.position[0] -
          1,
      ) < 0.011,
      'E_DETAIL_UI_DRAG',
    );
    await click('[data-detail-vertex-preview]');
    await apply();
    await field('[data-detail-restore-scope]', 'mesh');
    await click('[data-detail-restore]');
    await apply();
    verify(
      JSON.stringify(current().motion!.meshes.find((m) => m.partId === id)) ===
        JSON.stringify(originalMesh),
      'E_DETAIL_UI_RESTORE_MESH',
    );
    await field('[data-detail-binding-select]', '');
    await field(
      '[data-detail-binding-parameter]',
      current().parameters.find((v) => v.previewKey === 'head_roll')!.id,
    );
    await field('[data-detail-component]', 'translate-y');
    await field('[data-detail-field="output-0"]', -1);
    await field('[data-detail-field="output-1"]', 1);
    await click('[data-detail-binding-preview]');
    await apply();
    const binding = current().partBindings.find(
      (b) => b.partId === id && b.kind === 'transform' && b.mapping.component === 'translate-y',
    )!;
    await field('[data-detail-binding-select]', binding.id);
    await field('[data-detail-field="output-1"]', 2);
    await click('[data-detail-binding-preview]');
    await apply();
    await field('[data-detail-binding-select]', binding.id);
    await click('[data-detail-unbind]');
    await apply();
    verify(!current().partBindings.some((b) => b.id === binding.id), 'E_DETAIL_UI_UNBIND');
    const unchanged = JSON.stringify(current());
    await click('[data-detail-import]');
    await wait();
    verify(
      host.current()!.detail!.project!.assets.length === current().assets.length + 2 &&
        JSON.stringify(current()) === unchanged,
      'E_DETAIL_UI_IMPORT',
    );
    await click('[data-detail-discard]');
    verify(JSON.stringify(current()) === unchanged, 'E_DETAIL_UI_DISCARD');
    await click('[data-detail-close]');
    await host.command({ type: 'sample' });
    await until(() => !!document.querySelector('[data-detail-protection]'));
    verify(
      host.current()!.errorCode === 'E_DETAIL_PROTECTED' && JSON.stringify(current()) === unchanged,
      'E_DETAIL_UI_PROTECTION',
    );
    await host.command({
      type: 'detail-open',
      location: { kind: 'part', id: 'obsolete-reference' },
    });
    await pause();
    verify(
      host.current()!.detail!.errorCode === 'E_DETAIL_LOCATION',
      'E_DETAIL_UI_MISSING_LOCATION',
    );
    await host.command({ type: 'detail-open', location: { kind: 'vertex', id, index: 0 } });
    await pause();
    verify(
      host.current()!.detail!.partId === id &&
        document.querySelector<HTMLSelectElement>('[data-detail-select]')!.value === id,
      'E_DETAIL_UI_FIX_LOCATION',
    );
    const victim = current().parts.find((v) => v.role === 'mouth')!,
      victimId = victim.id;
    await field('[data-detail-select]', victimId);
    await click('[data-detail-delete]');
    verify(
      host.current()!.detail!.impact!.kind === 'delete' && JSON.stringify(current()) === unchanged,
      'E_DETAIL_UI_DELETE_REPORT',
    );
    await apply();
    verify(!current().parts.some((v) => v.id === victimId), 'E_DETAIL_UI_DELETE');
    await host.command({ type: 'undo' });
    await pause();
    verify(
      current().parts.some((v) => v.id === victimId),
      'E_DETAIL_UI_UNDO',
    );
    await host.command({ type: 'redo' });
    await pause();
    verify(!current().parts.some((v) => v.id === victimId), 'E_DETAIL_UI_REDO');
    await host.command({ type: 'undo' });
    await pause();
    await field('[data-detail-select]', id);
    await field('[data-detail-restore-scope]', 'all');
    await click('[data-detail-restore]');
    await apply();
    verify(!current().detail, 'E_DETAIL_UI_RESTORE_ALL');
    if (route === 'single-image') {
      for (const item of source.parts) {
        await field('[data-detail-select]', item.id);
        await click('[data-detail-delete]');
        await apply();
      }
      verify(!current().parts.length, 'E_DETAIL_UI_EMPTY');
      verify(
        !document.querySelector('[data-detail-frame="현재 적용 결과"]') &&
          document.querySelector('[data-detail-empty-frame]'),
        'E_DETAIL_UI_EMPTY_PREVIEW',
      );
      for (const item of source.parts) {
        await click('[data-detail-restore-deleted="' + item.id + '"]');
        await apply();
      }
      verify(
        current().parts.length === source.parts.length && !current().detail,
        'E_DETAIL_UI_EMPTY_RESTORE',
      );
      await field('[data-detail-select]', id);
    }
    await field('[data-detail-field="pivot-0"]', originalMesh.pivot[0] + 3);
    await click('[data-detail-mesh-preview]');
    await apply();
    await click('[data-detail-close]');
    verify(
      document.querySelector('[data-viewport]')?.getAttribute('data-selected') === id,
      'E_DETAIL_UI_RETURN_SELECTION',
    );
    const saved = JSON.stringify(current().detail),
      motion = JSON.stringify(current().motion);
    await host.command({ type: 'save' });
    verify(!host.current()!.dirty, 'E_DETAIL_UI_SAVE');
    await host.command({ type: 'duplicate' });
    verify(current().projectId !== projectId, 'E_DETAIL_UI_DUPLICATE');
    await host.command({ type: 'recent', id: host.current()!.recent[0]!.id });
    verify(
      JSON.stringify(current().detail) === saved && JSON.stringify(current().motion) === motion,
      'E_DETAIL_UI_REOPEN',
    );
    verify(
      JSON.stringify(
        current().inputAssetIds.map(
          (id) => current().assets.find((a) => a.id === id)!.fingerprint.sha256,
        ),
      ) === JSON.stringify(hashes),
      'E_DETAIL_UI_SOURCE_HASH',
    );
    await click(`[data-part-id="${id}"]`);
    await click('[data-detail-open]');
    await until(() => !!document.querySelector('[data-detail-editor]'));
    await field('[data-detail-field="pivot-0"]', originalMesh.pivot[0] + 5);
    await click('[data-detail-mesh-preview]');
    await until(() => document.querySelectorAll('[data-detail-ready="true"]').length === 2);
    await click('[data-detail-point="max"]');
    await pause();
    report.push({
      route,
      passed: true,
      actualRoutePreparation: true,
      sameProjectSelection: true,
      cycleBlocked: true,
      previewBeforeApply: true,
      localMeshDrag: true,
      pivotAndVertex: true,
      otherMeshesPreserved: true,
      bindingsAddEditRemove: true,
      realPngReplacementPreview: true,
      deleteImpactAndUndoRedo: true,
      selectiveRestore: true,
      emptyRestoration: route === 'single-image' ? true : 'NOT_APPLICABLE',
      simpleConflictProtected: true,
      idFixLocations: true,
      saveDuplicateReopen: true,
      originalHashesPreserved: true,
      pixels: result,
    });
    if (routeIndex < 2) {
      await click('[data-detail-discard]');
      await click('[data-detail-close]');
    }
  }
  window.detailExtremeData = contact.toDataURL('image/png');
  document.querySelector('[data-detail-map]')!.scrollIntoView({ block: 'center' });
  await new Promise((r) => setTimeout(r, 400));
  return {
    passed: true,
    routes: report,
    logicalLocations: true,
    invalidReferencesHandled: true,
    devicesOpened: false,
    m2FoundationChecked: true,
    m2ExitApproved: false,
    followup: ['T-171~180', 'T-268', 'T-271'],
    scope:
      'Actual detailed UI on three real creation routes, common GPU, semantic preservation and file roundtrips; not independent ART, live devices, broadcast/external compatibility or M0 approval',
  };
}
