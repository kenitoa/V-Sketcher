import { clickCommittedControl } from './ui-check-control';
import { layerCorners } from '../../../packages/editor-view';
import type {
  SessionCommand,
  SessionReply,
  SessionView,
} from '../../../packages/project-session/contracts';
import { AvatarRenderer } from '../../../packages/avatar-renderer';
import { NEUTRAL, type PreviewScene, type Parameters } from '../../../packages/scene-core';
export async function structurePixels(scene: PreviewScene, original: PreviewScene) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 512;
  const a = new AvatarRenderer(canvas, original);
  await a.load(document.baseURI);
  a.draw();
  const read = (r: AvatarRenderer) => {
    r.gl.finish();
    const p = new Uint8Array(512 * 512 * 4);
    r.gl.readPixels(0, 0, 512, 512, r.gl.RGBA, r.gl.UNSIGNED_BYTE, p);
    return p;
  };
  const source = read(a);
  a.dispose();
  const r = new AvatarRenderer(canvas, scene);
  await r.load(document.baseURI);
  r.draw();
  const neutral = read(r);
  let total = 0,
    maximum = 0,
    alpha = 0;
  for (let i = 0; i < source.length; i++) {
    const d = Math.abs(source[i]! - neutral[i]!);
    total += d;
    maximum = Math.max(maximum, d);
    if (i % 4 === 3) alpha += d;
  }
  const uploads = r.report().staticBufferUploads;
  let midpointAlphaDrop = 0;
  for (const key of ['eye_left', 'eye_right', 'mouth'] as const) {
    r.draw({ ...NEUTRAL, [key]: 0.5 });
    const middle = read(r);
    const corners = layerCorners(scene.layers.find((l) => l.bind === key)!);
    const x0 = Math.ceil((Math.min(...corners.map((v) => v.x)) * 512) / scene.canvas[0]) + 2,
      x1 = Math.floor((Math.max(...corners.map((v) => v.x)) * 512) / scene.canvas[0]) - 2,
      y0 = Math.ceil((Math.min(...corners.map((v) => v.y)) * 512) / scene.canvas[1]) + 2,
      y1 = Math.floor((Math.max(...corners.map((v) => v.y)) * 512) / scene.canvas[1]) - 2;
    for (let y = y0; y < y1; y++)
      for (let x = x0; x < x1; x++) {
        const at = ((511 - y) * 512 + x) * 4 + 3;
        midpointAlphaDrop = Math.max(midpointAlphaDrop, neutral[at]! - middle[at]!);
      }
  }
  const inputs: Parameters[] = [{ ...NEUTRAL }];
  for (const key of Object.keys(NEUTRAL) as (keyof Parameters)[])
    for (const value of [key.startsWith('head') ? -1 : 0, 1])
      inputs.push({ ...NEUTRAL, [key]: value });
  for (const head_yaw of [-1, 0, 1])
    for (const head_roll of [-1, 0, 1]) inputs.push({ ...NEUTRAL, head_yaw, head_roll });
  inputs.push(
    { ...NEUTRAL, eye_left: 0, eye_right: 0 },
    { ...NEUTRAL, mouth: 0.65, head_yaw: 1, head_roll: 1 },
  );
  for (const key of ['eye_left', 'eye_right', 'mouth'] as const)
    inputs.push({ ...NEUTRAL, [key]: 0.5 });
  const sheet = document.createElement('canvas');
  sheet.width = 1536;
  sheet.height = 2304;
  const ctx = sheet.getContext('2d')!;
  ctx.fillStyle = '#302737';
  ctx.fillRect(0, 0, sheet.width, sheet.height);
  const hashes = new Set<string>();
  let frame = 0;
  for (const input of inputs) {
    r.draw(input);
    r.gl.finish();
    hashes.add(String(r.report().pixelHash));
    ctx.drawImage(canvas, (frame % 3) * 512, Math.floor(frame / 3) * 256, 256, 256);
    ctx.fillStyle = '#f5e8fb';
    ctx.font = '12px sans-serif';
    Object.entries(input).forEach(([key, value], line) =>
      ctx.fillText(
        key + ': ' + value,
        (frame % 3) * 512 + 270,
        Math.floor(frame / 3) * 256 + 60 + line * 22,
      ),
    );
    frame++;
  }
  const info = r.report();
  r.dispose();
  window.structureExtremeData = sheet.toDataURL('image/png');
  const mean = total / source.length,
    alphaMean = alpha / (512 * 512);
  return {
    passed:
      midpointAlphaDrop <= 1 &&
      mean < 1 &&
      alphaMean < 1 &&
      hashes.size >= 10 &&
      info.glError === 0 &&
      info.staticBufferUploads === uploads,
    midpointAlphaDrop,
    frames: frame,
    uniqueFrames: hashes.size,
    neutralMeanDifference: mean,
    neutralMaximumDifference: maximum,
    neutralAlphaMeanDifference: alphaMean,
    buffersStable: info.staticBufferUploads === uploads,
    glClean: info.glError === 0,
    scope:
      'Real common GPU from automatically prepared premium original; neutral sampling tolerance <1/255 mean, pixel-exact CPU reconstruction verified separately',
  };
}
export async function checkStructureUI(host: {
  current: () => SessionView | null;
  command: (c: SessionCommand) => Promise<SessionReply>;
  settled: () => Promise<unknown>;
}) {
  let lastControl = '';
  const record = () => {
    const v = host.current(),
      c = v?.structure;
    window.editorFailureState = {
      ...window.editorFailureState,
      structureControl: lastControl,
      sequence: v?.sequence,
      errorCode: v?.errorCode,
      structure: c
        ? { state: c.state, busy: c.busy, errorCode: c.errorCode, jobId: c.jobId }
        : null,
    };
  };
  const pause = () => new Promise((r) => setTimeout(r, 30));
  const until = async (fn: () => boolean) => {
    const t = Date.now();
    while ((record(), !fn())) {
      if (Date.now() - t > 300000) throw new Error('E_STRUCTURE_UI_TIMEOUT');
      await pause();
    }
  };
  const verify = (v: unknown, code: string) => {
    if (!v) throw new Error(code);
  };
  const prepared = () => {
    const state = host.current()!.structure!;
    if (state.state === 'failed') throw new Error('E_STRUCTURE_UI_PREPARE');
    return !state.busy && state.state === 'review';
  };
  const click = async (selector: string) => {
    lastControl = selector;
    record();
    const priorJob = host.current()?.structure?.jobId;
    await clickCommittedControl(selector, host.current);
    await pause();
    await host.settled();
    await new Promise<void>((resolve) =>
      requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
    );
    await pause();
    if (selector === '[data-structure-start]' || selector === '[data-structure-restrict]')
      await until(() => host.current()?.structure?.jobId !== priorJob);
  };
  await host.command({ type: 'new', sourceType: 'single-image', name: '자동 구조화 검증' });
  await host.command({ type: 'import-image' });
  await until(() => !host.current()!.input!.busy);
  const d = host.current()!.input!.draft!;
  await host.command({
    type: 'input-apply',
    draftId: d.id,
    selection: {
      rect: { x: 0, y: 0, ...d.probe.size },
      backgroundTolerance: null,
      masks: [],
      occluded: false,
    },
  });
  await until(() => !!host.current()!.project?.inputPreparation && !host.current()!.input!.busy);
  await until(() => !!document.querySelector('[data-structure-start]'));
  const before = JSON.stringify(host.current()!.project);
  let early = false;
  await click('[data-structure-start]');
  await until(() => {
    early ||= !!host.current()!.structure!.earlyReady;
    return prepared();
  });
  verify(early, 'E_STRUCTURE_UI_EARLY');
  verify(host.current()!.structure!.canApply, 'E_STRUCTURE_UI_REVIEW');
  verify(JSON.stringify(host.current()!.project) === before, 'E_STRUCTURE_UI_PREMATURE_APPLY');
  verify(
    document.querySelector('[aria-label="자동 구조화 움직임 미리보기"]'),
    'E_STRUCTURE_UI_PREVIEW',
  );
  const pixels = await structurePixels(host.current()!.structure!.scene!, host.current()!.scene!);
  verify(pixels.passed, 'E_STRUCTURE_UI_GPU');
  await click('[data-structure-play]');
  await click('[data-structure-play]');
  await click('[data-structure-apply]');
  verify(host.current()!.project!.parts.length === 4, 'E_STRUCTURE_UI_APPLY');
  const report = JSON.stringify(host.current()!.project!.structure!.report);
  await host.command({ type: 'undo' });
  verify(!host.current()!.project!.structure, 'E_STRUCTURE_UI_UNDO');
  await host.command({ type: 'redo' });
  verify(
    JSON.stringify(host.current()!.project!.structure!.report) === report,
    'E_STRUCTURE_UI_REDO',
  );
  await host.command({ type: 'save' });
  const originalId = host.current()!.project!.projectId;
  await host.command({ type: 'duplicate' });
  verify(host.current()!.project!.projectId !== originalId, 'E_STRUCTURE_UI_DUPLICATE');
  const id = host.current()!.recent[0]!.id;
  await host.command({ type: 'recent', id });
  verify(
    JSON.stringify(host.current()!.project!.structure!.report) === report,
    'E_STRUCTURE_UI_REOPEN',
  );
  await click('[data-step="prepare"]');
  await click('[data-structure-start]');
  await until(() => prepared());
  const saved = JSON.stringify(host.current()!.project);
  await click('[data-structure-discard]');
  verify(JSON.stringify(host.current()!.project) === saved, 'E_STRUCTURE_UI_DISCARD');
  await click('[data-structure-restrict]');
  await until(() => prepared());
  verify(host.current()!.structure!.project!.parts.length === 1, 'E_STRUCTURE_UI_ALTERNATIVE');
  await click('[data-structure-discard]');
  await click('[data-structure-start]');
  await until(() => prepared());
  return {
    passed: true,
    realLandmarks: true,
    earlyPreview: early,
    reviewBeforeApply: true,
    estimatedSourceDisclosure: true,
    restrictedAlternative: true,
    discardPreservesNormal: true,
    apply: true,
    undoRedo: true,
    duplicate: true,
    saveReopen: true,
    devicesOpened: false,
    pixels,
  };
}
