"""Reduce cold replay objects losslessly. Never modifies live models or archive indexes."""
import importlib.util
import json
import lzma
import os
from pathlib import Path
import tempfile
import time
import zlib

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('compact_archive', ROOT / 'scripts/cache-archive.py')
archive = importlib.util.module_from_spec(spec)
spec.loader.exec_module(archive)
FILTERS = [{'id': lzma.FILTER_LZMA2, 'dict_size': 1024**2, 'preset': 4}]


def candidates(data, existing_size):
    # Probe a bounded sample; avoid running a full compressor on high-entropy PNG/ZIP data.
    sample = data[:65536]
    for shuffled in (False, True):
        probe = archive.shuffle4(sample) if shuffled else sample
        for codec in ('z', 'xz'):
            encode = (lambda value: zlib.compress(value, 6)) if codec == 'z' else (lambda value: lzma.compress(value, filters=FILTERS))
            if len(encode(probe)) / len(probe) >= existing_size / len(data) * 0.94:
                continue
            payload = encode(archive.shuffle4(data) if shuffled else data)
            if len(payload) < existing_size * 0.95:
                yield ('s4' if shuffled else '') + codec, payload


def main():
    if any('cache-archive-batch.py' in command or 'scripts/cache-policy.py' in command.replace('\\', '/') for command in archive.running_commands()):
        raise ValueError('E_CACHE_COMPACT_ACTIVE')
    folder = archive.STORE / 'objects'
    objects = archive.Objects(folder)
    before = after = changed = checked = 0
    started = time.monotonic()
    listing = tempfile.TemporaryFile(mode='w+t', encoding='utf-8')
    for file in folder.iterdir():
        if file.suffix in {'.raw', '.z', '.xz', '.s4z', '.s4xz'}:
            listing.write(file.name + '\n')
    listing.seek(0)
    for name in listing:
        file = folder / name.rstrip('\n')
        if file.suffix not in {'.raw', '.z', '.xz', '.s4z', '.s4xz'}:
            continue
        size = file.stat().st_size
        before += size
        after += size
        if size < 16384:
            continue
        checked += 1
        data = objects.get(file.stem)
        best_codec, best_payload = None, None
        for codec, payload in candidates(data, size):
            if best_payload is None or len(payload) < len(best_payload):
                best_codec, best_payload = codec, payload
        if best_payload is None:
            continue
        if archive.digest(archive.decode_object(best_payload, best_codec)) != file.stem:
            raise ValueError('E_CACHE_COMPACT_HASH')
        destination = file.with_suffix('.' + best_codec)
        if destination == file or destination.exists():
            continue
        staging = None
        try:
            # Same-directory staging is required for the atomic replace; removed on failure.
            with tempfile.NamedTemporaryFile(prefix='.compact-', dir=folder, delete=False) as stream:
                staging = Path(stream.name)
                stream.write(best_payload)
                stream.flush()
                os.fsync(stream.fileno())
            if archive.digest(archive.decode_object(staging.read_bytes(), best_codec)) != file.stem:
                raise ValueError('E_CACHE_COMPACT_HASH')
            staging.replace(destination)
            file.unlink()
            after -= size - len(best_payload)
            changed += 1
        finally:
            if staging is not None:
                staging.unlink(missing_ok=True)
        if changed % 100 == 0:
            print(json.dumps({'objectsCompacted': changed, 'savedMiB': round((before-after)/1024**2, 2)}), flush=True)
    listing.close()
    report = {'beforeBytes': before, 'afterBytes': after, 'objectsChecked': checked, 'objectsCompacted': changed,
              'allChangedObjectsDecodedAndHashMatched': True, 'liveModelsModified': False,
              'archiveIndexesModified': False, 'lzmaDictionaryMiB': 1, 'decoderMemoryLimitMiB': 32,
              'readCacheMiBLimit': 32, 'seconds': round(time.monotonic()-started, 2)}
    output = ROOT / ('evidence/cleanup/run-01/store-compaction-' + str(time.time_ns()) + '.json')
    output.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        code = str(error)
        print(code if code.startswith('E_CACHE_') and code.replace('_', '').isalnum() else 'E_CACHE_COMPACT')
        raise SystemExit(1)
