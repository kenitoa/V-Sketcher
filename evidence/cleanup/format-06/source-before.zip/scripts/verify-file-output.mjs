import { spawnSync } from 'node:child_process';
import {
  mkdirSync,
  writeFileSync,
  appendFileSync,
  readFileSync,
  readdirSync,
  copyFileSync,
  existsSync,
} from 'node:fs';
import { resolve, join, relative, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { root } from './common.mjs';
const output = resolve(root, 'evidence/phase24');
const log = resolve(root, '.local/phase24-check.log');
mkdirSync(output, { recursive: true });
writeFileSync(log, '');
const env = { ...process.env, PATH: dirname(process.execPath) + ';' + process.env.PATH };
delete env.ELECTRON_RUN_AS_NODE;
const sources = {};
const fileFolder = resolve(root, '.local/smoke/file-output-' + Date.now());
const broadcastFolder = resolve(root, '.local/smoke/broadcast-' + Date.now());
function inventory(folder) {
  for (const item of readdirSync(folder, { withFileTypes: true })) {
    const path = join(folder, item.name);
    if (item.name === '__pycache__' || item.name.endsWith('.pyc')) continue;
    if (item.isDirectory()) inventory(path);
    else
      sources[relative(root, path).replaceAll('\\', '/')] = createHash('sha256')
        .update(readFileSync(path))
        .digest('hex');
  }
}
for (const folder of [
  'packages/image-export',
  'packages/export-check',
  'packages/broadcast',
  'packages/execution',
  'packages/input-control',
  'packages/tracking',
  'packages/expression-control',
  'packages/detail-editor',
  'packages/split-image',
  'assets/product/split',
  'packages/single-image',
  'assets/product/parts',
  'packages/parts-library',
  'packages/image-input',
  'worker',
  'packages/motion',
  'packages/scene-core',
  'packages/project-model',
  'packages/editor-view',
  'packages/project-storage',
  'packages/project-session',
  'packages/workflow',
  'packages/avatar-renderer',
  'apps/renderer/src',
  'apps/desktop',
])
  inventory(resolve(root, folder));
for (const file of [
  'scripts/file-output-package-check.mjs',
  'scripts/file-output-audit.py',
  'scripts/file-output-pixels.py',
  'scripts/file-output-ui-check.mjs',
  'tests/file-output.test.ts',
  'vite.config.mjs',
  'apps/renderer/image-export.html',
  'apps/renderer/index.html',
  'apps/renderer/output.html',
  'scripts/broadcast-package-check.mjs',
  'scripts/broadcast-audit.py',
  'scripts/broadcast-ui-check.mjs',
  'scripts/broadcast-pixels.py',
  'tests/broadcast.test.ts',
  'tools/obs-client.mjs',
  'tools/obs-broadcast-check.mjs',
  'scripts/runtime-changes-package-check.mjs',
  'scripts/runtime-changes-audit.py',
  'tests/runtime-changes.test.ts',
  'scripts/execution-package-check.mjs',
  'scripts/execution-audit.py',
  'tests/execution.test.ts',
  'scripts/input-recovery-package-check.mjs',
  'scripts/input-recovery-audit.py',
  'tests/input-control.test.ts',
  'tools/camera-diagnostic.py',
  'scripts/tracking-package-check.mjs',
  'scripts/tracking-audit.py',
  'tests/tracking.test.ts',
  'tests/worker/test_tracking.py',
  'scripts/expression-package-check.mjs',
  'scripts/expression-audit.py',
  'tests/expression-control.test.ts',
  'scripts/detail-preservation-check.mjs',
  'scripts/detail-audit.py',
  'scripts/detail-package-check.mjs',
  'tests/detail-editor.test.ts',
  'scripts/split-package-check.mjs',
  'scripts/prepare-split-example.py',
  'tests/split-image.test.ts',
  'tests/worker/test_split_image.py',
  'scripts/correction-quality.py',
  'tests/corrections.test.ts',
  'tests/worker/test_corrections.py',
  'scripts/generate-project-validators.mjs',
  'scripts/build.mjs',
  'tests/single-image.test.ts',
  'tests/worker/test_structure.py',
  'scripts/structure-quality.py',
  'tests/storage.test.ts',
  'tests/editor.test.ts',
  'tests/motion.test.ts',
  'tests/image-input.test.ts',
  'tests/parts-library.test.ts',
  'tests/worker/test_parts_assets.py',
  'scripts/prepare-parts-catalog.py',
  'scripts/provision.py',
  'scripts/notices.py',
  'tests/worker/test_image_input.py',
  'scripts/prepare-motion-example.mjs',
  'assets/product/preview-project.json',
  'scripts/check.mjs',
  'scripts/test.mjs',
  'scripts/smoke.mjs',
  'scripts/package-check.mjs',
  'package.json',
  'package-lock.json',
])
  sources[file] = createHash('sha256')
    .update(readFileSync(resolve(root, file)))
    .digest('hex');
sources['scripts/verify-file-output.mjs'] = createHash('sha256')
  .update(readFileSync(resolve(root, 'scripts/verify-file-output.mjs')))
  .digest('hex');
let combined = '';
for (const script of [
  'scripts/check.mjs',
  'scripts/smoke.mjs',
  'scripts/broadcast-ui-check.mjs',
  'scripts/file-output-ui-check.mjs',
]) {
  const pending = process.argv.find((v) => v.startsWith('--wait-live-report='))?.slice(19);
  if (script === 'scripts/smoke.mjs' && pending) {
    const end = Date.now() + 900000;
    while (!existsSync(resolve(root, pending))) {
      if (Date.now() > end) throw new Error('E_LIVE_REVIEW_STILL_ACTIVE');
      await new Promise((r) => setTimeout(r, 250));
    }
  }
  const required = script === 'scripts/check.mjs';
  const result = spawnSync(
    required ? (process.env.ComSpec ?? 'cmd.exe') : process.execPath,
    required
      ? ['/d', '/c', 'tools\\dev.cmd', 'run', 'check']
      : [
          script,
          ...(script === 'scripts/broadcast-ui-check.mjs'
            ? ['--output-dir=' + broadcastFolder]
            : script === 'scripts/file-output-ui-check.mjs'
              ? ['--output-dir=' + fileFolder]
              : []),
        ],
    { cwd: root, env, windowsHide: true, encoding: 'utf8', timeout: 1860000 },
  );
  const chunk = (result.stdout ?? '') + (result.stderr ?? '');
  appendFileSync(log, chunk);
  combined += chunk;
  if (result.error || result.status !== 0)
    throw new Error('E_PROJECT_GATE: inspect .local/phase24-check.log');
}
const node = Number(combined.match(/\btests (\d+)/)?.[1]);
const python = Number(combined.match(/Ran (\d+) tests/)?.[1]);
const browser = JSON.parse(
  readFileSync(resolve(root, '.local/smoke/development/report.json'), 'utf8'),
);
if (!(
  node > 0 &&
  python > 0 &&
  browser.passed &&
  browser.runtimeChanges.passed &&
  browser.runtimeChanges.routes.length === 3 &&
  browser.runtimeChanges.routes.every(
    (r) =>
      r.passed &&
      r.realGPUReplacement &&
      r.rendererFailureKeepsHealthy &&
      r.transitionCancelKeepSwitch,
  ) &&
  browser.execution.passed &&
  browser.execution.routes.length === 3 &&
  browser.execution.routes.every((r) => r.passed && r.quickRecent && r.dirtyPreserved) &&
  browser.inputRecovery.passed &&
  browser.inputRecovery.routes.length === 3 &&
  browser.inputRecovery.routes.every(
    (r) =>
      r.passed &&
      r.realAudioWorklet &&
      r.watchdogWithoutCallbacks &&
      r.manualReconnect &&
      r.projectSaveReopen,
  ) &&
  browser.tracking.passed &&
  browser.tracking.routes.length === 3 &&
  browser.tracking.routes.every(
    (r) => r.passed && r.stableCalibration && r.cancelPreservesBaseline && r.saveDuplicateReopen,
  ) &&
  browser.expressions.passed &&
  browser.expressions.m2CreationExitApproved &&
  browser.expressions.routes.length === 3 &&
  browser.expressions.routes.every(
    (r) => r.passed && r.pixels.passed && r.saveDuplicateReopen && r.damageRepairAndUndo,
  ) &&
  browser.detail.passed &&
  browser.detail.routes.length === 3 &&
  browser.detail.routes.every((r) => r.passed && r.pixels.passed) &&
  browser.split.passed &&
  browser.split.pixels.passed &&
  browser.split.folderPixels.passed &&
  browser.corrections.passed &&
  browser.corrections.pixels.passed &&
  browser.structure.passed &&
  browser.structure.pixels.passed &&
  browser.parts.passed &&
  browser.renderer.partsPixels.passed &&
  browser.input.passed &&
  browser.projects.passed &&
  browser.editor.passed &&
  browser.motion.passed &&
  browser.renderer.motionPixels.passed
))
  throw new Error('E_PROJECT_EVIDENCE');
for (const [source, target] of [
  ['runtime-changes.png', 'runtime-changes-ui.png'],
  ['execution.png', 'execution-ui.png'],
  ['input-recovery.png', 'input-recovery-ui.png'],
  ['tracking.png', 'tracking-ui.png'],
  ['expressions.png', 'expressions-ui.png'],
  ['expression-extremes.png', 'expression-extremes.png'],
  ['detail.png', 'detail-ui.png'],
  ['detail-extremes.png', 'detail-extremes.png'],
  ['split.png', 'split-ui.png'],
  ['split-extremes.png', 'split-extremes.png'],
  ['correction.png', 'correction-ui.png'],
  ['correction-extremes.png', 'correction-extremes.png'],
  ['structure.png', 'structure-ui.png'],
  ['structure-extremes.png', 'structure-extremes.png'],
  ['report.json', 'development-run.json'],
  ['input.png', 'input-ui.png'],
  ['parts.png', 'parts-ui.png'],
  ['parts-contact.png', 'parts-contact.png'],
  ['parts-extremes.png', 'parts-extremes.png'],
  ['workflow.png', 'review-ui.png'],
  ['editor.png', 'editor-ui.png'],
  ['motion.png', 'motion-ui.png'],
  ['project.png', 'project-ui.png'],
  ['studio.png', 'studio-ui.png'],
])
  copyFileSync(resolve(root, '.local/smoke/development', source), join(output, target));
const broadcast = JSON.parse(readFileSync(join(broadcastFolder, 'report.json'), 'utf8'));
if (
  !broadcast.passed ||
  broadcast.broadcast.routes.length !== 3 ||
  !broadcast.broadcast.routes.every(
    (r) => r.passed && r.alpha && r.avatarOnly && r.executionReplacement && r.stalePublisherClears,
  )
)
  throw new Error('E_BROADCAST_EVIDENCE');
copyFileSync(join(broadcastFolder, 'report.json'), join(output, 'broadcast-development-run.json'));
copyFileSync(
  join(broadcastFolder, 'broadcast-ui.png'),
  join(output, 'development-broadcast-ui.png'),
);
const files = JSON.parse(readFileSync(join(fileFolder, 'report.json'), 'utf8'));
if (
  !files.passed ||
  files.fileOutput.images.length !== 14 ||
  files.fileOutput.routes.length !== 3 ||
  !files.fileOutput.staticWithoutMotion ||
  !files.fileOutput.frozenExecutionImage
)
  throw new Error('E_FILE_OUTPUT_EVIDENCE');
const saved = join(output, 'development-files');
mkdirSync(saved, { recursive: true });
for (const file of readdirSync(fileFolder))
  if (file.endsWith('.png')) copyFileSync(join(fileFolder, file), join(saved, file));
copyFileSync(join(fileFolder, 'report.json'), join(output, 'file-output-development-run.json'));
const pixels = spawnSync(
  resolve(root, '.venv-product/Scripts/python.exe'),
  [
    'scripts/file-output-pixels.py',
    '--report=' + join(output, 'file-output-development-run.json'),
    '--images-dir=' + saved,
    '--output=' + join(output, 'pixel-quality.json'),
  ],
  { cwd: root, encoding: 'utf8', windowsHide: true },
);
if (pixels.status !== 0) throw new Error('E_FILE_OUTPUT_PIXELS');
for (const [file, digest] of Object.entries(sources))
  if (
    createHash('sha256')
      .update(readFileSync(resolve(root, file)))
      .digest('hex') !== digest
  )
    throw new Error('E_SOURCE_CHANGED_DURING_VERIFICATION');
writeFileSync(
  join(output, 'verification.json'),
  JSON.stringify(
    {
      passed: true,
      created: new Date().toISOString(),
      appVersion: '0.19.0',
      newFileOutputNodeGroups: 20,
      fileOutputUI: files.fileOutput,
      newBroadcastNodeGroups: 13,
      broadcastUI: broadcast.broadcast,
      newRuntimeChangeNodeGroups: 20,
      runtimeChangesUI: browser.runtimeChanges,
      newExecutionNodeGroups: 17,
      executionUI: browser.execution,
      newInputControlNodeGroups: 20,
      inputRecoveryUI: browser.inputRecovery,
      newTrackingNodeGroups: 18,
      newTrackingPythonGroups: 5,
      trackingUI: browser.tracking,
      newExpressionNodeGroups: 20,
      expressionUI: browser.expressions,
      newDetailNodeGroups: 20,
      detailUI: browser.detail,
      newSplitNodeGroups: 18,
      newSplitPythonGroups: 5,
      splitUI: browser.split,
      node: process.versions.node,
      nodeTestGroups: node,
      pythonTestGroups: python,
      totalTestGroups: node + python,
      newCorrectionNodeGroups: 12,
      newCorrectionPythonGroups: 5,
      correctionUI: browser.corrections,
      newStructureNodeGroups: 8,
      newStructurePythonGroups: 7,
      structureUI: browser.structure,
      newStorageSessionGroups: 19,
      typecheck: true,
      ruff: true,
      generatedValidatorMatches: true,
      testBuild: true,
      newMotionNodeGroups: 16,
      newEditorNodeGroups: 12,
      partsUI: browser.parts,
      partsPixels: browser.renderer.partsPixels,
      newPartsNodeGroups: 12,
      newPartsPythonGroups: 3,
      inputUI: browser.input,
      newInputNodeGroups: 8,
      newInputPythonGroups: 8,
      motionUI: browser.motion,
      motionPixels: browser.renderer.motionPixels,
      browserUI: browser.editor,
      projectLifecycle: browser.projects,
      actualWindowsFiles: true,
      actualProcessTerminationBeforeReplace: true,
      actualRecoveryAfterKilledProcess: true,
      faultInjection: [
        'ENOSPC',
        'EACCES',
        'before-write',
        'after-sync',
        'after-verify',
        'before-backup',
        'after-backup',
        'before-replace',
        'after-replace',
      ],
      scope:
        'Actual static PNG export with matching preview bytes, frozen execution image, explicit target profile and conservative compatibility/normalization-copy review, exact warning scope and stale rejection on three real creation routes; full previous editor/runtime/broadcast receiver regressions. INP file writing/independent avatar use remain phase25; physical devices/OS global keys and M0 acceptance not promoted.',
      followup: ['T-268', 'T-271'],
      sourceSha256: sources,
    },
    null,
    2,
  ) + '\n',
);
console.log(
  `File output, broadcast and prior full regressions passed: ${node}+${python} groups and actual Electron editor/save/recovery UI.`,
);
