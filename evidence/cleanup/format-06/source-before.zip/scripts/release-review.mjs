import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';
import { createHash } from 'node:crypto';
import { extractFile } from '@electron/asar';
import {
  assessRelease,
  requiredChecks,
  incidentIntake,
  transitionIncident,
} from '../tools/release-controls.mjs';
const out = resolve(process.argv[2]);
assert.ok(!existsSync(join(out, 'review.json')), 'E_RELEASE_REVIEW_EXISTS');
mkdirSync(out, { recursive: true });
const hash = (b) => createHash('sha256').update(b).digest('hex'),
  load = (p) => JSON.parse(readFileSync(p, 'utf8'));
function ref(path) {
  assert.ok(!path.includes('..') && !path.includes(':'), 'E_RELEASE_REFERENCE');
  return { path, sha256: hash(readFileSync(path)) };
}
const here = (name) => relative(process.cwd(), join(out, name)).replaceAll('\\', '/');
const candidate = load(join(out, 'candidate/candidate.json')),
  gate = load(join(out, 'gate.json'));
assert.equal(gate.exitCode, 0);
assert.ok(gate.nodeTests >= 338 && gate.pythonTests >= 36);
assert.equal(candidate.originalCandidatePreserved, true);
const full = load(join(out, 'candidate/full.json'));
for (const key of [
  'projects',
  'editor',
  'motion',
  'input',
  'parts',
  'structure',
  'corrections',
  'split',
  'detail',
  'expressions',
  'tracking',
  'inputRecovery',
  'execution',
  'runtimeChanges',
])
  assert.equal(full[key]?.passed, true, 'E_RELEASE_FULL_' + key.toUpperCase());
for (const mode of ['image', 'avatar', 'broadcast'])
  assert.equal(load(join(out, 'candidate/' + mode + '.json')).passed, true);
const imagePixels = load(join(out, 'image-pixels.json')),
  avatarPixels = load(join(out, 'avatar-pixels.json'));
assert.equal(imagePixels.passed, true);
assert.equal(avatarPixels.passed, true);
const targets = load(join(out, 'targets-02/target-scope.json')),
  external = load(join(out, 'targets-02/external-run.json')),
  obs = load(join(out, 'targets-02/obs/obs-run.json'));
assert.equal(targets.passed, true);
assert.equal(targets.appVersion, candidate.candidate.version);
assert.equal(targets.independentRuns, 6);
assert.equal(targets.actualOBSAllThreeRoutes, false);
assert.equal(external.passed, true);
assert.equal(obs.passed, true);
assert.equal(obs.streamingStarted, false);
assert.equal(obs.recordingStarted, false);
assert.equal(external.runs.length, 6);
const exported = load(join(out, 'candidate/avatar.json')).avatarExport.files;
for (const run of external.runs) {
  assert.ok(
    exported.some(
      (file) =>
        file.route === run.route &&
        file.version === run.resultVersion &&
        file.sha256 === run.sourceSha256,
    ),
    'E_RELEASE_EXTERNAL_BASIS',
  );
  for (const key of ['externalFileUnchanged', 'appProcessExited', 'workerStopped', 'qualityPassed'])
    assert.equal(run[key], true, 'E_RELEASE_EXTERNAL_' + key.toUpperCase());
}
const archive = 'out/2DSketcher-win32-x64/resources/app.asar';
assert.equal(
  hash(readFileSync(archive)),
  candidate.candidate.components.find((c) => c.path === 'resources/app.asar').sha256,
  'E_RELEASE_ASAR_DRIFT',
);
const assets = [];
for (const item of load('assets/product/manifest.json').assets) {
  const bytes = extractFile(archive, join('dist/renderer/assets', item.path));
  assert.equal(hash(bytes), item.sha256);
  assets.push({ path: item.path, sha256: item.sha256, bytes: bytes.length });
}
const parts = JSON.parse(
  extractFile(archive, join('dist', 'renderer', 'assets', 'parts', 'catalog.json')),
);
for (const [digest, path] of Object.entries(parts.files)) {
  const bytes = extractFile(archive, join('dist/renderer/assets', path));
  assert.equal(hash(bytes), digest);
  assets.push({ path, sha256: digest, bytes: bytes.length });
}
assert.equal(Object.keys(parts.files).length, 13);
const model = load('worker/resources/model-source.json');
assert.equal(full.worker.modelSha256, model.sha256);
writeFileSync(
  join(out, 'assets.json'),
  JSON.stringify(
    {
      candidateSha256: candidate.candidate.sha256,
      assets,
      premiumPartsPngs: 13,
      model: { id: model.id, sha256: model.sha256, loadedByFrozenWorker: true },
      versions: {
        app: full.appVersion,
        electron: full.electron,
        node: full.node,
        python: full.worker.python,
      },
      publicDistributionRightsApproved: false,
    },
    null,
    2,
  ) + '\n',
);
const historical = {
  m0: ref('docs/planning/05-m0-review.md'),
  contract: ref('docs/planning/05-release-gates.md'),
  integration: ref('evidence/phase27/run-1794981764746/review.json'),
  reliability: ref('evidence/phase28/run-02/review.json'),
  usability: ref('evidence/phase29/run-05/review.json'),
  participant: ref('evidence/phase29/run-01/participant-U29-001-result.json'),
};
const current = ref(here('candidate/full.json')),
  rows = [];
const signature = load(join(out, 'signature.json'));
assert.equal(signature.status, 'NotSigned');
assert.equal(
  signature.exeSha256,
  candidate.candidate.components.find((c) => c.path === '2DSketcher.exe').sha256,
);
const statusFor = (id) =>
  ['AC-11', 'AC-13'].includes(id)
    ? 'PASS'
    : id.startsWith('M0-') ||
        ['PREDECESSOR-29', 'DISTRIBUTION-RIGHTS', 'AC-06', 'AC-15'].includes(id)
      ? 'BLOCKED'
      : id === 'SIGNATURE'
        ? 'FAIL'
        : [
              'PERF-03',
              'PERF-04',
              'RUN-01',
              'ART-01',
              'UX-M0',
              'UX-02',
              'UX-03',
              'UX-04',
              'UX-05',
              'UX-06',
              'CLEAN-WINDOWS',
              'CONTROLLED-TRIAL',
              'AC-10',
            ].includes(id)
          ? 'NOT_RUN'
          : 'PARTIAL';
const sourceFor = (id) =>
  id.startsWith('M0-')
    ? [historical.m0]
    : id.startsWith('PERF-') || id.startsWith('RUN-') || id === 'DATA-01'
      ? [historical.contract, historical.reliability, current]
      : id.startsWith('UX-') || id === 'PREDECESSOR-29' || id === 'AC-15'
        ? [historical.contract, historical.usability, historical.participant]
        : [historical.contract, historical.integration, current];
for (const id of requiredChecks) {
  const evidence =
    id === 'AC-11'
      ? [
          ref(here('candidate/avatar.json')),
          ref(here('avatar-pixels.json')),
          ref(here('targets-02/external-run.json')),
          ref(here('targets-02/target-scope.json')),
        ]
      : id === 'AC-13'
        ? [ref(here('candidate/image.json')), ref(here('image-pixels.json'))]
        : id === 'SIGNATURE'
          ? [ref(here('signature.json'))]
          : sourceFor(id);
  rows.push({
    id,
    status: statusFor(id),
    evidence,
    candidateSha256: ['AC-11', 'AC-13', 'SIGNATURE'].includes(id)
      ? candidate.candidate.sha256
      : null,
  });
}
const decision = assessRelease(candidate.candidate, rows);
assert.equal(decision.decision, 'HOLD');
// Preserve the exact wording of thresholds and distinguish target values from measurements.
const contract = readFileSync('docs/planning/05-release-gates.md', 'utf8');
const thresholds = contract
  .split(/\r?\n/)
  .filter((line) => /^\| (PERF|RUN|DATA|ART|OUT|UX)-/.test(line))
  .map((line) => ({
    id: line.match(/^\| ([A-Z]+-[A-Z0-9]+)/)[1],
    contractRow: line,
    measurement: 'See cited bounded evidence; full target not demonstrated',
    status: statusFor(line.match(/^\| ([A-Z]+-[A-Z0-9]+)/)[1]),
  }));
writeFileSync(
  join(out, 'readiness.json'),
  JSON.stringify(
    {
      ...decision,
      targets: thresholds,
      boundedHistoricalDiagnostics: {
        scope: 'Phase28 single-scene 12 seconds per condition; not current candidate acceptance',
        evidence: historical.reliability,
        measurements: load('evidence/phase28/run-02/review.json').webglDiagnostics,
      },
      currentCandidateAcceptanceMeasurements: {
        twoHourRuns: 0,
        cameraToOBSLatencyMs: null,
        independentLatencyMs: null,
        processTreeRSSMiB: null,
        qualityPanelScore: null,
        noviceTaskSeconds: null,
        correctionCount: null,
      },
      historicalEvidenceRevalidatedOnThisCandidate: false,
      physicalDevicesVerified: false,
      actualOBSReceiptVerified: true,
      actualOBSRoute: 'split-image final prepared route',
      actualOBSAllThreeRoutes: false,
      actualIndependentRuntimeVerified: true,
      independentRuns: 6,
      cleanWindowsVerified: false,
      noviceVerified: false,
    },
    null,
    2,
  ) + '\n',
);
let camera = incidentIntake({
  consent: true,
  id: 'INC30-001',
  appVersion: candidate.candidate.version,
  route: 'application',
  stage: 'camera',
  symptom: 'no-face',
  origin: 'developer-observation',
  evidenceLevel: 'unverified',
  environment: { os: 'windows11', arch: 'x64', camera: 'unknown' },
});
camera = transitionIncident(camera, 'TRIAGED');
writeFileSync(
  join(out, 'known-incidents.json'),
  JSON.stringify(
    {
      origin: 'Existing local evidence review; not post-release user intake',
      incidents: [
        {
          ...camera,
          relatedIssue: 'INT27-CAM-01',
          evidence: [historical.integration],
          mitigation: 'Device-free manual execution; not a fix',
          reproducedOnCurrentCandidate: false,
          fixed: false,
          released: false,
        },
      ],
      newPostReleaseReports: 0,
    },
    null,
    2,
  ) + '\n',
);
const files = [
  'tools/release-controls.mjs',
  'scripts/release-candidate-check.mjs',
  'scripts/release-external-check.mjs',
  'scripts/release-review.mjs',
  'tests/release-controls.test.mjs',
  'scripts/test.mjs',
  'docs/planning/30-release-stabilization.md',
  'docs/user/incident-response.md',
];
const sourceSha256 = Object.fromEntries(files.map((path) => [path, hash(readFileSync(path))]));
for (const entry of load('evidence/phase29/run-05/review.json').sources.filter(
  (s) =>
    s.path.startsWith('apps/') ||
    s.path.startsWith('packages/') ||
    [
      'package.json',
      'package-lock.json',
      'forge.config.cjs',
      'scripts/build.mjs',
      'scripts/prepare-release.mjs',
    ].includes(s.path),
))
  assert.equal(hash(readFileSync(entry.path)), entry.sha256, 'E_RELEASE_PRODUCT_SOURCE_DRIFT');
const privacyScan = [];
function scan(dir) {
  for (const file of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, file.name);
    if (file.isDirectory()) scan(path);
    else if (file.name.endsWith('.json')) {
      assert.ok(
        !/[A-Za-z]:[\\/]+Users[\\/]/i.test(readFileSync(path, 'utf8')),
        'E_RELEASE_PRIVACY',
      );
      privacyScan.push(relative(out, path).replaceAll('\\', '/'));
    }
  }
}
scan(out);
const result = {
  phase: 30,
  localVerificationPassed: true,
  entirePhaseComplete: false,
  releaseDecision: 'HOLD',
  m0: 'HOLD',
  completedTasks: ['T-292', 'T-293', 'T-294', 'T-300'],
  incompleteTasks: ['T-291', 'T-295', 'T-296', 'T-297', 'T-298', 'T-299'],
  gate,
  candidate: candidate.candidate,
  requiredChecks: requiredChecks.length,
  blockingChecks: decision.blockers.length,
  productSourcePinsUnchanged: true,
  packagingChanged: false,
  publicDistributionApproved: false,
  signed: false,
  published: false,
  postReleaseFeedbackCount: 0,
  physicalDevicesOpened: false,
  rawMediaStored: false,
  privacyScan,
  sourceSha256,
};
writeFileSync(join(out, 'review.json'), JSON.stringify(result, null, 2) + '\n');
console.log('T292/293/294/300 local work verified; release and remaining tasks stay HOLD.');
