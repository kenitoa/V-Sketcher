import assert from 'node:assert/strict';
import {
  cpSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
  readdirSync,
  statSync,
  existsSync,
  renameSync,
} from 'node:fs';
import { resolve, join, relative } from 'node:path';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { listPackage, extractFile } from '@electron/asar';
import { root } from './common.mjs';
const evidence = resolve(
  root,
  process.argv.find((v) => v.startsWith('--evidence-dir='))?.slice(15) ??
    '.local/avatar-export-package-' + Date.now(),
);
mkdirSync(evidence, { recursive: true });
assert.ok(!existsSync(join(evidence, 'package-audit.json')), 'E_EVIDENCE_EXISTS');
const source = resolve(root, 'out/2DSketcher-win32-x64'),
  target = resolve(root, '.local/isolated', 'avatar-export-' + Date.now(), '한글 경로 with spaces'),
  bundle = join(target, '2DSketcher');
mkdirSync(target, { recursive: true });
cpSync(source, bundle, { recursive: true, errorOnExist: true, force: false });
const archive = join(bundle, 'resources/app.asar'),
  entries = listPackage(archive).map((p) => p.replaceAll('\\', '/'));
assert.ok(
  !entries.some((p) =>
    /(^|\/)(experiments|tests|\.git|\.venv-product|\.local|scripts|tools|worker\/main\.py|electron-forge|typescript|vite)(\/|$)/.test(
      p,
    ),
  ),
);
assert.ok(!entries.some((p) => /obs64\.exe/.test(p)));
const file = (p) => extractFile(archive, join(...p.split('/'))),
  digest = (b) => createHash('sha256').update(b).digest('hex');
assert.equal(JSON.parse(file('dist/runtime-config.json')).channel, 'release');
assert.equal(JSON.parse(file('package.json')).version, '0.20.0');
assert.equal(JSON.parse(file('dist/renderer/assets/preview-project.json')).schemaVersion.minor, 9);
const manifest = JSON.parse(readFileSync('assets/product/manifest.json'));
for (const asset of manifest.assets)
  assert.equal(digest(file('dist/renderer/assets/' + asset.path)), asset.sha256);
const catalog = JSON.parse(readFileSync('assets/product/parts/catalog.json'));
for (const [sha, path] of Object.entries(catalog.files))
  assert.equal(digest(file('dist/renderer/assets/' + path)), sha);
const split = JSON.parse(readFileSync('assets/product/split/manifest.json'));
assert.equal(digest(file('dist/renderer/assets/split/premium-example.2dparts')), split.sha256);
const system = process.env.SystemRoot ?? 'C:\\Windows',
  env = Object.fromEntries(
    Object.entries(process.env).filter(
      ([k]) => !/^(PYTHON|NODE|NPM|ELECTRON|VIRTUAL_ENV|CONDA|VSCODE)/i.test(k),
    ),
  );
env.PATH = join(system, 'System32');
for (const command of ['node', 'npm', 'python', 'py'])
  assert.notEqual(
    spawnSync(join(system, 'System32/where.exe'), [command], {
      cwd: target,
      env,
      windowsHide: true,
    }).status,
    0,
  );
const reports = [];
for (const attempt of [1, 2]) {
  const scenario = join(evidence, 'packaged-' + attempt);
  mkdirSync(scenario, { recursive: true });
  const reportPath = join(target, `report-${attempt}.json`),
    args = [
      '--avatar-export-only=true',
      `--profile-dir=${join(target, 'profile-' + attempt)}`,
      `--self-check-report=${reportPath}`,
      `--avatar-export-evidence=${scenario}`,
    ];
  if (attempt === 2) args.push('--compact-editor=true');
  const result = spawnSync(join(bundle, '2DSketcher.exe'), args, {
    cwd: target,
    env,
    windowsHide: true,
    encoding: 'utf8',
    timeout: 1200000,
  });
  writeFileSync(
    join(target, 'launch-' + attempt + '.log'),
    (result.stdout ?? '') + (result.stderr ?? ''),
  );
  if (result.error) throw result.error;
  const bytes = readFileSync(reportPath),
    report = JSON.parse(bytes);
  writeFileSync(join(evidence, `packaged-run-${attempt}.json`), bytes);
  writeFileSync(join(scenario, 'report.json'), bytes);
  assert.equal(result.status, 0);
  assert.equal(report.passed, true);
  assert.equal(report.packaged, true);
  assert.equal(report.appVersion, '0.20.0');
  assert.equal(report.channel, 'release');
  assert.equal(report.worker.frozen, true);
  assert.equal(report.worker.dependencyFilesInsideBundle, true);
  assert.equal(report.workerStopped, true);
  const ui = report.avatarExport;
  assert.equal(ui.passed, true);
  assert.equal(ui.routes.length, 3);
  for (const route of ui.routes)
    for (const key of [
      'passed',
      'actualRoutePreparation',
      'conversionPreview',
      'reviewRequired',
      'realINPWrite',
      'staleRejected',
      'reexport',
      'oldConfirmationStale',
      'targetVersionRejected',
      'settingsReopened',
    ])
      assert.equal(route[key], true);
  assert.equal(ui.files.length, 6);
  assert.equal(ui.images.length, 42);
  assert.equal(ui.actualFileMoveReconnected, true);
  assert.equal(ui.resourcesReleased, true);
  assert.equal(ui.programmaticConfirmationOnly, true);
  assert.equal(ui.actualExternalRuntimeVerified, false);
  assert.equal(ui.deviceRequests, 0);
  assert.equal(ui.m0, 'HOLD');
  assert.deepEqual(report.protections, {
    sandbox: true,
    contextIsolation: true,
    nodeIntegration: false,
    externalNetworkBlocked: true,
  });
  if (attempt === 2) assert.deepEqual(report.windowSize, [1080, 720]);
  for (const f of ui.files) assert.equal(digest(readFileSync(join(scenario, f.name))), f.sha256);
  writeFileSync(
    join(scenario, 'runner.json'),
    JSON.stringify(
      {
        passed: true,
        appProcessExited: true,
        exitCode: result.status,
        workerStopped: report.workerStopped,
        reportSha256: digest(bytes),
      },
      null,
      2,
    ) + '\n',
  );
  const pixel = spawnSync(
    resolve(root, '.venv-product/Scripts/python.exe'),
    [
      'scripts/avatar-export-pixels.py',
      '--report=' + join(evidence, `packaged-run-${attempt}.json`),
      '--images-dir=' + scenario,
      '--output=' + join(evidence, `pixel-quality-release-${attempt}.json`),
    ],
    { cwd: root, encoding: 'utf8', windowsHide: true },
  );
  assert.equal(pixel.status, 0, 'E_AVATAR_EXPORT_PIXELS');
  reports.push({ attempt, passed: true, freshProfile: true, windowSize: report.windowSize });
}
const files = [];
function walk(dir) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, entry.name);
    if (entry.isDirectory()) walk(p);
    else
      files.push({
        path: relative(source, p).replaceAll('\\', '/'),
        bytes: statSync(p).size,
        sha256: digest(readFileSync(p)),
      });
  }
}
walk(source);
writeFileSync(
  join(evidence, 'package-audit.json'),
  JSON.stringify(
    {
      passed: true,
      toolSourceSha256: digest(readFileSync('scripts/avatar-export-package-check.mjs')),
      appVersion: '0.20.0',
      commonProjectSchema: '1.9',
      scope:
        'Six actual INP outputs on three creation routes; 42 original/native-state pixel pairs; frozen input, explicit approximation review, save/re-export, version/hash-scoped confirmation and actual file-move reconnect.',
      cleanWindowsOS: false,
      isolation: {
        developerToolsOnPath: false,
        externalNodeOrPythonRequired: false,
        freshProfiles: 2,
        unicodeAndSpacePath: true,
        externalNetworkBlocked: true,
      },
      reports,
      archiveEntries: entries.length,
      forbiddenDevelopmentContent: false,
      obsBundled: false,
      packageBytes: files.reduce((n, v) => n + v.bytes, 0),
      limitations: [
        'Same Windows installation/drivers/system DLLs retained',
        'Official external target capture is recorded separately; no physical-device/OS-global-key/M0 acceptance',
      ],
      files,
    },
    null,
    2,
  ) + '\n',
);
console.log('Avatar export release passed twice without developer tools on PATH.');
