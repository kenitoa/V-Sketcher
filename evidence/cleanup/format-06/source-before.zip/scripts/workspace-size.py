"""Read-only workspace inventory. Skip directory links; never emit personal paths."""

import argparse
import ctypes
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    output = (ROOT / args.output).resolve()
    if not output.is_relative_to(ROOT / 'evidence/cleanup') or output.exists():
        raise ValueError('E_SIZE_OUTPUT')
    output.parent.mkdir(parents=True, exist_ok=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    allocated = kernel.GetCompressedFileSizeW
    allocated.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_ulong)]
    allocated.restype = ctypes.c_ulong
    by_root, by_local = {}, {}
    seen = set()
    totals = {
        'files': 0,
        'logicalBytes': 0,
        'allocatedBytes': 0,
        'uniqueLogicalBytes': 0,
        'uniqueAllocatedBytes': 0,
        'skippedDirectoryLinks': 0,
        'errors': 0,
    }

    def add(bucket, name, size, disk):
        row = bucket.setdefault(name, {'files': 0, 'logicalBytes': 0, 'allocatedBytes': 0})
        row['files'] += 1
        row['logicalBytes'] += size
        row['allocatedBytes'] += disk

    stack = [ROOT]
    while stack:
        directory = stack.pop()
        try:
            entries = list(os.scandir(directory))
        except OSError:
            totals['errors'] += 1
            continue
        for entry in entries:
            try:
                if entry.is_dir(follow_symlinks=False):
                    if entry.is_symlink() or os.path.isjunction(entry.path):
                        totals['skippedDirectoryLinks'] += 1
                    else:
                        stack.append(Path(entry.path))
                    continue
                if entry.is_symlink() or not entry.is_file(follow_symlinks=False):
                    continue
                stat = entry.stat(follow_symlinks=False)
                # Windows DirEntry.stat can omit the file index; os.stat obtains it.
                if not stat.st_ino or not stat.st_dev:
                    stat = os.stat(entry.path, follow_symlinks=False)
                high = ctypes.c_ulong()
                ctypes.set_last_error(0)
                low = allocated(entry.path, ctypes.byref(high))
                if low == 0xFFFFFFFF and ctypes.get_last_error():
                    raise OSError('E_SIZE_ALLOCATION')
                disk = (high.value << 32) | low
                rel = Path(entry.path).relative_to(ROOT)
                add(
                    by_root,
                    rel.parts[0] if len(rel.parts) > 1 else '(root files)',
                    stat.st_size,
                    disk,
                )
                if rel.parts[0] == '.local' and len(rel.parts) > 2:
                    add(by_local, rel.parts[1], stat.st_size, disk)
                totals['files'] += 1
                totals['logicalBytes'] += stat.st_size
                totals['allocatedBytes'] += disk
                identity = (stat.st_dev, stat.st_ino) if stat.st_ino else entry.path
                if identity not in seen:
                    totals['uniqueLogicalBytes'] += stat.st_size
                    totals['uniqueAllocatedBytes'] += disk
                    seen.add(identity)
            except OSError:
                totals['errors'] += 1
    report = {
        'format': '2dsketcher-workspace-size/1',
        'totals': totals,
        'topLevel': dict(sorted(by_root.items(), key=lambda pair: -pair[1]['logicalBytes'])),
        'localGroups': dict(sorted(by_local.items(), key=lambda pair: -pair[1]['logicalBytes'])),
        'directoryLinksFollowed': False,
        'privatePathsStored': False,
    }
    output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(
        json.dumps(
            {
                'files': totals['files'],
                'logicalGiB': round(totals['logicalBytes'] / 1024**3, 3),
                'allocatedGiB': round(totals['uniqueAllocatedBytes'] / 1024**3, 3),
                'errors': totals['errors'],
            }
        )
    )


if __name__ == '__main__':
    try:
        main()
    except Exception:
        print('E_WORKSPACE_SIZE')
        raise SystemExit(1)
