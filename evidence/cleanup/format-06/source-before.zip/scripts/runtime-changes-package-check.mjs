import assert from 'node:assert/strict';
import { cpSync, mkdirSync, readFileSync, writeFileSync, readdirSync, statSync } from 'node:fs';
import { resolve, join, relative } from 'node:path';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { listPackage, extractFile } from '@electron/asar';
import { root } from './common.mjs';
const source = resolve(root, 'out/2DSketcher-win32-x64'),
  target = resolve(
    root,
    '.local/isolated',
    'runtime-changes-' + Date.now(),
    '한글 경로 with spaces',
  ),
  bundle = join(target, '2DSketcher');
mkdirSync(target, { recursive: true });
cpSync(source, bundle, { recursive: true, errorOnExist: true, force: false });
const evidence = resolve(
  root,
  process.argv.find((v) => v.startsWith('--evidence-dir='))?.slice(15) ??
    '.local/smoke/runtime-changes-package',
);
mkdirSync(evidence, { recursive: true });
const archive = join(bundle, 'resources/app.asar'),
  entries = listPackage(archive).map((p) => p.replaceAll('\\', '/'));
assert.ok(
  !entries.some((p) =>
    /(^|\/)(experiments|tests|\.git|\.venv-product|\.local|scripts|worker\/main\.py|electron-forge|typescript|vite)(\/|$)/.test(
      p,
    ),
  ),
);
assert.equal(
  JSON.parse(extractFile(archive, join('dist', 'runtime-config.json'))).channel,
  'release',
);
assert.equal(JSON.parse(extractFile(archive, 'package.json')).version, '0.17.0');
const file = (path) => extractFile(archive, join(...path.split('/')));
const digest = (b) => createHash('sha256').update(b).digest('hex');
const provenance = JSON.parse(readFileSync('assets/product/split/manifest.json'));
const sample = file('dist/renderer/assets/split/premium-example.2dparts');
assert.equal(digest(sample), provenance.sha256);
assert.equal(JSON.parse(file('dist/renderer/assets/preview-project.json')).schemaVersion.minor, 9);
const assetManifest = JSON.parse(readFileSync('assets/product/manifest.json'));
for (const item of assetManifest.assets)
  assert.equal(digest(extractFile(archive, join('dist/renderer/assets', item.path))), item.sha256);
const catalog = JSON.parse(file('dist/renderer/assets/parts/catalog.json'));
for (const [sha, path] of Object.entries(catalog.files))
  assert.equal(digest(extractFile(archive, join('dist/renderer/assets', path))), sha);
const system = process.env.SystemRoot ?? 'C:\\Windows',
  env = Object.fromEntries(
    Object.entries(process.env).filter(
      ([key]) => !/^(PYTHON|NODE|NPM|ELECTRON|VIRTUAL_ENV|CONDA|VSCODE)/i.test(key),
    ),
  );
env.PATH = join(system, 'System32');
for (const command of ['node', 'npm', 'python', 'py'])
  assert.notEqual(
    spawnSync(join(system, 'System32/where.exe'), [command], {
      cwd: target,
      env,
      windowsHide: true,
    }).status,
    0,
  );
const reports = [];
for (const attempt of [1, 2]) {
  const reportPath = join(target, `report-${attempt}.json`),
    args = [
      '--runtime-changes-only=true',
      `--profile-dir=${join(target, 'profile-' + attempt)}`,
      `--self-check-report=${reportPath}`,
      `--runtime-changes-screenshot=${join(evidence, attempt === 1 ? 'release-runtime-changes.png' : 'release-runtime-changes-compact.png')}`,
    ];
  if (attempt === 2) args.push('--compact-editor=true');
  const result = spawnSync(join(bundle, '2DSketcher.exe'), args, {
    cwd: target,
    env,
    windowsHide: true,
    encoding: 'utf8',
    timeout: 600000,
  });
  writeFileSync(
    join(target, 'launch-' + attempt + '.log'),
    (result.stdout ?? '') + (result.stderr ?? ''),
  );
  if (result.error) throw result.error;
  const report = JSON.parse(readFileSync(reportPath));
  writeFileSync(
    join(evidence, 'packaged-run-' + attempt + '.json'),
    JSON.stringify(report, null, 2) + '\n',
  );
  assert.equal(result.status, 0);
  assert.equal(report.passed, true);
  assert.equal(report.packaged, true);
  assert.equal(report.channel, 'release');
  assert.equal(report.appVersion, '0.17.0');
  assert.equal(report.worker.frozen, true);
  assert.equal(report.worker.dependencyFilesInsideBundle, true);
  assert.equal(report.workerStopped, true);
  assert.equal(report.runtimeChanges.passed, true);
  assert.equal(report.runtimeChanges.routes.length, 3);
  for (const route of report.runtimeChanges.routes) {
    for (const key of [
      'passed',
      'actualRoutePreparation',
      'validatedImmediateControls',
      'expressionSnapshotApplied',
      'workingAndExecutionSeparate',
      'candidateGPUIsolation',
      'duplicatePrepareSuppressed',
      'prepareCancel',
      'staleCommitRejected',
      'realGPUReplacement',
      'rendererFailureKeepsHealthy',
      'logicalRestart',
      'transitionCancelKeepSwitch',
      'explicitInputBasis',
      'workingSavePinned',
      'heavyDeferred',
      'noUnneededDeviceOpen',
      'allSurfacesReleased',
    ])
      assert.equal(route[key], true);
  }
  assert.equal(report.runtimeChanges.devicesOpened, false);
  assert.equal(report.runtimeChanges.physicalDevices, 'NOT_RUN');
  assert.equal(report.runtimeChanges.osGlobalKeyDelivery, 'NOT_RUN');
  assert.equal(report.runtimeChanges.actualAudioWorklet, true);
  assert.equal(report.runtimeChanges.actualLocalInference, true);
  assert.equal(report.runtimeChanges.projectRebindKeepsBothStreams, true);
  assert.equal(report.runtimeChanges.deviceRequests, 2);
  assert.equal(report.runtimeChanges.m0, 'HOLD');
  assert.equal(report.renderer.diagnosticsVisible, false);
  assert.equal(report.renderer.workflowLabVisible, false);
  assert.equal(report.renderer.projectModel.schemaVersion, '1.9');
  assert.equal(report.priorRouteUI, 'NOT_RUN');
  assert.equal(report.devicesOpened, false);
  assert.deepEqual(report.protections, {
    sandbox: true,
    contextIsolation: true,
    nodeIntegration: false,
    externalNetworkBlocked: true,
  });
  reports.push({
    attempt,
    freshProfile: true,
    passed: true,
    exitCode: result.status,
    windowSize: report.windowSize,
  });
}
const inventory = [];
function walk(dir) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) walk(path);
    else
      inventory.push({
        path: relative(source, path).replaceAll('\\', '/'),
        bytes: statSync(path).size,
        sha256: digest(readFileSync(path)),
      });
  }
}
walk(source);
writeFileSync(
  join(evidence, 'package-audit.json'),
  JSON.stringify(
    {
      passed: true,
      toolSourceSha256: digest(readFileSync('scripts/runtime-changes-package-check.mjs')),
      appVersion: '0.17.0',
      commonProjectSchema: '1.9',
      scope:
        'Concurrent editor/run revisions, GPU candidates and rollback, project transitions, explicit input basis and save on three actual routes; synthetic audio/video, actual AudioWorklet and local inference, persistent input ownership; prior feature UI NOT_RUN in packaged scope (full development regression recorded separately)',
      userApprovedScope: 'Same PC isolated runtime; no separate PC or VM available',
      cleanWindowsOS: false,
      isolation: {
        developerToolsOnPath: false,
        externalNodeOrPythonRequired: false,
        freshProfiles: 2,
        unicodeAndSpacePath: true,
        rendererExternalNetworkBlocked: true,
        systemNetworkDisabled: false,
      },
      reports,
      splitExampleSha256: digest(sample),
      archiveEntries: entries.length,
      forbiddenDevelopmentContent: false,
      packageBytes: inventory.reduce((n, v) => n + v.bytes, 0),
      limitations: [
        'Same Windows installation/drivers/system DLLs retained',
        'No physical unplug/human audio scene, OBS, independent avatar export or M0 performance approval',
      ],
      files: inventory,
    },
    null,
    2,
  ) + '\n',
);
console.log(
  'Runtime changes passed on three routes twice with frozen worker and no developer tools on PATH.',
);
