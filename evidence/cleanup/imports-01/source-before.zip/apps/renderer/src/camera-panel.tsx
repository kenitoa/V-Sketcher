import { environmentValue } from './environment-state';
import React, { useEffect, useRef, useState } from 'react';
import type { Project } from '../../../packages/project-model';
import { defaultTracking, cameraMessages, type TrackingSettings } from '../../../packages/tracking';
import { motionNames } from '../../../packages/motion';
import { ExpressionPreview } from './expression-preview';
import type { PreviewScene } from '../../../packages/scene-core';
import type { CameraRuntime } from './camera-runtime';
export function CameraPanel({
  runtime: r,
  project: p,
  scene,
  save,
}: {
  runtime: CameraRuntime;
  project: Project;
  scene: PreviewScene | null;
  save: (value: TrackingSettings) => void;
}) {
  const [, refresh] = useState(0),
    [devices, setDevices] = useState<MediaDeviceInfo[]>([]),
    [chosen, setChosen] = useState(environmentValue().cameraId),
    host = useRef<HTMLDivElement>(null);
  const list = async () => {
    const values = await r.devices();
    setDevices(values);
    setChosen((prior) =>
      r.deviceId && values.some((v) => v.deviceId === r.deviceId) ? r.deviceId : prior || '',
    );
  };
  useEffect(() => {
    void list();
    const update = () => void list();
    navigator.mediaDevices.addEventListener('devicechange', update);
    const timer = setInterval(() => refresh((v) => v + 1), 100);
    return () => {
      clearInterval(timer);
      navigator.mediaDevices.removeEventListener('devicechange', update);
    };
  }, []);
  useEffect(() => {
    if (r.showPreview && host.current) {
      host.current.appendChild(r.previewCanvas);
      r.previewCanvas.className = r.mirror ? 'camera-video mirrored' : 'camera-video';
    }
    return () => {
      if (r.previewCanvas.parentElement === host.current) r.previewCanvas.remove();
    };
  }, [r.showPreview, r.mirror]);
  const config = p.tracking ?? defaultTracking();
  return (
    <div className="camera-layout" data-camera-panel>
      <ExpressionPreview scene={scene} player={r.player} />
      <div className="camera-controls">
        {r.reviewPrompt && (
          <div className="camera-review" role="alert">
            {r.reviewPrompt}
            {r.reviewCanStart && (
              <button
                data-camera-review-start
                disabled={
                  r.state !== 'open' ||
                  !r.selected ||
                  r.selected.brightness < 35 ||
                  Math.abs(r.selected.values.head_yaw) > 20 ||
                  Math.abs(r.selected.values.head_roll) > 15
                }
                onClick={() => {
                  r.reviewStartRequested = true;
                }}
              >
                얼굴 확인 완료 · 실제 시험 시작
              </button>
            )}
          </div>
        )}
        <label>
          카메라
          <select
            data-camera-device
            value={chosen}
            disabled={r.state === 'connecting'}
            onChange={(e) => setChosen(e.target.value)}
          >
            <option value="">Windows 기본 카메라</option>
            {chosen && !devices.some((d) => d.deviceId === chosen) && (
              <option value={chosen}>저장한 카메라 없음 · 다시 선택</option>
            )}
            {devices.map((d, i) => (
              <option key={d.deviceId || i} value={d.deviceId}>
                {d.label || `카메라 ${i + 1}`}
              </option>
            ))}
          </select>
        </label>
        <div className="expression-actions">
          <button data-camera-refresh onClick={() => void list()}>
            목록 새로 고침
          </button>
          <button
            data-camera-start
            disabled={r.state === 'connecting'}
            onClick={() => void r.start(chosen).then(list)}
          >
            선택한 카메라 연결
          </button>
          <button data-camera-stop disabled={r.state === 'idle'} onClick={() => r.stop()}>
            카메라 중지
          </button>
          <button onClick={() => r.player.stop()}>편집 시험 해제</button>
        </div>
        {r.sourceLabel && <p data-camera-active-device>연결된 입력: {r.sourceLabel}</p>}
        <small>
          가상 입력이 아닌 실제 웹캠을 시험하려면 본인의 실사 얼굴이 보이는 장치를 선택해 주세요.
          목록 이름은 연결 후 확인할 수 있습니다.
        </small>
        {r.stale > 0 && r.state === 'open' && (
          <small>
            지연된 분석 결과 {r.stale}개를 동작 제어에서 제외했어요. 보정은 영상 획득 시각의 안정된
            표본을 사용합니다.
          </small>
        )}
        <p data-camera-state role="status">
          {r.state === 'idle'
            ? '카메라 중지'
            : r.state === 'connecting'
              ? '로컬 추적기·카메라 연결 중'
              : r.state === 'failed'
                ? '입력 중단'
                : `영상 수신 · ${r.resolution} · 얼굴 ${r.result?.faces.length ?? 0}명 · ${r.target.state === 'tracked' ? '선택 대상 추적 중' : r.target.state === 'ambiguous' ? '대상 겹침 · 선택 필요' : r.target.state === 'lost' ? '대상 놓침 · 다시 선택해 주세요' : r.target.state === 'select' ? '대상 선택 필요' : '얼굴 검출 대기'}`}
        </p>
        {r.errorCode && (
          <p role="alert">
            {cameraMessages[r.errorCode] ??
              '입력을 확인하지 못했어요. 중지한 뒤 다시 연결해 주세요.'}
          </p>
        )}
        {r.result && (r.selected?.brightness ?? r.result.brightness) < 35 && (
          <p role="alert">
            조명이 어두워 추적과 보정이 불안정할 수 있어요. 얼굴 쪽 조명을 밝혀 주세요.
          </p>
        )}
        <label>
          <input
            data-camera-preview
            type="checkbox"
            checked={r.showPreview}
            onChange={(e) => {
              r.showPreview = e.target.checked;
              refresh((v) => v + 1);
            }}
          />
          사용자용 카메라 영상 표시
        </label>
        <label>
          <input
            data-camera-mirror
            type="checkbox"
            checked={r.mirror}
            onChange={(e) => {
              r.mirror = e.target.checked;
              refresh((v) => v + 1);
            }}
          />
          카메라 미리보기만 좌우 반전
        </label>
        <div ref={host} className="camera-source" hidden={!r.showPreview || r.state !== 'open'}>
          <svg
            className="camera-face-overlay"
            viewBox="0 0 1 1"
            preserveAspectRatio="none"
            aria-label="검출한 얼굴 위치"
          >
            {r.result?.faces.map((face, i) => {
              const b = face.box,
                x = r.mirror ? 1 - b.x - b.width : b.x;
              return (
                <g key={i}>
                  <rect x={x} y={b.y} width={b.width} height={b.height} />
                  <text x={x + 0.01} y={Math.max(0.05, b.y - 0.01)}>
                    {i + 1}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
        <div className="expression-actions">
          {r.result?.faces.map((face, i) => (
            <button key={i} data-camera-target={i} onClick={() => r.select(face.box)}>
              얼굴 {i + 1} 선택
            </button>
          ))}
        </div>
        <small>
          얼굴 겹침·미검출 0.5초·영상 관찰 공백 2초에는 대상을 다시 선택합니다. 자동으로 다른 사람을
          고르지 않습니다. 위치 연속성이며 사람의 신원을 식별하지는 않습니다.
        </small>
        {r.selected && (
          <p data-camera-quality>
            선택 얼굴 밝기 {r.selected.brightness.toFixed(0)} · 고개 좌우{' '}
            {r.selected.values.head_yaw.toFixed(1)}° · 기울기{' '}
            {r.selected.values.head_roll.toFixed(1)}°
          </p>
        )}
        <section className="camera-calibration">
          <h3>정면·중립 보정</h3>
          <p>
            밝은 곳에서 정면을 보고 눈을 뜬 채 입을 편하게 다물어 주세요. 표정·편집 시험 값은 보정에
            사용하지 않습니다.
          </p>
          <div className="expression-actions">
            <button
              data-camera-calibrate
              disabled={r.state !== 'open' || !r.selected || r.calibration.state === 'collecting'}
              onClick={() => r.beginCalibration()}
            >
              중립 다시 맞추기
            </button>
            <button
              data-camera-cancel
              disabled={r.calibration.state !== 'collecting' && r.calibration.state !== 'ready'}
              onClick={() => r.calibration.cancel()}
            >
              보정 취소
            </button>
            <button
              data-camera-calibration-apply
              disabled={r.calibration.state !== 'ready'}
              onClick={() => void r.applyCalibration()}
            >
              새 기준 적용
            </button>
          </div>
          <p data-camera-calibration-state role="status">
            {r.profile
              ? '이 카메라·해상도의 저장 기준 사용 중'
              : '기본 기준 사용 중 · 장치 보정 전'}{' '}
            ·{' '}
            {r.calibration.state === 'collecting'
              ? `안정된 입력 수집 ${r.calibration.count}개`
              : r.calibration.state === 'ready'
                ? '새 기준 준비됨 · 적용 전까지 기존 기준 유지'
                : r.calibration.state === 'cancelled'
                  ? '보정 취소 · 기존 기준 유지'
                  : r.calibration.state === 'failed'
                    ? '보정 실패 · 기존 기준 유지'
                    : ''}
          </p>
          {r.calibration.reason && <p>{r.calibration.reason}</p>}
        </section>
        <details data-camera-mapping>
          <summary>프로젝트의 방향·범위·강도·부드러움</summary>
          {config.channels.map((c, i) => (
            <form
              key={`${c.key}-${JSON.stringify(c)}`}
              onSubmit={(event) => {
                event.preventDefault();
                const data = new FormData(event.currentTarget),
                  next = structuredClone(config);
                next.channels[i] = {
                  ...c,
                  enabled: data.has('enabled'),
                  invert: data.has('invert'),
                  range: [Number(data.get('min')), Number(data.get('max'))],
                  gain: Number(data.get('gain')),
                  smoothingMs: Number(data.get('smooth')),
                  deadzone: Number(data.get('deadzone')),
                };
                save(next);
              }}
            >
              <fieldset disabled={!r.player.list().some((v) => v.key === c.key && v.supported)}>
                <legend>
                  {motionNames[c.key]}
                  {!r.player.list().some((v) => v.key === c.key && v.supported) &&
                    ' · 표시 가능한 연결 부위 없음'}
                </legend>
                <label>
                  <input type="checkbox" name="enabled" defaultChecked={c.enabled} />
                  입력 사용
                </label>
                <label>
                  <input type="checkbox" name="invert" defaultChecked={c.invert} />
                  캐릭터 반응 방향 반전
                </label>
                <div className="expression-row">
                  {[
                    ['min', '입력 최소', c.range[0]],
                    ['max', '입력 최대', c.range[1]],
                    ['gain', '강도', c.gain],
                    ['smooth', '부드러움(ms)', c.smoothingMs],
                    ['deadzone', '중립 여유', c.deadzone],
                  ].map(([name, label, value]) => (
                    <label key={name}>
                      {label}
                      <input
                        name={String(name)}
                        type="number"
                        required
                        step={name === 'smooth' ? '1' : '.01'}
                        defaultValue={value}
                        min={
                          name === 'smooth'
                            ? 0
                            : name === 'gain' || name === 'deadzone'
                              ? 0
                              : c.key.startsWith('head')
                                ? -80
                                : c.key === 'mouth'
                                  ? -1
                                  : 0
                        }
                        max={
                          name === 'smooth'
                            ? 500
                            : name === 'gain'
                              ? 2
                              : name === 'deadzone'
                                ? 0.1
                                : c.key.startsWith('head')
                                  ? 80
                                  : c.key.startsWith('eye')
                                    ? 2
                                    : 1
                        }
                      />
                    </label>
                  ))}
                </div>
                <button type="submit" data-camera-map-save={c.key}>
                  매핑 저장
                </button>
              </fieldset>
            </form>
          ))}
          <small>
            고개는 보정 정면 기준 각도(도), 눈은 기본 열림 1의 배수, 입은 중립 기준 변화량입니다.
            반전해도 기본 자세는 유지하며 범위 끝의 자세는 반전 움직임이 제한될 수 있습니다. 미러
            표시는 이 방향을 바꾸지 않습니다. 장치별 기준은 이 PC에, 매핑은 프로젝트에 저장합니다.
          </small>
        </details>
        <small data-camera-privacy>
          원본 영상은 이 사용자 화면에만 표시합니다. 캐릭터 캔버스·프로젝트·기본 로그에 넣지
          않습니다.
        </small>
      </div>
    </div>
  );
}
