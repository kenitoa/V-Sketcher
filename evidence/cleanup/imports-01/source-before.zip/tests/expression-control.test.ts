import { scratchPath } from './temp';
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, mkdir, mkdtemp } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import {
  ExpressionController,
  editExpressions,
  referenceIssue,
  targets,
  defaults,
  assertOperation,
  shortcutSlot,
  type ExpressionOperation,
} from '../packages/expression-control';
import { MotionPlayer } from '../packages/motion';
import {
  assertProject,
  readProject,
  serializeProject,
  editProject,
  type Project,
} from '../packages/project-model';
import { parseSessionCommand } from '../packages/project-session/contracts';
import { ProjectSession } from '../packages/project-session';
import { encodeBundle, decodeBundle } from '../packages/project-storage/archive';
const load = async (route?: string): Promise<Project> => {
  const r = readProject(
    await readFile(
      route
        ? `tests/fixtures/common-model/${route}/project.json`
        : 'assets/product/preview-project.json',
      'utf8',
    ),
  );
  if (r.mode !== 'read-write') throw new Error('fixture');
  return r.project;
};
const param = (p: Project, key: string) => p.parameters.find((v) => v.previewKey === key)!;
const op = (
  p: Project,
  keys = ['eye_left'],
  patch: Partial<Extract<ExpressionOperation, { kind: 'save' }>> = {},
): Extract<ExpressionOperation, { kind: 'save' }> => ({
  kind: 'save',
  id: null,
  name: 'Authored eyes',
  values: keys.map((key) => ({
    parameterId: param(p, key).id,
    value: param(p, key).min,
    locked: true,
  })),
  transitionMs: 0,
  releaseMs: 200,
  release: 'live-input',
  ...patch,
});
const author = (
  p: Project,
  keys?: string[],
  patch?: Partial<Extract<ExpressionOperation, { kind: 'save' }>>,
) => {
  const id = 'expression-new-' + p.expressions.length;
  editExpressions(p, op(p, keys, patch), () => id);
  assertProject(p);
  return id;
};
const engine = (p: Project) => {
  const c = new ExpressionController();
  c.setProject(p);
  c.frame(1000);
  return c;
};
const v = (p: Project, key: string, value: number) => new Map([[param(p, key).id, value]]);
const near = (a: number, b: number) => assert.ok(Math.abs(a - b) < 1e-8, `${a} != ${b}`);
test('T171: authored multi-part values, locks, names, duplicate/delete/default cleanup persist without altering the original', async () => {
  const p = await load(),
    before = serializeProject(p);
  const q = editProject(p, (q) => {
    const id = author(q, ['eye_left', 'mouth']);
    editExpressions(q, { kind: 'duplicate', id }, () => 'copy-expression');
    q.runtimeProfile.fallbackExpressionId = id;
    editExpressions(
      q,
      { kind: 'settings', value: { ...defaults, shortcuts: [id, 'copy-expression', null] } },
      () => 'unused',
    );
    editExpressions(q, { kind: 'delete', id }, () => 'unused');
  });
  assert.equal(serializeProject(p), before);
  assert.equal(q.expressions.at(-1)!.displayName, 'Authored eyes (복제)');
  assert.equal(q.expressions.at(-1)!.values.length, 2);
  assert.equal(q.runtimeProfile.fallbackExpressionId, null);
  assert.deepEqual(q.expressionSettings!.shortcuts, [null, 'copy-expression', null]);
});
test('T172: noisy runtime input and preview do not write expression/project/settings/history', async () => {
  const p = await load(),
    id = author(p),
    before = serializeProject(p),
    c = engine(p);
  for (let i = 0; i < 100; i++) {
    c.input('camera', v(p, 'mouth', Math.sin(i)), 1000 + i, i);
    c.frame(1000 + i);
  }
  c.activate(id, 1100);
  c.release(1101);
  c.frame(1400);
  assert.equal(serializeProject(p), before);
});
test('T173: instant transition and smoothstep are bounded by 0..3000ms, absolute clock and exact endpoints', async () => {
  const p = await load(),
    id = author(p, undefined, { transitionMs: 200 }),
    c = engine(p);
  c.activate(id, 1000);
  near(c.frame(1000).values.get(param(p, 'eye_left').id)!, 1);
  near(c.frame(1100).values.get(param(p, 'eye_left').id)!, 0.5);
  near(c.frame(1200).values.get(param(p, 'eye_left').id)!, 0);
  assert.equal(c.frame(9999).transitioning, false);
  for (const n of [-1, 3001, NaN, Infinity, 0.5])
    assert.throws(() => assertOperation(op(p, undefined, { transitionMs: n })));
});
test('T174: locked left eye owns only its parameter; opposite eye/head/mouth keep current camera input', async () => {
  const p = await load(),
    id = author(p),
    c = engine(p);
  c.input(
    'camera',
    new Map(
      [
        ['eye_left', 0.8],
        ['eye_right', 0.6],
        ['mouth', 0.4],
        ['head_yaw', 0.5],
      ].map(([key, value]) => [param(p, String(key)).id, Number(value)]),
    ),
    1000,
    0,
  );
  c.activate(id, 1000);
  const f = c.frame(1000);
  near(f.values.get(param(p, 'eye_left').id)!, 0);
  for (const [key, value] of [
    ['eye_right', 0.6],
    ['mouth', 0.4],
    ['head_yaw', 0.5],
  ] as const) {
    near(f.values.get(param(p, key).id)!, value);
    assert.equal(f.owners.get(param(p, key).id), 'camera');
  }
});
test('T175: test > locked expression > valid live > auto > unlocked fallback > baseline, final clamp always wins', async () => {
  const p = await load(),
    id = author(p),
    c = engine(p);
  p.expressionSettings = { ...defaults, autoBlink: true };
  c.input('camera', v(p, 'eye_left', 0.8), 4000, 0);
  c.activate(id, 4000);
  const key = param(p, 'eye_left').id;
  near(c.frame(4080, v(p, 'eye_left', 999)).values.get(key)!, 1);
  assert.equal(c.frame(4080, v(p, 'eye_left', 0.4)).owners.get(key), 'test');
  assert.equal(c.frame(4080).owners.get(key), 'expression-locked');
  p.expressions.find((e) => e.id === id)!.values[0]!.locked = false;
  assert.equal(c.frame(4080).owners.get(key), 'camera');
  c.clearInput('camera');
  assert.equal(c.frame(4080).owners.get(key), 'automatic');
  assert.equal(c.frame(4500).owners.get(key), 'expression-default');
  c.resume(4500);
  assert.equal(c.frame(5000).owners.get(key), 'neutral');
});
test('T176: camera/mic mouth policy selects exclusively; optional alternate starts only when primary invalid/stale', async () => {
  const p = await load(),
    c = engine(p),
    key = param(p, 'mouth').id;
  p.expressionSettings = { ...defaults, mouth: 'microphone' };
  c.input('camera', v(p, 'mouth', 0.2), 1000, 0);
  c.input('microphone', v(p, 'mouth', 0.7), 1000, 0);
  near(c.frame(1000).values.get(key)!, 0.7);
  c.input('camera', v(p, 'mouth', 0.3), 1250, 1);
  near(c.frame(1301).values.get(key)!, 0.3);
  p.expressionSettings.alternate = false;
  near(c.frame(1301).values.get(key)!, 0);
  p.expressionSettings.mouth = 'camera';
  near(c.frame(1301).values.get(key)!, 0.3);
});
test('T177: release blends to newest moving stream, never entry snapshot; test overlay stays highest during release', async () => {
  const p = await load(),
    id = author(p),
    c = engine(p),
    key = param(p, 'eye_left').id;
  c.input('camera', v(p, 'eye_left', 0.9), 1000, 0);
  c.activate(id, 1000);
  c.release(1100);
  c.input('camera', v(p, 'eye_left', 0.4), 1200, 1);
  near(c.frame(1200).values.get(key)!, 0.2);
  c.input('camera', v(p, 'eye_left', 0.7), 1300, 2);
  near(c.frame(1300).values.get(key)!, 0.7);
  near(c.frame(1300, v(p, 'eye_left', 0.1)).values.get(key)!, 0.1);
});
test('T173/T177: switching active expressions blends from current output and releases old scope to latest live input', async () => {
  const p = await load(),
    a = author(p),
    b = author(p, ['mouth'], { transitionMs: 200 }),
    c = engine(p);
  c.activate(a, 1000);
  c.input('camera', v(p, 'eye_left', 0.8), 1000, 0);
  c.activate(b, 1000);
  near(c.frame(1100).values.get(param(p, 'eye_left').id)!, 0.4);
  near(c.frame(1200).values.get(param(p, 'eye_left').id)!, 0.8);
  assert.equal(c.snapshot().activeId, b);
});
test('T177: explicit neutral release holds former scope only until resume, other live controls continue', async () => {
  const p = await load(),
    id = author(p, undefined, { release: 'neutral', releaseMs: 0 }),
    c = engine(p);
  c.activate(id, 1000);
  c.input('camera', new Map([...v(p, 'eye_left', 0.3), ...v(p, 'mouth', 0.6)]), 1000, 0);
  c.release(1000);
  const f = c.frame(1000);
  near(f.values.get(param(p, 'eye_left').id)!, 1);
  near(f.values.get(param(p, 'mouth').id)!, 0.6);
  assert.equal(f.owners.get(param(p, 'eye_left').id), 'neutral-hold');
  c.resume(1000);
  near(c.frame(1250).values.get(param(p, 'eye_left').id)!, 0.3);
});
test('T178: deleted/replaced target damages only relevant rows, valid values still play and explicit repair reconnects', async () => {
  const p = await load(),
    id = author(p, ['eye_left', 'mouth']),
    e = p.expressions.find((e) => e.id === id)!,
    left = e.values[0]!,
    old = targets(p, left.parameterId)[0]!;
  p.partBindings = p.partBindings.filter((b) => b.partId !== old);
  assert.equal(referenceIssue(p, left), 'unbound');
  const c = engine(p);
  c.activate(id, 1000);
  assert.equal(c.frame(1000).issues.length, 1);
  assert.equal(c.snapshot().owners.get(param(p, 'mouth').id), 'expression-locked');
  p.partBindings.push({
    id: 'replacement-binding',
    partId: p.parts.find((x) => x.role === 'mouth')!.id,
    parameterId: left.parameterId,
    kind: 'transform',
    mapping: { component: 'translate-y', outputRange: [-1, 1] },
  });
  assert.equal(referenceIssue(p, left), 'changed');
  assert.throws(() => editExpressions(p, op(p, ['eye_left'], { id }), () => 'x'), /REPAIR/);
  editExpressions(
    p,
    { kind: 'repair', id, parameterId: left.parameterId, action: 'reconnect' },
    () => 'x',
  );
  assert.equal(referenceIssue(p, left), null);
  assertProject(p);
});
test('T178: removing damaged row preserves all other expressions and parameter definitions', async () => {
  const p = await load(),
    id = author(p, ['eye_left', 'mouth']),
    before = JSON.stringify(p.expressions.slice(0, -1));
  editExpressions(
    p,
    { kind: 'repair', id, parameterId: param(p, 'eye_left').id, action: 'remove' },
    () => 'x',
  );
  assert.equal(p.expressions.at(-1)!.values.length, 1);
  assert.equal(JSON.stringify(p.expressions.slice(0, -1)), before);
  assertProject(p);
});
test('T175/T176: absent/nonfinite/unknown/out-of-order packets cannot claim ownership or extend expired input', async () => {
  const p = await load(),
    c = engine(p),
    key = param(p, 'mouth').id;
  assert.equal(c.input('microphone', v(p, 'eye_left', 0), 1000, 0), false);
  assert.equal(c.input('camera', v(p, 'mouth', 0.4), 1000, 1), true);
  for (const [time, serial, value] of [
    [999, 2, 0.2],
    [1100, 1, 0.2],
    [1100, 2, NaN],
    [1100, 3, Infinity],
  ] as const)
    assert.equal(c.input('camera', v(p, 'mouth', value), time, serial), false);
  assert.equal(c.frame(1301).owners.get(key), 'neutral');
  assert.equal(c.input('camera', v(p, 'mouth', 0.2), 900, 9), false);
  assert.throws(() => c.frame(NaN));
});
test('T175: mapped input is clamped to parameter units and microphone never owns head/eyes', async () => {
  const p = await load(),
    c = engine(p);
  c.input('camera', v(p, 'head_yaw', 999), 1000, 0);
  near(c.frame(1000).values.get(param(p, 'head_yaw').id)!, 1);
  c.clearInput('camera');
  c.input('microphone', new Map([...v(p, 'head_yaw', 1), ...v(p, 'mouth', -999)]), 1000, 0);
  assert.equal(c.frame(1000).owners.get(param(p, 'head_yaw').id), 'neutral');
  near(c.snapshot().values.get(param(p, 'mouth').id)!, 0);
});
test('T179: generation/document change clears active/transitions/live inputs; repeated same document keeps runtime', async () => {
  const p = await load(),
    id = author(p),
    c = engine(p);
  c.activate(id, 1000);
  c.setProject(structuredClone(p));
  assert.equal(c.frame(1000).activeId, id);
  c.setProject(p, 'new-session');
  assert.equal(c.frame(0).activeId, null);
  assert.ok([...c.snapshot().owners.values()].every((v) => v === 'neutral'));
});
test('T179: MotionPlayer composes scoped editor tests over expression/live and stop releases only tests', async () => {
  const p = await load();
  p.motion!.settings.smoothingMs = 0;
  const id = author(p),
    m = new MotionPlayer();
  m.setProject(p);
  m.frame(0);
  m.controls.activate(id, 0);
  m.set('eye_left', 0.5);
  near(m.frame(16).parameters.eye_left, 0.5);
  m.stop();
  near(m.frame(32).parameters.eye_left, 0);
  assert.equal(m.controls.snapshot().activeId, id);
  m.setProject(p, undefined, 'different-session');
  near(m.frame(0).parameters.eye_left, 1);
});
test('T179: app-local fixed shortcut commands ignore IME/repeat/text/modal and OS/global registration is absent', () => {
  const e = {
    ctrlKey: true,
    altKey: true,
    shiftKey: true,
    metaKey: false,
    repeat: false,
    isComposing: false,
    code: 'Digit2',
  };
  assert.equal(shortcutSlot(e, false), 2);
  for (const patch of [
    { repeat: true },
    { isComposing: true },
    { altKey: false },
    { metaKey: true },
    { code: 'KeyA' },
  ])
    assert.equal(shortcutSlot({ ...e, ...patch }, false), null);
  assert.equal(shortcutSlot(e, true), null);
});
test('T171/T172: strict command parser rejects extra runtime data, empty scope, forged anchors and invalid settings', async () => {
  const p = await load();
  for (const operation of [
    { ...op(p), cameraFrame: 'private' },
    op(p, []),
    { ...op(p), values: [{ ...op(p).values[0], partIds: ['forged'] }] },
    { kind: 'settings', value: { ...defaults, shortcuts: [null] } },
  ])
    assert.throws(() =>
      parseSessionCommand({ type: 'expression-edit', expectedRevision: 0, operation }),
    );
  assert.throws(() =>
    editExpressions(
      p,
      { kind: 'settings', value: { ...defaults, shortcuts: ['missing', null, null] } },
      () => 'x',
    ),
  );
});
test('T180: all three prepared structures save/reopen independent expression scopes/settings/anchors with actual resources', async () => {
  for (const route of ['parts', 'single-image', 'split-image']) {
    const p = await load(route);
    const id = author(p, ['eye_left', 'mouth'], { transitionMs: 350, releaseMs: 200 });
    p.expressionSettings = { ...defaults, mouth: 'microphone', shortcuts: [id, null, null] };
    const bytes = new Map<string, Buffer>();
    for (const a of p.assets)
      bytes.set(a.id, await readFile(join('tests/fixtures/common-model', route, a.storage.path)));
    const decoded = await decodeBundle(await encodeBundle(p, bytes, 'manual'));
    assert.deepEqual(decoded.project!.expressions, p.expressions);
    assert.deepEqual(decoded.project!.expressionSettings, p.expressionSettings);
    const c = engine(decoded.project!);
    c.activate(id, 1000);
    assert.equal(c.frame(1350).activeId, id);
    assertProject(decoded.project!);
  }
});
test('T171/T178: actual session checkpoints, CAS rejection, undo/redo, duplicate, save and reopen keep expression data', async () => {
  const p = await load(),
    resources = new Map<string, Buffer>();
  for (const a of p.assets)
    resources.set(
      a.id,
      await readFile(join('assets/product/preview', a.fingerprint.sha256 + '.png')),
    );
  await mkdir(scratchPath('expression-tests'), { recursive: true });
  const dir = await mkdtemp(scratchPath('expression-tests/run-'));
  const s = new ProjectSession({
    dataDir: dir,
    bundled: p,
    bundledBytes: resources,
    autoTimers: false,
    dialogs: {
      openProject: async () => null,
      saveProject: async () => join(dir, 'expression.2dsketch'),
      relinkImage: async () => null,
      unsaved: async () => 'discard',
    },
  });
  await s.init();
  await s.dispatch({ type: 'new', name: 'Expressions', sourceType: 'parts' });
  await s.dispatch({ type: 'sample' });
  const before = s.view().project!,
    operation = op(before, ['eye_left', 'mouth']);
  let reply = await s.dispatch({
    type: 'expression-edit',
    expectedRevision: before.revision,
    operation,
  });
  assert.equal(reply.view.errorCode, null);
  const expressions = structuredClone(reply.view.project!.expressions);
  assert.ok(reply.view.recoveries.length);
  reply = await s.dispatch({
    type: 'expression-edit',
    expectedRevision: before.revision,
    operation,
  });
  assert.equal(reply.view.errorCode, 'E_EDIT_STALE');
  await s.dispatch({ type: 'undo' });
  assert.equal(s.view().project!.expressions.length, before.expressions.length);
  await s.dispatch({ type: 'redo' });
  assert.deepEqual(s.view().project!.expressions, expressions);
  await s.dispatch({ type: 'save' });
  assert.equal(s.view().dirty, false);
  await s.dispatch({ type: 'duplicate' });
  await s.dispatch({ type: 'recent', id: s.view().recent[0]!.id });
  assert.deepEqual(s.view().project!.expressions, expressions);
  await s.shutdown();
});
